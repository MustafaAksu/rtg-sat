#!/usr/bin/env python3
"""Replay available Python evidence only; never silently substitutes for GAP replay."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,shutil
BASE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check_manifest(directory,name):
    entries=[]
    for line in (directory/name).read_text().splitlines():
        if not line.strip():continue
        expected,rel=line.split(maxsplit=1);rel=rel.lstrip('*')
        p=(directory/rel).resolve()
        if not p.is_relative_to(directory.resolve()):raise ValueError('Unsafe manifest path')
        assert p.is_file(),rel
        assert sha(p)==expected,rel
        entries.append(rel)
    return len(entries)
def run(script,*args):
    proc=subprocess.run([sys.executable,str(script),*map(str,args)],check=True,capture_output=True)
    return proc.stdout

def main():
    outer=check_manifest(BASE,'SHA256SUMS.txt')
    inner=check_manifest(BASE/'source','BUNDLE_SHA256SUMS.txt')
    with tempfile.TemporaryDirectory(prefix='hcg_d42_replay_') as tmp:
        t=Path(tmp)
        name='d25_terminal_sieve_claude.py';shutil.copy2(BASE/'source'/name,t/name)
        text=(BASE/'source/d25_counts_and_gt13_claude.py').read_text()
        old='/home/claude/g34/nonsplit8/d25_terminal_sieve_claude.py'
        assert text.count(old)==1
        text=text.replace(old,str(t/name))
        script=t/'counts_path_only.py';script.write_text(text)
        stdout=run(script)
        assert stdout==(BASE/'source/d25_counts_and_gt13_claude_out.txt').read_bytes()
    jobs=[('independent_algebra_checks.py',[],'independent_algebra.json'),
          ('verify_character_export.py',['--self-test'],'character_checker_selftest.json'),
          ('summarize_received_gap_log.py',[BASE/'source/quasisimple_scan_out.txt'],'received_gap_log_summary.json')]
    for script,args,out in jobs:
        got=run(BASE/'checks'/script,*args)
        assert got==(BASE/'outputs'/out).read_bytes(),out
    summary={'package_manifest_pass':outer,'source_manifest_pass':inner,
             'source_python_replay_byte_identical':True,
             'independent_python_outputs_byte_identical':len(jobs),
             'gap_character_table_replay':False,
             'real_character_export_available':False,
             'scope':'PASS for the executed Python evidence; GAP/reduced-table computations remain unexecuted.'}
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
