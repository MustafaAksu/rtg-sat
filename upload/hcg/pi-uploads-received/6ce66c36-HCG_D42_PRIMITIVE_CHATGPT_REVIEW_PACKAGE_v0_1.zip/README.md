# HCG degree-42 peer review — reproduction instructions

This package preserves the received Claude source archive and text files unchanged. Reports and code comments are in English. No adopted DSN is modified.

## What can be replayed now

Python 3.10+ standard library only:

    python replay.py

This validates the package manifest, source manifest, the local source Python recount (changing only its hardcoded file path), the exact algebra/source-repair checks, the received GAP-log *consistency* extraction, and the synthetic tests of the new exact character reader.

**A successful run is NOT a replay of GAP character-table calculations.** GAP was absent from the review runtime, no GAP program was run, and the actual raw character/power-map tables are not in this package. The summary JSON explicitly records that gap_character_table_replay=false. The source spectrum script uses `cmath` for the GT trace-gap screen and exact arithmetic for the profile count; those two evidence types are not conflated.

## Minimal missing input, without another 459-table scan

On the environment with GAP/CTblLib already installed:

    gap -q -b checks/export_all_candidate_characters.g

This should produce `all_candidate_character_data.json` for all 20 eligible ordinary characters of the nine available group-degree pairs, including all power maps and the index-two fusion for 3.O7(3).

**The exporter was inspected but could not be executed in this review environment.** It is a delivery script, not a claimed tested computation. Preserve its output, runtime version, stdout, and SHA-256. Its result should then be verified with:

    python checks/verify_character_export.py all_candidate_character_data.json

The Python reader computes every cyclic eigenvalue multiplicity from the raw character values using exact arithmetic in cyclotomic fields. It does not call GAP or import CTblLib. It also checks a concrete fusion obstruction to invariance of each degree-27 character under the index-two outer extension.

The reader has passed synthetic positive and negative tests only in this session. No claim is made about successful execution on the real export before that file is received.

## Evidence structure

- `source/`: received sources, logs and original manifest.
- `SOURCE_*.zip`: unmodified received ZIP.
- `checks/`: new standard-library checks, prospective all-character exporter and exact reader.
- `outputs/`: frozen executed output files; `received_gap_log_summary.json` is marked log-only.
- `HCG_*REVIEW*.md`: mathematical and source-scope review.
- `HCG_SP8_WEIL_BOUND_SOURCE_REPAIR_v0_1.md`: published-source repair of the absent double-cover row.
- `HCG_D42_PRIMITIVE_LEDGER_PROPOSAL_v0_1.md`: nonadopted disposition proposal.
- `SOURCE_READING_MANIFEST.json`: inspected primary sources and failed screenshot scope.

Do not send this internal HCG research package to the separate Hodge auditor without PI direction.
