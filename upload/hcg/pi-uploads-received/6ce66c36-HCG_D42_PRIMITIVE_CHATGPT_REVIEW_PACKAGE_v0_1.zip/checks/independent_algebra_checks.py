#!/usr/bin/env python3
"""Exact checks of the algebra/budget repairs in the degree-42 peer audit.
No GAP data and no finite-group classification are proved by these tests.
"""
from fractions import Fraction as F
from pathlib import Path
import json, re

def rank_mod(A,p=3):
    a=[[x%p for x in row] for row in A]; r=0
    for j in range(len(a[0])):
        q=next((i for i in range(r,len(a)) if a[i][j]),None)
        if q is None: continue
        a[r],a[q]=a[q],a[r]
        inv=pow(a[r][j],-1,p); a[r]=[(x*inv)%p for x in a[r]]
        for i in range(len(a)):
            if i!=r and a[i][j]:
                c=a[i][j];a[i]=[(x-c*y)%p for x,y in zip(a[i],a[r])]
        r+=1
        if r==len(a):break
    return r

def mm(A,B,p=3):
    return [[sum(a*b for a,b in zip(row,col))%p for col in zip(*B)] for row in A]
def tr(A):return list(map(list,zip(*A)))
def eye(n):return [[int(i==j) for j in range(n)] for i in range(n)]

def main():
    I=eye(8)
    J=[[0]*8 for _ in range(8)]
    for i in range(4):J[i][i+4]=1;J[i+4][i]=-1
    T=[row[:] for row in I];T[0][4]+=1
    minusT=[[-x for x in row] for row in T]
    output={}
    for label,g in [('transvection',T),('negative_transvection',minusT)]:
        assert mm(mm(tr(g),J),g)==[[x%3 for x in row] for row in J]
        a=8-rank_mod([[g[i][j]-I[i][j] for j in range(8)] for i in range(8)])
        b=8-rank_mod([[g[i][j]+I[i][j] for j in range(8)] for i in range(8)])
        output[label]={'fixed_plus':a,'fixed_minus':b}
    assert output['negative_transvection']=={'fixed_plus':0,'fixed_minus':7}
    # For h != +/-I: a,b<=7, a+b<=8. The rank-one determinant argument gives
    # a=7 => b=0, b=7 => a=0. Without these last restrictions (7,1) is a false option.
    allowed=[(a,b) for a in range(8) for b in range(8) if a+b<=8 and (a!=7 or b==0) and (b!=7 or a==0)]
    # Compare A+B*sqrt(3) exactly for nonnegative integer A,B.
    def trace_bound(a,b):
        coeff=[F(0),F(0)]
        for q in (a,b):coeff[q%2]+=F(3**(q//2),2)
        return tuple(coeff)
    target=(F(1,2),F(27,2))
    def nonnegative(A,B):
        if A>=0 and B>=0:return True
        if A<0 and B<0:return False
        if A>=0:return A*A>=3*B*B
        return 3*B*B>=A*A
    for a,b in allowed:
        u=trace_bound(a,b);assert nonnegative(target[0]-u[0],target[1]-u[1])
    assert 47**2>3*27**2 # (1+27 sqrt3)/2 < 24
    output['weil_40_41']={'allowed_dimension_pairs':len(allowed),'uniform_trace_bound':'(1+27*sqrt(3))/2 < 24','moving_rank_lower_bound_40':9,'moving_rank_lower_bound_41':9,'proof_margin_squared':47**2-3*27**2}
    # Lemma S: 2ceil(d/2)+3(N-2), N>=19, versus 2d+8.
    rows=[]
    for d in range(25,44):
        lower=2*((d+1)//2)+51;budget=2*d+8
        assert lower>budget
        rows.append({'d':d,'selfdual_min_sum':lower,'budget':budget,'gap':lower-budget})
    output['selfdual_budget']=rows
    output['commutator_thresholds']=[{'d':d,'c_min_upper':(2*d+8)//19,'commutator_rank_upper':2*((2*d+8)//19)} for d in range(25,43)]
    for row in output['commutator_thresholds']:assert row['commutator_rank_upper']<row['d']
    output['symplectic_type']=[{'d':27,'p':3,'noncentral_min_rank':18,'commutator_rank_upper':6},{'d':32,'p':2,'noncentral_min_rank':16,'commutator_rank_upper':6}]
    # Purely necessary dimension filters, NOT existence results.
    impr=[]
    for d in range(26,42):
        pairs=[(k,d//k) for k in range(2,d+1) if d%k==0 and d//k>=6 and d//k+2*k>=17]
        if pairs:impr.append({'d':d,'block_patterns':pairs})
    assert [x['d'] for x in impr]==[26,28,30,32,33,34,35,36,38,39,40]
    output['imprimitive_budget_survivors']=impr
    output['d42_tensor_budget_survivors']=[(a,42//a) for a in range(2,7) if 42%a==0 and 42//a>=a and 3*(42//a)+16*a<=92]
    assert output['d42_tensor_budget_survivors']==[(3,14)]
    return output
if __name__=='__main__':
    r=main();print(json.dumps(r,indent=2))
