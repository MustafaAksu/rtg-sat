#!/usr/bin/env python3
"""Audit the structure of the received GAP text output; does NOT evaluate GAP tables."""
import json,re,sys
from collections import defaultdict
from pathlib import Path
p=Path(sys.argv[1])
text=p.read_text(encoding='utf-8')
pat=r'^(\S+) d=(\d+) \|Z\|=(\d+) ind=0 field=CF\(3\) inK=true minMovingRank=(\d+)$'
rows=[]
for m in re.finditer(pat,text,re.M):
    name,d,z,mr=m.groups()
    rows.append({'group':name,'dimension':int(d),'centre_order':int(z),'source_reported_min_moving_rank':int(mr)})
summary=defaultdict(list)
for r in rows:summary[(r['group'],r['dimension'])].append(r['source_reported_min_moving_rank'])
expected={('3.O7(3)',27):(2,6),('3.G2(3)',27):(4,12),('U4(2)',30):(2,12),
          ('2.U4(2)',36):(2,18),('3_2.U4(3)',36):(2,16),('6.A7',36):(2,24),
          ('6.L3(4)',36):(2,16),('U4(2)',40):(2,20),('S8(3)',41):(2,16)}
assert set(summary)==set(expected)
for k,(n,mr) in expected.items():assert summary[k]==[mr]*n
print(json.dumps({'classification':'RECEIVED-LOG CONSISTENCY ONLY; NO CHARACTER TABLE REPLAY',
                  'gap_executed':False,'character_rows':len(rows),'group_degree_pairs':len(summary),
                  'rows':rows},indent=2))
