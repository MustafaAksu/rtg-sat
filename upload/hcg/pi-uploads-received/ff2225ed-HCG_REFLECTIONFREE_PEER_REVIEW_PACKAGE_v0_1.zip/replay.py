#!/usr/bin/env python3
"""Verified, local-only replay of the delivered finite checks."""
from __future__ import annotations
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parent

def digest(data: bytes)->str:
    return hashlib.sha256(data).hexdigest()

def verify_manifest()->int:
    count=0
    for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
        if not line.strip():continue
        h,rel=line.split('  ',1)
        path=(ROOT/rel).resolve()
        if ROOT not in path.parents:
            raise ValueError('Unexpected manifest path')
        assert digest(path.read_bytes())==h,rel
        count+=1
    return count

def main()->None:
    print('OUTER_MANIFEST',verify_manifest(),'PASS')
    with zipfile.ZipFile(ROOT/'source'/'SOURCE_CLAUDE.zip') as z:
        lines=z.read('BUNDLE_SHA256SUMS.txt').decode().splitlines()
        n=0
        for line in lines:
            if not line.strip():continue
            h,rel=line.split(None,1);rel=rel.strip().lstrip('*')
            assert digest(z.read(rel))==h,rel
            n+=1
        for name in ['spectral_sieve_and_triples_claude.py','spectral_sieve_and_triples_claude_out.txt']:
            assert z.read(name)==(ROOT/'source'/name).read_bytes()
    print('SOURCE_MANIFEST',n,'PASS')
    with tempfile.TemporaryDirectory(prefix='hcg_reflectionfree_') as tmp:
        t=Path(tmp)
        script=t/'source_test.py'
        script.write_bytes((ROOT/'source'/'spectral_sieve_and_triples_claude.py').read_bytes())
        p=subprocess.run([sys.executable,'-I',str(script)],cwd=t,check=True,capture_output=True)
        assert p.stdout==(ROOT/'source'/'spectral_sieve_and_triples_claude_out.txt').read_bytes()
        assert p.stdout==(ROOT/'evidence'/'claude_replay_stdout.txt').read_bytes()
        print('SOURCE_STDOUT_BYTE_MATCH PASS')
        (t/'scripts').mkdir();(t/'evidence').mkdir()
        ind=t/'scripts'/'independent_checks.py'
        ind.write_bytes((ROOT/'scripts'/'independent_checks.py').read_bytes())
        p=subprocess.run([sys.executable,'-I',str(ind)],cwd=t,check=True,capture_output=True)
        assert p.stdout==(ROOT/'evidence'/'independent_checks_stdout.txt').read_bytes()
        assert (t/'evidence'/'independent_checks.json').read_bytes()==(ROOT/'evidence'/'independent_checks.json').read_bytes()
        print('INDEPENDENT_STDOUT_AND_JSON_BYTE_MATCH PASS')
    print('ORIGINAL_MANIFEST_RECHECK',verify_manifest(),'PASS')
    print('FRESH REPLAY PASS')

if __name__=='__main__':
    main()
