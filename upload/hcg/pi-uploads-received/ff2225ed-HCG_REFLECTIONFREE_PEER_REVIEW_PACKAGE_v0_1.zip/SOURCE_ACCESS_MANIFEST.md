# Primary-source access manifest

Inspection date: 2026-10-29. Exact scientific input files are pinned in the package hash manifest.

| Source | Access and inspection | What is NOT claimed |
|---|---|---|
| Claude, reflection-free review v0.1 | Entire uploaded report, script, output and current ledger read as submitted | No automatic adoption of the ledger proposals |
| Earlier HCG induced-period bound; reflection dichotomy; next-screen note | Targeted local mathematical passages read | No replay of every earlier scientific campaign |
| W. C. Huffman, Caltech thesis (1974), DOI 10.7907/1hnq-y922 | Institutional record/abstract, including two theorem statements, retrieved via web search | Thesis PDF not acquired; no fresh full-proof audit |
| Huffman–Wales, LMA 3 (1975), 53–59, DOI 10.1080/03081087508817092 | Bibliographic identity and publisher access attempted | Full text not read |
| Huffman–Wales, J. Algebra 45 (1977), 465–515 | Publication identity corroborated by primary bibliography and publisher profile | Full text not read |
| D. B. Wales, J. Algebra 53 (1978), 58–67, DOI 10.1016/0021-8693(78)90204-1 | Publisher/bibliographic identity and access attempted | Full text not read |
| Guralnick–Tiep, JEMS 14 (2012), 605–657, DOI 10.4171/JEMS/313 | Published PDF parsed text: pp. 608–609, Definition 2.1, Theorem 1.4, §5.9 pp. 653–654; preprint statement cross-check | Not a reproof of the entire article; rendering attempts failed; no visual-table result is used; no PDF bytes/hash in this archive |

Addresses:

- https://thesis.caltech.edu/14100/
- https://thesis.library.caltech.edu/14100/1/Huffman_WC_1974.pdf
- https://doi.org/10.1080/03081087508817092
- https://doi.org/10.1016/0021-8693(78)90204-1
- https://ems.press/journals/jems/articles/4396
- https://ems.press/content/serial-article-files/31824
- https://arxiv.org/abs/1009.2535

The exact quotations/theorem usage needed for the new argument are described in the proof note, not reconstructed from an aggregator summary. External mathematical statements are imported dependencies; algebraic/Hodge deductions newly written in this review are explicitly SESSION PROPOSED.
