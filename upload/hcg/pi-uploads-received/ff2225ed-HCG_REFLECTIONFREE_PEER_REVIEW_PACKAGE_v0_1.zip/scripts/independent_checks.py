#!/usr/bin/env python3
"""Exact finite checks accompanying the written review; no submitted engine is imported.

The spectral test works in Q[z]/Phi_120(z) using integer coefficient arrays,
not Claude's two-root/Galois-set criterion. Dimension tables check necessary
inequalities, not existence/nonexistence by exhaustive group enumeration.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import combinations_with_replacement
from math import gcd
from pathlib import Path
import json
import random

# Phi_120(z) = z^32 + z^28 - z^20 - z^16 - z^12 + z^4 + 1.
PHI = {0: 1, 4: 1, 12: -1, 16: -1, 20: -1, 28: 1, 32: 1}
DEG = 32

def times_z(v: tuple[int, ...]) -> tuple[int, ...]:
    out = [0] + list(v)
    high = out[32]
    if high:
        for j, c in PHI.items():
            out[j] -= high * c
    assert out[32] == 0
    return tuple(out[:32])

one = (1,) + (0,) * 31
powers = [one]
for a in range(120):
    powers.append(times_z(powers[-1]))
assert powers[120] == one
omega = powers[40]
pivot = next(j for j in range(1, DEG) if omega[j])

def in_K(v: tuple[int, ...]) -> bool:
    b = Fraction(v[pivot], omega[pivot])
    a = Fraction(v[0]) - b * omega[0]
    return all(Fraction(v[j]) == (a if j == 0 else 0) + b * omega[j]
               for j in range(DEG))

def order(a: int) -> int:
    return 120 // gcd(a, 120)

def spectral_sieve() -> list[dict]:
    result = []
    for a, b in combinations_with_replacement(range(1, 120), 2):
        if order(a) != order(b):
            continue
        trace = tuple(x + y for x, y in zip(powers[a], powers[b]))
        determinant = powers[(a+b) % 120]
        if not (in_K(trace) and in_K(determinant)):
            continue
        assert not any(((j*a) % 120 == 0) != ((j*b) % 120 == 0)
                       for j in range(1, 121))
        age = Fraction(a+b, 120)
        inverse_age = 2-age
        assert min(age, inverse_age) <= 1
        result.append({'exponents_zeta120': [a, b], 'order': order(a),
                       'minimum_age_of_g_and_inverse': str(min(age,inverse_age))})
    assert len(result) == 10
    assert {q:sum(x['order']==q for x in result) for q in [2,3,4,6,12]} == {
        2:1,3:3,4:1,6:3,12:2}
    return result

def budget_tables() -> dict:
    branches = []
    prime_branch = []
    for d in range(15,25):
        possible = []
        for k in range(2,d+1):
            if d % k:
                continue
            r = d//k
            if r < 6:
                continue
            lower = 38 + 2*(r-2)*(k-1)
            target = 2*d+8
            assert lower > target
            possible.append({'k':k,'r':r,'moving_rank_lower_bound':lower,
                             'available_rank_sum':target,'contradiction_gap':lower-target,
                             'r_plus_2k':r+2*k})
        if not possible:
            prime_branch.append(d)
        branches.append({'d':d,'forced_codim2_branches_at_least':49-2*d,
                         'old_C_imprimitive_candidate_blocks':possible})
    assert prime_branch == [15,17,19,23]
    survivors = [(k*r,k,r) for k in range(2,31) for r in range(6,61) if r+2*k >=17]
    assert min(d for d,_,_ in survivors)==26
    tensor = []
    for d in range(15,25):
        decomps = []
        for a in range(2,int(d**0.5)+1):
            if d % a:
                continue
            b = d//a
            if a > 2:
                decomps.append({'a':a,'b':b,'reason':'a codimension-2 element is impossible'})
            else:
                lower=3*b+32
                available=4*b+8
                assert lower>available
                decomps.append({'a':a,'b':b,'three_projective_nonidentity_lower_bound':lower,
                                'available_rank_sum':available,'gap':lower-available})
        tensor.append({'d':d,'factorizations':decomps})
    return {'dimensions_15_to_24':branches,'old_forced_C_primitive_dimensions':prime_branch,
            'minimum_C_imprimitive_dimension_allowed_by_new_bound':26,
            'tensor_factor_budget':tensor}

def tensor_multiplicity_tests() -> dict:
    rng = random.Random(20261029)
    tests=0
    for a in range(2,8):
        for b in range(a,13):
            for _ in range(40):
                A=[rng.randrange(12) for _ in range(a)]
                B=[rng.randrange(12) for _ in range(b)]
                fixed=sum((x+y)%12==0 for x in A for y in B)
                c=a*b-fixed
                As=len(set(A))==1
                Bs=len(set(B))==1
                if not As:
                    assert c>=b
                if not Bs:
                    assert c>=a
                if not As and not Bs:
                    assert c>=max(a,b)
                if a*b>=15 and c==2:
                    assert min(a,b)==2 and (As or Bs)
                tests += 1
    # Sharp warning against omitting tensor indecomposability in the imported theorem.
    # I_2 tensor diag(-1,1^7) has dimension 16 and moving rank 2.
    A=[0,0];B=[6]+[0]*7
    c=16-sum((x+y)%12==0 for x in A for y in B)
    assert c==2
    return {'exact_root_of_unity_tensor_tests':tests,
            'rank2_does_not_alone_imply_tensor_indecomposable':{'dimension':16,'moving_rank':c}}

def main() -> None:
    result={'status':'FINITE_CONSISTENCY_CHECKS_NOT_A_SUBSTITUTE_FOR_PROOFS',
            'arithmetic':'integer cyclotomic quotient and Fraction',
            'spectral_types':spectral_sieve(), 'budgets':budget_tables(),
            'tensor_multiplicity_tests':tensor_multiplicity_tests()}
    out=Path(__file__).resolve().parents[1]/'evidence'/'independent_checks.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('CYCLOTOMIC_QUOTIENT_SIEVE 10/10 PASS')
    print('OLD_BLOCK_LIST reproduced; NEW REFLECTION-FREE BUDGET excludes all listed blocks')
    print('TENSOR_MULTIPLICITY',result['tensor_multiplicity_tests']['exact_root_of_unity_tensor_tests'],'PASS')
    print('TENSOR_COUNTERCHECK I2 tensor reflection has rank 2: PASS')
    print('ALL EXACT FINITE CHECKS PASS')

if __name__=='__main__':
    main()
