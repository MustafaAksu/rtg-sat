# Replay

Requires Python 3 standard library only. No network, GAP, SymPy, source engines or pickle execution is used.

```
python -I replay.py
```

The driver verifies the outer manifest; checks the nested original Claude archive's five entries without running arbitrary embedded code; compares the extracted source script/output with their original bytes; executes the inspected source script; and runs the new independent checks in a fresh temporary directory. Both outputs must match their frozen evidence files byte-for-byte.

The script checks:
- ten spectra via exact cyclotomic polynomial reduction;
- source scalar-triple enumeration;
- old and new dimension budgets;
- 2,040 finite tensor-eigenvalue consistency tests;
- an explicit check that moving rank two does not by itself imply tensor indecomposability.

It does NOT computationally prove Hodge factorization, the Guralnick–Tiep classification theorem, or the general exclusion theorem. Those are written proof obligations/imports in the reports.

Files in `source/` are byte-preserved incoming evidence. New results are in `evidence/`. `SHA256SUMS.txt` does not hash itself. No historical source is overwritten.
