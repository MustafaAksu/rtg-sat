#!/usr/bin/env python3
"""Exact ancillary checks for the normal-reflection-subgroup review.

These checks verify arithmetic and matrix identities, not the classification
or the Hodge-theoretic period-factorization proof. Standard library only.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from itertools import permutations
from math import comb
import json
from pathlib import Path
import random


def rank(a: list[list[int]]) -> int:
    if not a:
        return 0
    x = [[F(v) for v in row] for row in a]
    p = 0
    for j in range(len(x[0])):
        pivot = next((i for i in range(p, len(x)) if x[i][j]), None)
        if pivot is None:
            continue
        x[p], x[pivot] = x[pivot], x[p]
        z = x[p][j]
        x[p] = [v / z for v in x[p]]
        for i in range(p + 1, len(x)):
            if x[i][j]:
                z = x[i][j]
                x[i] = [u - z * v for u, v in zip(x[i], x[p])]
        p += 1
        if p == len(x):
            break
    return p


def eye(n: int) -> list[list[int]]:
    return [[int(i == j) for j in range(n)] for i in range(n)]


def mm(a: list[list[int]], b: list[list[int]]) -> list[list[int]]:
    return [[sum(x * y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def corank_one(a: list[list[int]]) -> int:
    return rank([[int(i == j) - a[i][j] for j in range(len(a))] for i in range(len(a))])


def cycle_list(p: tuple[int, ...]) -> list[list[int]]:
    left = set(range(len(p)))
    ans = []
    while left:
        x = min(left)
        cyc = []
        while x in left:
            left.remove(x)
            cyc.append(x)
            x = p[x]
        ans.append(cyc)
    return ans


def signed_perm(r: int, rng: random.Random) -> list[list[int]]:
    q = list(range(r))
    rng.shuffle(q)
    a = [[0] * r for _ in range(r)]
    for j in range(r):
        a[q[j]][j] = rng.choice((-1, 1))
    return a


def block_cycle_checks() -> dict:
    rng = random.Random(20261029)
    cases = 0
    no_defect_control_detected = 0
    for k, r in [(2, 5), (5, 2)]:
        for p in permutations(range(k)):
            cyc = cycle_list(p)
            ind = k - len(cyc)
            for _ in range(3):
                maps = [signed_perm(r, rng) for _ in range(k)]
                g = [[0] * (k * r) for _ in range(k * r)]
                for j in range(k):
                    for a in range(r):
                        for b in range(r):
                            g[p[j] * r + a][j * r + b] = maps[j][a][b]
                defect = 0
                for c in cyc:
                    prod = eye(r)
                    for j in c:
                        prod = mm(maps[j], prod)
                    defect += corank_one(prod)
                direct = corank_one(g)
                assert direct == r * ind + defect
                assert direct >= r * ind
                no_defect_control_detected += int(direct != r * ind)
                cases += 1
    assert no_defect_control_detected > 0
    return {'tested_block_matrices': cases, 'identity_mismatches': 0,
            'omitted_cycle_defect_negative_controls_detected': no_defect_control_detected,
            'identity': 'rank(1-g) = r*ind(pi) + sum_cycles rank(1-cycle_product)'}


def normalizer_incidence_checks() -> dict:
    count = 0
    minimal_margin = None
    for d in range(5, 41):
        for m in range(2, 21):
            for delta in (0, 1):
                coordinate = m * comb(d - 1, 2) + delta * (d - 1)
                for z in range(d - 1):
                    bound = m * comb(z, 2) + comb(d - z, 2) + delta * z
                    margin = coordinate - bound
                    assert margin > 0
                    minimal_margin = margin if minimal_margin is None else min(minimal_margin, margin)
                    count += 1
    # Dimension four really is exceptional: D4 has an incidence tie.
    assert 2 * comb(3, 2) == comb(4, 2)
    return {'tested_incidence_inequalities': count, 'smallest_margin': minimal_margin,
            'D4_tie_detected': True,
            'scope': 'finite arithmetic regression, general convexity proof is in review note'}


def screen() -> list[dict]:
    ans = []
    for d in range(6, 13):
        budget = 2 * d - 11
        a_lower = 2 * (d - (d + 1) // 3 - 1)
        e_lower = 2 * ((d + 1) // 2 - 1) if d in (6, 7, 8) else None
        blocks = []
        for k in range(2, d):
            if d % k:
                continue
            r = d // k
            if r < 2:
                continue
            lower = 2 * (r - 1) * (k - 1)
            genera = [g for g in range(20) if 2 * (r - 1) * (k - 1 + g) <= budget]
            blocks.append({'blocks_k': k, 'block_rank_r': r, 'epsilon_lower': lower,
                           'survives_arithmetic': lower <= budget, 'possible_quotient_genera': genera})
        ans.append({'d': d, 'epsilon_max': budget, 'A_type_lower': a_lower,
                    'E_type_lower': e_lower, 'nonreal_exceptional_at_full_rank': ['G34'] if d == 6 else [],
                    'block_cases': blocks})
    for d in (7, 8, 9, 11):
        row = next(x for x in ans if x['d'] == d)
        assert row['A_type_lower'] > row['epsilon_max']
        assert row['E_type_lower'] is None or row['E_type_lower'] > row['epsilon_max']
        assert not any(b['survives_arithmetic'] for b in row['block_cases'])
    row = next(x for x in ans if x['d'] == 10)
    survivors = [b for b in row['block_cases'] if b['survives_arithmetic']]
    assert [(b['blocks_k'], b['block_rank_r']) for b in survivors] == [(2, 5), (5, 2)]
    assert all(b['possible_quotient_genera'] == [0] for b in survivors)
    return ans


def induced_bounds() -> dict:
    cases = []
    for r in range(1, 7):
        for g in range(7):
            total = 8 + 2 * r * (1 - g)
            if total < 0:
                continue
            dim = 3 * g - 3 + total
            assert dim == 2 * r + 5 + (3 - 2 * r) * g
            cases.append({'block_rank': r, 'genus': g, 'total_moving_rank': total,
                          'effective_points_upper': total, 'period_rank_upper': dim})
    for r in range(1, 6):
        maximum = max(c['period_rank_upper'] for c in cases if c['block_rank'] == r)
        assert maximum < 16
    # The two d=10 residues, under the Hodge/Shapiro factorization proved in the note.
    residues = [{'blocks': 2, 'rank': 5, 'genus': 0, 'effective_points_upper': 18,
                 'period_rank_upper': 15},
                {'blocks': 5, 'rank': 2, 'genus': 0, 'effective_points_upper': 12,
                 'period_rank_upper': 9}]
    return {'cases': cases, 'd10_residues': residues,
            'status': 'PROPOSED geometric application; arithmetic assertions do not prove period factorization'}


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--out', type=Path, default=Path(__file__).with_name('INDEPENDENT_RESULTS.json'))
    args = p.parse_args()
    result = {'screen': screen(), 'normalizer_incidence': normalizer_incidence_checks(),
              'block_cycle_identity': block_cycle_checks(), 'induced_period_bound': induced_bounds(),
              'all_computational_checks_passed': True}
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('INDEPENDENT EXACT CHECKS PASS')
    print(json.dumps({k: result[k] for k in ['normalizer_incidence', 'block_cycle_identity']}, indent=2))

if __name__ == '__main__':
    main()
