#!/usr/bin/env python3
"""Replay hash checks, the producer arithmetic table, and independent exact tests."""
from __future__ import annotations
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parent

def check_manifest(root: Path, name: str) -> int:
    count=0
    for line in (root/name).read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        digest, rel=line.split(None,1)
        rel=rel.strip().lstrip('*')
        path=Path(rel)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError(f'Unsafe manifest entry: {rel}')
        blob=(root/path).read_bytes()
        actual=hashlib.sha256(blob).hexdigest()
        if actual!=digest:
            raise AssertionError(f'Hash mismatch: {rel}')
        count+=1
    return count


def main() -> None:
    n=check_manifest(ROOT,'SHA256SUMS.txt')
    with tempfile.TemporaryDirectory(prefix='hcg_normal_reflection_') as tmp:
        work=Path(tmp)
        src=work/'source';src.mkdir()
        with zipfile.ZipFile(ROOT/'SOURCE_H3_D7_SCREEN_REVIEW_CLAUDE_v0_1.zip') as z:
            for info in z.infolist():
                path=Path(info.filename)
                if path.is_absolute() or '..' in path.parts:
                    raise ValueError('Unsafe ZIP member')
                if info.is_dir():
                    (src/path).mkdir(parents=True,exist_ok=True)
                else:
                    (src/path).parent.mkdir(parents=True,exist_ok=True)
                    (src/path).write_bytes(z.read(info.filename))
        s=check_manifest(src,'BUNDLE_SHA256SUMS.txt')
        p=subprocess.run([sys.executable,'-I',str(src/'nonsplit8_budget_screen_claude.py')],
                         capture_output=True,check=True,timeout=30)
        expected=(src/'nonsplit8_budget_screen_claude_out.txt').read_bytes()
        if p.stdout!=expected:
            raise AssertionError('Producer screen output differs')
        target=work/'independent.json'
        p=subprocess.run([sys.executable,'-I',str(ROOT/'independent_checks.py'),'--out',str(target)],
                         capture_output=True,check=True,timeout=45)
        if target.read_bytes()!=(ROOT/'INDEPENDENT_RESULTS.json').read_bytes():
            raise AssertionError('Independent exact JSON differs')
        assert check_manifest(ROOT,'SHA256SUMS.txt')==n
    print(f'BUNDLE MANIFEST {n}/{n} PASS')
    print(f'ORIGINAL SOURCE MANIFEST {s}/{s} PASS')
    print('SOURCE SCREEN BYTE REPLAY PASS')
    print('INDEPENDENT EXACT JSON BYTE REPLAY PASS')
    print('FRESH REPLAY PASS')

if __name__=='__main__':
    main()
