# HCG normal-reflection screen and proposed d=10 refinement

This is an INTERNAL review bundle, not an adopted DSN. Read the review first; the induced-period note is a **new PROPOSED result**, not part of the already cross-reviewed Claude lemma.

## Replay

Python 3.10+; standard library only. No network, external algebra system, pickle loading, or downloaded code is used.

```sh
python replay.py
```

The driver checks the bundle manifest, safely opens the byte-preserved Claude ZIP into a temporary directory, checks its six-file manifest, reruns its arithmetic screen and compares stdout byte-for-byte. It then runs the independently written exact checker and compares the complete JSON to the frozen expected result. Finally it verifies that this bundle remains unchanged.

The exact checker covers the rank-budget table, 29,412 incidence-inequality regressions (including a D4 negative control), and 366 exact block-permutation matrix tests of the cycle-return rank identity. It also checks numerical consequences of the proposed induced-period bound. These finite computations **do not prove** the Hodge-factorization step or the Shephard–Todd classification. The written proofs and scope limits are in the two reports.

All previous large G34/locality campaigns are intentionally not rerun. The original source ZIP is preserved in full. Primary-source URLs and actual reading extent are listed in the review; no inaccessible Severn PDF is included or represented as freshly verified.
