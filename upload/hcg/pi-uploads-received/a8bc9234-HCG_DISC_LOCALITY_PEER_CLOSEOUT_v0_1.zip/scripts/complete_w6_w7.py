"""Complete only the formerly missing W6/W7 tests with the independent ChatGPT engine."""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'prior_original/scripts'))
import local_determinant_independent as E
rows={}
for lab in ('W6','W7'):
    p=ROOT/'peer_original'/f'roots_{lab}.json'
    data=json.loads(p.read_text())
    values=data['generating_reflection_roots'] if isinstance(data,dict) else data
    roots=[[E.k(*z) for z in v] for v in values]
    rs=[E.reflect(v) for v in roots]
    gs=[s for s in rs for _ in range(2)]
    out=E.parabolic_check(gs,full_block=True)
    out['root_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    assert out['H_dimension']==8
    assert out['class']=={'sign':1,'inert_odd_primes':[]}
    rows[lab]=out
    print(lab,'det_h',out['det_h'],'class',out['class'],'full_block',out['block_determinant_identity'],flush=True)
(ROOT/'work/W6_W7_INDEPENDENT_RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n')
