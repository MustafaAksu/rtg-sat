from pathlib import Path
import hashlib,difflib,json
R=Path(__file__).resolve().parent
src=Path('/mnt/data/HCG_PARABOLIC_DISCRIMINANT_LOCALITY_PROOF_v0_1.md')
text=src.read_text()
assert hashlib.sha256(src.read_bytes()).hexdigest().startswith('0ec38558')
changes=[]
def replace(old,new,label):
 global text
 assert text.count(old)==1,(label,text.count(old))
 text=text.replace(old,new);changes.append(label)
replace('# HCG — A local determinant formula for parabolic cup pairings','# HCG — A local determinant formula for parabolic cup pairings (reviewed clarification v0.2)','title')
replace('**Status:** `[SESSION — THM / PROPOSED]`: a complete algebraic proof is supplied below, with exact checks; independent peer review is still required. No novelty claim and no adoption of this note.',
'''**Status:** `[SESSION — THM] [review: CHECKED by ChatGPT and Claude]`. Claude's independent proof review covers §§2–5; its separate computation was replayed in this revision's intake. This v0.2 applies M1–M6 clarifications without altering the theorem, proof equations, or mathematical scope. No novelty claim; no PI adoption or human refereeing is asserted.
**Source baseline:** `HCG_PARABOLIC_DISCRIMINANT_LOCALITY_PROOF_v0_1.md`, SHA-256 `'''+hashlib.sha256(src.read_bytes()).hexdigest()+'''`; the baseline remains byte-preserved.
**Review receipt:** `H3_DISC_LOCALITY_PROOF_REVIEW_CLAUDE_v0_1.md`, SHA-256 `41bc9997328cbc74a592ba9a899fd6cc30eb6e71656cc284c591ff05ac1878ee`.''','status')
replace('- G. I. Lehrer, *A new proof of Steinberg\'s fixed-point theorem*, IMRN 2004(28), 1407–1411, Theorem 1.1: https://www.maths.usyd.edu.au/u/gusl/Steinimrn.pdf ; DOI 10.1155/S107379280413376X. The theorem statement was accessible through the primary-source indexed text; a fresh download of the full PDF was not available.',
'''- R. Steinberg, *Differential equations invariant under finite reflection groups*, Trans. Amer. Math. Soc. 112 (1964), 392–400, Theorem 1.5: the externally imported pointwise-stabilizer theorem used in §5. G. I. Lehrer, *A new proof of Steinberg's fixed-point theorem*, IMRN 2004(28), 1407–1411, Theorem 1.1, DOI 10.1155/S107379280413376X, states precisely the subspace version. The published abstract and indexed theorem statement were checked; neither reviewer claims a full rereading of Lehrer's proof. The fresh PDF retrieval attempts in this round also failed. This is a classical external theorem, not a new HCG proof.
- D. Bessis, *Finite complex reflection arrangements are K(pi,1)*, arXiv:math/0610777v5 (22 January 2014), Table 2, printed p. 58: `|R(G34)|=126` and invariant degrees `6,12,18,24,30,42`. The table entries were retrieved as extracted text; PDF-rendering attempts failed in this round. The classification datum is imported, not inferred merely from a 126-line orbit.''','M5 and M6 sources')
replace('The restriction of 1-g_i is invertible on E_i. Let S be the parabolic skew-Hermitian cup form and let theta in K^* satisfy conjugate(theta)=-theta. Then',
'''For a unitary g_i, `(1-g_i)^dagger=1-g_i^{-1}` and the two kernels agree. Thus

 E_i^perp=ker(1-g_i),  V=E_i direct_sum ker(1-g_i),

where the direct sum follows from positive definiteness. In particular, `(1-g_i)|E_i` is invertible. Two preimages of x_i under 1-g_i differ by a fixed vector and pair identically with any y_i in E_i.

The product `prod_i b_i` is rational (proved in §3.5); this fact is required before interpreting the brackets below in `Q^*/N(K^*)`. Individual b_i need not be rational. Let S be the parabolic skew-Hermitian cup form and let theta in K^* satisfy conjugate(theta)=-theta. Then''','M1 M3')
replace('Multiplying, using product g_i=1 and even R=2n+2d, proves product b_i is in Q^*. Therefore (5) is an equality between rational determinant representatives modulo an actual norm.',
'''The determinant in this formula may be computed on V because g_i is the identity on `E_i^perp=ker(1-g_i)`: `det(g_i|E_i)=det(g_i|V)`. Multiplying, using product g_i=1 and even R=2n+2d, proves product b_i is in Q^*. Therefore (5) is an equality between rational determinant representatives modulo an actual norm.''','M2')
replace('This holds on **every** component with this local datum; it needs neither a braid connection to W5 nor a boundary degeneration. Thus looking for a nonsplit component with the same twenty reflection classes cannot succeed if the displayed local determinant theorem is accepted.',
'''This holds on **every** component with this local datum; it needs neither a braid connection to W5 nor a boundary degeneration. The root normalization is not an extra hypothesis: replacing root-basis vectors multiplies the local a_i by norms, and rescaling the coefficient form by q in Q^* multiplies the total product by q^R. Here R=20, so q^20=N(q^10). For positive coefficient forms one takes q>0; the class identity itself is unaffected by any nonzero rational scale. Thus looking for a nonsplit component with the same twenty reflection classes cannot succeed under the theorem's hypotheses.''','M4')
replace("By Steinberg's fixed-point theorem (Lehrer Theorem 1.1), the pointwise stabilizer P of Fix(g) is generated by the G34 reflections whose normals lie in E=Fix(g)^perp. Since g has moving rank two, this parabolic subgroup has rank two.",
"By Steinberg's fixed-point theorem (Steinberg 1964, Theorem 1.5; subspace formulation in Lehrer 2004, Theorem 1.1), the pointwise stabilizer P of Fix(g) is generated by the G34 reflections whose normals lie in E=Fix(g)^perp. Since g has moving rank two, this parabolic subgroup has rank two.",'M5 attribution')
replace('The independent root-orbit calculation in this package recovers all 126 known reflection lines, with norm-six representatives. For any two different lines,',
'''**Completeness of the reflection list.** The computed root orbit supplies 126 distinct lines and hence 126 distinct order-two unitary reflections in the verified G34 realization. The classical total reflection count is 126 (Bessis, Table 2, cited above). Therefore the computed list contains **every reflection of G34**, not just reflections encountered in a particular tuple or a proper subset of their orbit. This classification input is needed in the application of Steinberg's theorem.

The representatives all have norm six. For any two different lines,''','M6 completeness')
replace('**Disposition proposal:** suspend P1/P2 sampling and send this proof to Claude for line-by-line review. If that review passes, the current d=6 nonsplit search is closed negatively; proceed to d>=7 using local-factor screening before constructing parabolic cohomology.',
'''**Reviewed disposition:** Claude's independent proof review passed, and ChatGPT has replayed its two new checkers without modifying their mathematical formulas. P1/P2 sampling is no longer the proposed next task. The d=6 nonsplit screen can be recorded as a negative closure **conditional on the group-screen, cup-to-polarization, and Weil-splitting imports above**; PI adoption remains separate. The full nonsplit-eightfold problem stays OPEN. For the next screen, epsilon <= 2d-11 in general, and epsilon <= 3 specifically when d=7; it is not a bound of 3 for every d>=7.''','scope and next budget')
text+='''
## 8. Revision and audit receipt

v0.2 preserves the v0.1 mathematical statement and equations (1)–(5). It makes the moving-space decomposition explicit (M1), records the full-space determinant identity for g_i (M2), front-loads rationality of the product of the b_i (M3), clarifies scale invariance (M4), attributes the imported fixed-point theorem to Steinberg and records the limited source-reading extent (M5), and states the completeness premise behind the 126-reflection list (M6).

The revised status reflects independent proof checking, not additional PI adoption. The source sample-count correction D-10 is retained separately in Claude's immutable dated addendum. The completed W6/W7 replay and external source-access limitations are in `HCG_DISC_LOCALITY_PEER_INTAKE_AND_NEXT_SCREEN_v0_1.md`.
'''
out=Path('/mnt/data/HCG_PARABOLIC_DISCRIMINANT_LOCALITY_PROOF_v0_2.md');out.write_text(text)
(R/'v0_1_to_v0_2.diff').write_text(''.join(difflib.unified_diff(src.read_text().splitlines(keepends=True),text.splitlines(keepends=True),fromfile=src.name,tofile=out.name)))
(R/'CLARIFICATION_CHANGES.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changes':changes},indent=2)+'\n')
print(out,hashlib.sha256(out.read_bytes()).hexdigest())
