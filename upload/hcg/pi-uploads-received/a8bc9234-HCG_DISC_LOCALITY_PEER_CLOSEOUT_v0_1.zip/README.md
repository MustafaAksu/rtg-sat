# HCG discriminant-locality peer closeout

Date: 29 October 2026. Internal HCG evidence only; no adopted DSN edits.

This archive contains the original two source ZIPs, a clarified proof v0.2, the independently replayed Claude logs, completed nine-input source scan, and two new independent W6/W7 checks. Original source bytes are preserved. The d=7 rank-profile note is a separate PROPOSED deduction; it is not part of the already peer-checked theorem.

Run with Python 3.10+ (standard library only):

```
python replay.py
```

The driver verifies this package's manifest, extracts source ZIPs safely into a temporary directory, applies only the declared path substitutions in the two peer programs, and executes them. It then reruns the source G34 scan with the restored W6/W7 inputs, and checks those two inputs using the previously independent ChatGPT triangular-cochain engine. Every output is compared byte-for-byte to the frozen expected files. It does not re-run the unchanged 320-case sampling campaign or download anything.

`SHA256SUMS.txt` excludes itself. The producer's manifest contains external-workspace entries: ten of its 23 pins correspond to delivered files, and all ten match; thirteen are not part of that producer ZIP. `MANIFEST_AUDIT.json` preserves that distinction. The earlier ChatGPT source archive has 40/40 complete records.

The report and changed proof are review artifacts, not a PI adoption decision or proof of any global Hodge conjecture.

## Current-session execution receipt

All four underlying computations completed individually, with the comparisons described in the report. A combined clean-directory call hit this environment's outer time limit after the proof checker passed; a separate source-scan stage also hit that outer limit, while fresh census and W6/W7 stages passed. No completed one-command clean replay is claimed. The same source scan had already completed successfully in the prepared work directory. Use `--stage proof`, `--stage census`, `--stage source`, or `--stage w67` to run stages separately. See `EXECUTION_RECEIPT.json` for the exact scope.
