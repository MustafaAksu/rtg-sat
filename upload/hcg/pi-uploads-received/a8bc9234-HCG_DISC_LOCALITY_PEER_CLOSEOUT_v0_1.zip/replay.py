#!/usr/bin/env python3
"""Replay the scoped peer closeout, preserving all original source bytes."""
from pathlib import Path
import sys,tempfile,zipfile,hashlib,subprocess,shutil,json,argparse
parser=argparse.ArgumentParser()
parser.add_argument("--stage",choices=["all","proof","census","source","w67"],default="all")
STAGE=parser.parse_args().stage
BASE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def extract(src,dest):
    dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(src) as z:
        for item in z.infolist():
            p=dest/item.filename
            if not p.resolve().is_relative_to(dest.resolve()):raise ValueError('Unsafe ZIP path: '+item.filename)
            if item.is_dir():p.mkdir(parents=True,exist_ok=True)
            else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(item))

def run(script,expected,stdout_path=None):
    proc=subprocess.run([sys.executable,str(script)],cwd=script.parent,capture_output=True,check=True,timeout=240)
    if expected is not None:
        assert proc.stdout==expected.read_bytes(), f'Output mismatch: {script.name}'
    if stdout_path:stdout_path.write_bytes(proc.stdout)
    print('PASS',script.name,flush=True)

records=[]
for line in (BASE/'SHA256SUMS.txt').read_text().splitlines():
    h,n=line.split('  ',1);p=BASE/n
    assert p.is_file() and sha(p)==h,n
    records.append(n)
print('Package manifest',len(records),'/',len(records),'PASS',flush=True)
with tempfile.TemporaryDirectory(prefix='hcg_locality_closeout_') as tmp:
    T=Path(tmp);P=T/'peer_original';O=T/'prior_original';W=T/'work';W.mkdir()
    extract(BASE/'source_archives/H3_DISC_LOCALITY_PROOF_REVIEW_CLAUDE_v0_1.zip',P)
    extract(BASE/'source_archives/HCG_DISCRIMINANT_LOCALITY_REPRO_v0_1.zip',O)
    # Re-check the complete prior manifest and located peer pins.
    for line in (O/'SHA256SUMS.txt').read_text().splitlines():
        h,n=line.split(maxsplit=1);assert sha(O/n)==h,n
    located=missing=0
    for line in (P/'SHA256SUMS.txt').read_text().splitlines():
        h,n=line.split(maxsplit=1)
        p=next((x for x in [P/n,P/Path(n).name] if x.is_file()),None)
        if p is None:missing+=1
        else:assert sha(p)==h,n;located+=1
    assert (located,missing)==(10,13)
    for script,expected in [('disc_locality_proof_check_claude.py','proof_stdout.txt'),('g34_rank2_plane_census_claude.py','census_stdout.txt')]:
        stage='proof' if script.startswith('disc_') else 'census'
        if STAGE not in ('all',stage):continue
        text=(P/script).read_text()
        old="'/home/claude/g34/roots_alt_5.json'";assert text.count(old)==1
        text=text.replace(old,repr(str(O/'inputs/W5_roots.json')))
        old="'/home/claude/g34/h4sel/p2p3'"
        if script.startswith('disc_'):
            assert text.count(old)==1;text=text.replace(old,repr(str(O/'source')))
        q=W/script;q.write_text(text)
        run(q,BASE/'expected'/expected)
    completed=W/'completed_inputs';shutil.copytree(O,completed)
    for lab in ('W6','W7'):shutil.copy2(P/f'roots_{lab}.json',completed/'inputs'/f'{lab}_roots.json')
    if STAGE in ('all','source'):
        run(completed/'scripts/g34_scan_path_adapter.py',BASE/'expected/g34_completed_replay.txt')
    if STAGE in ('all','w67'):
        q=W/'complete_w6_w7.py';shutil.copy2(BASE/'scripts/complete_w6_w7.py',q)
        run(q,None)
        generated=W/'W6_W7_INDEPENDENT_RESULTS.json'
        assert generated.read_bytes()==(BASE/'expected/W6_W7_INDEPENDENT_RESULTS.json').read_bytes()
        print('PASS independent W6/W7 frozen JSON',flush=True)
print('PEER CLOSEOUT FRESH REPLAY PASS: '+STAGE)
