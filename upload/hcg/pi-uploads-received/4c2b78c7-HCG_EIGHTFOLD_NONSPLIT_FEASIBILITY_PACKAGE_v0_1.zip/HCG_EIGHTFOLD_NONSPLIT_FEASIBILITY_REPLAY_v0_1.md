# Replay guide — HCG nonsplit eightfold first feasibility screen

All inputs are internal to the Python source; no external package, network or archived dataset is required.

```bash
python3 HCG_EIGHTFOLD_NONSPLIT_CYCLIC_FEASIBILITY_CHECK_v0_1.py
```

The script writes `HCG_EIGHTFOLD_NONSPLIT_CYCLIC_FEASIBILITY_RESULTS_v0_1.json` next to itself (within the extracted package). Scientific observations: C6 exponents `2^5,3,4^3,5` -> genus 15, signature (4,4), hermitian determinant 3/2 nonsplit; C3 exponents `1^5,2^5` -> genus 8, signature (4,4), determinant 1 split. Both bases are 7-dimensional. Supplier conditions are established in the English note by exhaustive subgroup analysis rather than by the determinant script.

`SHA256SUMS.txt` excludes itself to avoid circular hashing. Run `sha256sum -c SHA256SUMS.txt` from inside the extracted package.
