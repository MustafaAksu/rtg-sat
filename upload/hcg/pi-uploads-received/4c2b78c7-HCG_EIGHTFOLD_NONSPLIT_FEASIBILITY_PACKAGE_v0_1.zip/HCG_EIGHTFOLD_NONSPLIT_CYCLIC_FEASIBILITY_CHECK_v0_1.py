"""Independent exact Q(omega) feasibility check for cyclic genus-zero covers.
Session research only; does not verify any Hodge conjecture statement.
No external imports. All arithmetic over Q(omega), omega^2+omega+1=0.
"""
from fractions import Fraction
from math import gcd
import json
from pathlib import Path

class K:
    __slots__ = ("a", "b")
    def __init__(self, a=0, b=0): self.a, self.b = Fraction(a), Fraction(b)
    def __add__(self, other):
        if not isinstance(other, K): other=K(other)
        return K(self.a+other.a, self.b+other.b)
    __radd__=__add__
    def __neg__(self): return K(-self.a, -self.b)
    def __sub__(self, other): return self + ( -other if isinstance(other,K) else -K(other))
    def __rsub__(self, other): return -self + other
    def __mul__(self, other):
        if not isinstance(other,K): other=K(other)
        return K(self.a*other.a-self.b*other.b, self.a*other.b+self.b*other.a-self.b*other.b)
    __rmul__=__mul__
    def conj(self): return K(self.a-self.b,-self.b)
    def norm(self):
        v = self*self.conj(); assert v.b==0
        return v.a
    def __truediv__(self, other):
        if not isinstance(other,K): other=K(other)
        z=other.conj(); return self*K(z.a/other.norm(),z.b/other.norm())
    def __eq__(self, other):
        if not isinstance(other,K): other=K(other)
        return self.a==other.a and self.b==other.b
    def __pow__(self, exponent):
        if exponent<0: return (K(1)/self)**(-exponent)
        out=K(1)
        for _ in range(exponent): out=out*self
        return out
    def coords(self): return [str(self.a),str(self.b)]
    def __repr__(self): return f'{self.a}+({self.b})omega'

ZERO, ONE, OMEGA, ZETA6=K(0),K(1),K(0,1),K(1,1)
THETA=K(1,2)
assert OMEGA**3==ONE and ZETA6**6==ONE and THETA.conj()==-THETA

def determinant(mat):
    a=[row[:] for row in mat]
    out=ONE
    for j in range(len(a)):
        row=next((i for i in range(j,len(a)) if a[i][j]!=ZERO), None)
        if row is None: return ZERO
        if row!=j: a[j],a[row]=a[row],a[j]; out=-out
        pivot=a[j][j];out=out*pivot
        for i in range(j+1,len(a)):
            factor=a[i][j]/pivot
            for t in range(j+1,len(a)):
                a[i][t]=a[i][t]-factor*a[j][t]
            a[i][j]=ZERO
    return out

def hermitian_gram(exponents, order, gauge=None, dependent=None):
    r=len(exponents)
    assert r==10
    root=OMEGA if order==3 else ZETA6
    mon=[root**i for i in exponents]
    assert all(x!=ONE for x in mon)
    pref=[ONE]
    for x in mon:pref.append(pref[-1]*x)
    assert pref[-1]==ONE
    if gauge is None:gauge=r-2
    if dependent is None: dependent=r-1
    assert gauge!=dependent
    basis=[]
    for i in range(r):
        if i in (gauge,dependent):continue
        cocycle=[ZERO]*r
        cocycle[i]=ONE
        cocycle[dependent]=-pref[i]/pref[dependent]
        assert sum((pref[k]*cocycle[k] for k in range(r)),ZERO)==ZERO
        basis.append(cocycle)
    assert len(basis)==8
    def cup(c,b):
        s=ZERO;f=ZERO
        for i in range(r):
            ai=c[i]/(ONE-mon[i]); first=f/pref[i]+ai
            s=s+first*b[i].conj()
            f=f+pref[i]*c[i]
        assert f==ZERO
        return s
    S=[[cup(c,b) for b in basis] for c in basis]
    assert all(S[i][j]==-S[j][i].conj() for i in range(8) for j in range(8))
    H=[[THETA*z for z in row] for row in S]
    assert all(H[i][j]==H[j][i].conj() for i in range(8) for j in range(8))
    return H

def p_val(a,prime):
    a=Fraction(a); assert a!=0
    def count(n):
        x=abs(n); z=0
        while x%prime==0: z+=1;x//=prime
        return z
    return count(a.numerator)-count(a.denominator)

def branch_genus(exponents,order):
    return 1-order+(sum(order-gcd(order,a) for a in exponents))//2

def hodge_eigen_dim(exponents,order,k):
    x=sum(Fraction((k*a)%order,order) for a in exponents)
    assert x.denominator==1
    return int(x)-1

def inspect(exponents,order):
    assert sum(exponents)%order==0 and gcd(order,*exponents)==1
    g=branch_genus(exponents,order)
    d0=hodge_eigen_dim(exponents,order,1)
    d1=hodge_eigen_dim(exponents,order,order-1)
    assert (d0,d1)==(4,4)
    h=hermitian_gram(exponents,order)
    dh=determinant(h)
    assert dh.b==0 and dh.a>0
    # independent Q(omega)-basis gauge, and changed local order
    dh2=determinant(hermitian_gram(exponents,order,0,9))
    assert dh2.b==0 and p_val(dh.a,2)%2==p_val(dh2.a,2)%2
    perm=(2,7,0,8,4,9,6,1,3,5)
    dh3=determinant(hermitian_gram([exponents[j] for j in perm],order))
    assert dh3.b==0 and p_val(dh.a,2)%2==p_val(dh3.a,2)%2
    return dict(order=order,exponents=exponents,genus=g,primitive_factor_dimension=8,
                signature=[d0,d1],h_determinant=str(dh.a),h_determinant_new_gauge=str(dh2.a),
                h_determinant_permuted=str(dh3.a),v2_determinant=p_val(dh.a,2),
                discriminant_split=(p_val(dh.a,2)%2==0),base_dimension=len(exponents)-3,
                required_period_rank=16)

if __name__=='__main__':
    c3=[1]*5+[2]*5
    c6=[2]*5+[3]+[4]*3+[5]
    r3=inspect(c3,3); r6=inspect(c6,6)
    assert r3['h_determinant']=='1' and r3['discriminant_split']
    assert r6['h_determinant']=='3/2' and not r6['discriminant_split']
    # G=C3: (G, chi) admissible: 5 opposite pairs, h=10-2=8. L holds.
    # G=C6: H=G, faithful order-6 chars not admissible (not simple).
    # H=G, order-3 chars: C/C2 -> P1 has 9 branch points and h=7 odd.
    # H=C3: intermediate degree 2,
    # odd exponents 3 and 5 -> genus zero base; 17 branch points of C -> C/C3,
    # h=2*0-2+17=15 odd, so also not admissible. Thus L fails.
    assert len([a for a in c6 if a%2==1])==2
    s_c3=sum(2 if a%2==0 else (1 if a%3 else 0) for a in c6)
    assert s_c3==17 and s_c3-2==15
    s_full_order3=sum(a%3!=0 for a in c6)
    assert s_full_order3==9 and s_full_order3-2==7
    assert len(c6)==10 and len(c6)-3<16
    obj={'source_conventions':'Severn hexagon:2610.00387v2, Definition 4.5 and Lemma 7.2; K=Q(omega)',
         'split_cyclic3':dict(r3,L='YES: (C3,chi) admissible; branch exponents 5*(1,2)'),
         'nonsplit_cyclic6':dict(r6,L='NO: faithful C6 suppliers not simple; order-3 C6 chars h=7 odd; C3 subgroup h=15 odd',
           cyclic_C3_supplier_branch_count=s_c3,cyclic_C3_supplier_h=s_c3-2,
           full_C6_order3_supplier_branch_count=s_full_order3, full_C6_order3_supplier_h=s_full_order3-2),
         'interpretation':'Neither 7-dimensional Hurwitz family can dominate 16-dimensional Weil eightfold PEL domain.'}
    with (Path(__file__).resolve().parent / 'HCG_EIGHTFOLD_NONSPLIT_CYCLIC_FEASIBILITY_RESULTS_v0_1.json').open('w') as f:
        json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')
    print(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False))
