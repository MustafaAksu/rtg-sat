"""Compute exact trace-pairing annihilators of root-edge Hermitian forms; spectral signatures for diagnostics."""
from independent_edge_rank import generate,BASE,qrank,Q
import json,sympy as sp,numpy as np
from itertools import combinations

def get_obs(roots,edges):
    rank,rs,forms=generate(roots,edges,True)
    trace_rows=[]
    for c in forms:
        row=list(c[:4]); p=4
        for i,j in combinations(range(4),2):
            x,y=c[p:p+2];p+=2
            row.extend([2*x-y,2*y-x])
        trace_rows.append(row)
    mat=sp.Matrix(trace_rows)
    ns=mat.nullspace()
    if not ns:return rank,0,None
    if len(ns)!=1: return rank,len(ns),None
    y=ns[0]; d=sp.ilcm(*[a.q for a in y]); y=[int(d*a) for a in y]
    from math import gcd
    from functools import reduce
    g=reduce(gcd,[abs(a) for a in y]);y=[a//g for a in y]
    w=complex(-.5,3**.5/2)
    M=np.zeros((4,4),complex)
    for i in range(4):M[i,i]=y[i]
    p=4
    for i,j in combinations(range(4),2):
        a,b=y[p:p+2];p+=2
        M[i,j]=a+b*w;M[j,i]=M[i,j].conjugate()
    M_exact=sp.zeros(4)
    w_exact=(-1+sp.sqrt(-3))/2
    for i in range(4):M_exact[i,i]=y[i]
    jdx=4
    for i,j in combinations(range(4),2):
        a,b=y[jdx:jdx+2];jdx+=2
        M_exact[i,j]=a+b*w_exact
        M_exact[j,i]=sp.conjugate(M_exact[i,j])
    lam=sp.Symbol('lam')
    charpoly=sp.Poly(sp.simplify(sp.expand(M_exact.charpoly(lam).as_expr())),lam)
    assert all(z.is_Rational for z in charpoly.all_coeffs()), charpoly
    eig=np.linalg.eigvalsh(M)
    counts=(int(sum(eig>1e-6)),int(sum(eig< -1e-6)),int(sum(abs(eig)<=1e-6)))
    reduced=charpoly.exquo(sp.Poly(lam**counts[2],lam))
    assert reduced.count_roots(-sp.oo,0) == counts[1]
    assert reduced.count_roots(0,sp.oo) == counts[0]
    return rank,len(ns),(y,counts,str(charpoly.as_expr()))

def main():
    bal=[(2*i+1,2*i+2) for i in range(10)]+[(1,4),(5,8),(9,12),(13,16),(1,8),(9,16),(1,16)]
    comb=[(2*i+1,2*i+2) for i in range(10)]+[(1,2*k) for k in range(2,9)]
    for name,base in [('W5','g34_cert_tuple5_balanced.json'),('W6','g34_cert_W6_comb.json'),('W7','g34_cert_W7_comb.json')]:
        roots=json.loads((BASE/base).read_text())['roots']
        for label,edge in [('balanced',bal),('comb',comb)]:
            rank,nullity,obs=get_obs(roots,edge)
            if obs:
                y,counts,charpoly=obs
                print(name,label,'spanrank',rank,'annihilator_dim',nullity,'Y_complex_rank',sum(counts[:2]),'Y_signature(+,-,0)',counts,'Y_charpoly',charpoly,'Y_hermitian_coordinates',y)
            else: print(name,label,'spanrank',rank,'annihilator_dim',nullity)
if __name__=='__main__':main()
