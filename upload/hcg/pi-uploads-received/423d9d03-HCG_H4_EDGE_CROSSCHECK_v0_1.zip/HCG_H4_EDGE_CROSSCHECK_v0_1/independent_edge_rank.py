"""Independent finite test of the proposed root/pants edge-form rank predictor.
No G34 engine imported; monodromy certificate used only for comparison ranks on its own decomposition.
Uses exact (Fraction,Fraction) arithmetic in Q(w), w^2+w+1=0.
"""
from fractions import Fraction as Q
import json
from pathlib import Path
BASE=Path(__file__).resolve().parent
Z=(Q(0),Q(0)); ONE=(Q(1),Q(0))
def val(a):return (Q(a[0]),Q(a[1]))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[0],-a[1]
def sub(a,b):return add(a,neg(b))
def conj(a):return a[0]-a[1],-a[1]
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]-a[1]*b[1]
def div(a,b):
    c=conj(b); z=mul(b,c)[0]; p=mul(a,c);return p[0]/z,p[1]/z
def rref(A):
    A=[list(r) for r in A];piv=[];r=0
    for c in range(len(A[0])):
        p=next((i for i in range(r,len(A)) if A[i][c]!=Z),None)
        if p is None:continue
        A[r],A[p]=A[p],A[r]
        pv=A[r][c];A[r]=[div(v,pv) for v in A[r]]
        for i in range(len(A)):
            if i!=r and A[i][c]!=Z:
                t=A[i][c];A[i]=[sub(x,mul(t,y)) for x,y in zip(A[i],A[r])]
        piv.append(c);r+=1
        if r==len(A):break
    return A,piv
def kernel(A):
    R,piv=rref(A);free=[j for j in range(len(A[0])) if j not in piv];out=[]
    for k in free:
        x=[Z]*len(A[0]);x[k]=ONE
        for i,j in enumerate(piv):x[j]=neg(R[i][k])
        out.append(x)
    return out
def qrank(A):
    A=[list(row) for row in A];rank=0
    if not A:return 0
    for c in range(len(A[0])):
        p=next((r for r in range(rank,len(A)) if A[r][c]),None)
        if p is None:continue
        A[rank],A[p]=A[p],A[rank]
        pv=A[rank][c];A[rank]=[x/pv for x in A[rank]]
        for r in range(rank+1,len(A)):
            if A[r][c]:
                z=A[r][c];A[r]=[x-z*y for x,y in zip(A[r],A[rank])]
        rank+=1
        if rank==len(A):break
    return rank
def generate(roots,intervals,return_forms=False):
    roots=[[val(x) for x in v] for v in roots]
    A=[[roots[i][j] for i in range(10)] for j in range(6)]
    L=kernel(A)
    assert len(L)==4
    forms=[]; eranks=[]
    for start,stop in intervals:
        assert start%2==1 and stop%2==0
        idx=range((start-1)//2,stop//2)
        flux=[[sum_pair(mul(L[a][i],roots[i][j]) for i in idx) for j in range(6)] for a in range(4)]
        H=[[sum_pair(mul(flux[a][j],conj(flux[b][j])) for j in range(6)) for b in range(4)] for a in range(4)]
        assert all(H[a][b]==conj(H[b][a]) for a in range(4) for b in range(4))
        assert all(H[a][a][1]==0 for a in range(4))
        coord=[H[i][i][0] for i in range(4)]
        for i in range(4):
            for j in range(i+1,4):coord.extend(H[i][j])
        assert len(coord)==16
        forms.append(coord)
        eranks.append(len(rref(H)[1]))
    return (qrank(forms),eranks,forms) if return_forms else (qrank(forms),eranks)
def sum_pair(seq):
    o=Z
    for x in seq:o=add(o,x)
    return o
def cert_rank(cert):
    rows=[]
    for curve in cert['curves']:
        row=[]
        for r in curve['N']:
            for a,b in r:row.extend([Q(a),Q(b)])
        rows.append(row)
    return qrank(rows)
def cert_individual_ranks(cert):
    return [len(rref([[val(a) for a in row] for row in curve['N']])[1]) for curve in cert['curves']]
def run():
    bal=[(2*i+1,2*i+2) for i in range(10)]+[(1,4),(5,8),(9,12),(13,16),(1,8),(9,16),(1,16)]
    comb=[(2*i+1,2*i+2) for i in range(10)]+[(1,2*k) for k in range(2,9)]
    w5=json.loads((BASE/'g34_cert_tuple5_balanced.json').read_text())
    cs=[('W5',w5),('W6',json.loads((BASE/'g34_cert_W6_comb.json').read_text())),('W7',json.loads((BASE/'g34_cert_W7_comb.json').read_text()))]
    for name,c in cs:
        for label,curves in [('balanced',bal),('comb',comb)]:
            rr,individual=generate(c['roots'],curves)
            print(name,label,'edge_span_Q_rank',rr,'edge_form_ranks',individual)
            actual_curves=[tuple(row['curve']) for row in c['curves']]
            if actual_curves==curves:
                ar=cert_rank(c)
                print(' certified_monodromy_Q_rank',ar,'match',ar==rr)
                print(' certified_monodromy_individual_K_ranks',cert_individual_ranks(c))
                print(' individual_ranks_match',cert_individual_ranks(c)==individual)
if __name__=='__main__':run()
