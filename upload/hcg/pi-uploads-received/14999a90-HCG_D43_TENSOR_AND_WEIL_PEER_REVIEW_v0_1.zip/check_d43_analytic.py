#!/usr/bin/env python3
"""Exact integer checks for the d=43 U7(2) Weil-character bound
and 3 tensor b branch budgets; no GAP and no source motor.
"""
from itertools import product
from math import isqrt
import json
from pathlib import Path

# q=2, n=7; nonidentity g in SU7(2) is never an F4-scalar.
# f_i are the F4 dimensions of eigenspaces for 1, xi, xi^2.
triples=[]
for ff in product(range(7),repeat=3):
    if sum(ff)>7:
        continue
    p,q,r=((-2)**j for j in ff)
    A=p-r; B=q-r
    # 9 * |chi_43(g)|^2 is the Eisenstein norm of A + B*omega.
    z=A*A-A*B+B*B
    triples.append((z,ff))
max_norm, witness=max(triples)
assert max_norm==4167
assert max_norm<9*23**2
# For any f triple: |chi| <= sqrt(max_norm)/3 < 23,
# hence c(g) >= (43 - |chi|)/2 > 10,
# hence c(g) >= 11.
assert max_norm < 9*23**2
assert 43 - 23 == 20

rows=[]
for b in range(1,21):
    total=6*b+8
    # At least three A-projectively active elements
    min_three=3*b+3*(19-3)
    min_four=4*b+3*(19-4)
    slack=total-min_three
    rows.append(dict(b=b,d=3*b,rank_budget=total,
                     minimum_three_active=min_three,
                     minimum_four_active=min_four,
                     three_active_possible=total>=min_three,
                     four_active_possible=total>=min_four,
                     slack_at_three=slack,
                     three_distinct_eigenvalues_excluded=(slack < b)))
for b in range(14,19):
    x=rows[b-1]
    assert x['three_active_possible']
    assert not x['four_active_possible']
    assert x['three_distinct_eigenvalues_excluded']
assert not rows[13-1]['three_active_possible']
assert rows[19-1]['four_active_possible']

# d=43 Lemma S and C arithmetic:
d=43;Nmin=19;sumc=2*d+8
assert 2*((d+1)//2)+3*(Nmin-2)==95>sumc
assert 2*(sumc//Nmin)==8
assert 11>8

# d=44 factorwise tensor test; this is a prospective screen, not group classification.
for a,b in [(2,22),(4,11)]:
    assert 2*a*b+8 < 3*b+16*a

out={
    'weils_43': dict(f_triples=len(triples),max_nine_times_abs_trace_sq=max_norm,
                     f_witness=witness,
                     abs_trace_lt_23=True,
                     nonidentity_moving_rank_ge=11,
                     lemma_C_required_moving_rank_le=8),
    'three_tensor_b':rows,
    'd43_selfdual_budget':dict(minimal=95, available=94),
    'd44_factorwise_budget':{'2x22':[96,98], '4x11':[96,97]},
}
Path(__file__).with_name('d43_exact_results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('D43 ANALYTIC EXACT CHECK PASS')
