# HCG reflection dichotomy — independent peer-review bundle

Date: 2026-10-29. INTERNAL research evidence. No adopted source is modified.

## Main documents
- `HCG_REFLECTION_DICHOTOMY_CHATGPT_REVIEW_v0_1.md`: review of Claude's Lemmas E/F/Theorem R; exact assumptions, proof checks, field qualification and source access limitations.
- `HCG_REFLECTIONFREE_NEXT_SCREEN_PROPOSED_v0_1.md`: new optional reviewer derivations (type-A rank<=12, ten-type rank-two spectral sieve, unimodularity and K/C primitivity cautions); peer review pending.
- `SOURCE_H3_INDUCED_PERIOD_REVIEW_CLAUDE_v0_1.zip`: unchanged received archive.
- `source_engine/generic_engine.py`: recovered unchanged producer dependency, pinned to SHA-256 `66f2c253d7b8390858e9ca8cdf81b7b5579777721d7763e0d3b631be58fca505`.

## Replay
Python 3 with SymPy (tested 1.14.0):

```text
python replay.py
```

The replay checks this package's manifest and the producer manifest. It then runs a temporary copy of the source checker with ONLY its import-path literal changed, comparing complete output bytes. Finally it runs the independently written checker in a different temporary directory and compares its exact JSON with the frozen result. No network calls, repository writes, pickle loading or source archive execution is performed. The original files remain unchanged.

A PASS means deterministic replay of the listed finite calculations. It is not a formalized proof of the geometric/Hodge arguments, a human referee verdict, or an adoption decision.

PDFs are not bundled. The review explicitly records which primary-text passages were accessible and which full texts or screenshots failed; no archival PDF hash is fabricated.
