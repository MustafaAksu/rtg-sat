#!/usr/bin/env python3
"""Reproduce source and independent checks in disposable working directories."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(path,root):
 count=0
 for line in path.read_text().splitlines():
  if not line.strip():continue
  h,name=line.split('  ',1);p=root/name
  if not p.is_file() or digest(p)!=h:raise RuntimeError('Manifest mismatch: '+name)
  count+=1
 return count

def main():
 first=manifest(ROOT/'SHA256SUMS.txt',ROOT)
 print('PACKAGE MANIFEST',first,'PASS')
 second=manifest(ROOT/'source/BUNDLE_SHA256SUMS.txt',ROOT/'source')
 print('SOURCE MANIFEST',second,'PASS')
 pin='66f2c253d7b8390858e9ca8cdf81b7b5579777721d7763e0d3b631be58fca505'
 assert digest(ROOT/'source_engine/generic_engine.py')==pin
 with tempfile.TemporaryDirectory(prefix='hcg-reflection-review-') as td:
  tmp=Path(td);eng=tmp/'engine';eng.mkdir()
  shutil.copy2(ROOT/'source_engine/generic_engine.py',eng/'generic_engine.py')
  src=(ROOT/'source/block_cycle_local_factor_claude.py').read_text()
  literal="sys.path.insert(0,'/home/claude/g34/h4sel/p2p3')"
  assert src.count(literal)==1
  src=src.replace(literal,f'sys.path.insert(0,{str(eng)!r})')
  fn=tmp/'source_check.py';fn.write_text(src)
  p=subprocess.run([sys.executable,'-I',str(fn)],capture_output=True,check=True,timeout=120)
  assert p.stdout==(ROOT/'expected/source_replay_stdout.txt').read_bytes()
  assert p.stdout==(ROOT/'source/block_cycle_local_factor_claude_out.txt').read_bytes()
  print('SOURCE REPLAY 60/60; FULL STDOUT BYTE MATCH')
  ind=tmp/'independent';ind.mkdir()
  shutil.copy2(ROOT/'independent_checks.py',ind/'independent_checks.py')
  p=subprocess.run([sys.executable,'-I',str(ind/'independent_checks.py')],capture_output=True,check=True,timeout=120)
  assert (ind/'INDEPENDENT_RESULTS.json').read_bytes()==(ROOT/'expected/INDEPENDENT_RESULTS.json').read_bytes()
  print(p.stdout.decode().strip())
  print('INDEPENDENT JSON BYTE MATCH')
 assert manifest(ROOT/'SHA256SUMS.txt',ROOT)==first
 print('ORIGINAL PACKAGE UNCHANGED')
 print('FRESH REPLAY PASS')
if __name__=='__main__':main()
