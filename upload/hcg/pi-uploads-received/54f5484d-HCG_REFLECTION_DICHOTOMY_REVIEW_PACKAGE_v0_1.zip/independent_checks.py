#!/usr/bin/env python3
"""Independent exact checks for Lemma E local factor, Lemma F budgets, and field/spectral scope.
No producer computation engine is imported. Q(w), w^2+w+1=0.
The finite checks are regression evidence, not substitutes for the general proofs.
"""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import gcd
from pathlib import Path
import json
import sympy as sp

Z=(F(0),F(0)); O=(F(1),F(0)); W=(F(0),F(1))
def k(a=0,b=0): return F(a),F(b)
def add(x,y):return x[0]+y[0],x[1]+y[1]
def neg(x):return -x[0],-x[1]
def sub(x,y):return add(x,neg(y))
def mul(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]-x[1]*y[1]
def bar(x):return x[0]-x[1],-x[1]
def inv(x):
 n=mul(x,bar(x))[0]
 if not n: raise ZeroDivisionError
 b=bar(x);return b[0]/n,b[1]/n
def div(x,y):return mul(x,inv(y))
def total(xs):
 out=Z
 for x in xs:out=add(out,x)
 return out
def eye(n):return [[O if i==j else Z for j in range(n)] for i in range(n)]
def tr(A):return list(map(list,zip(*A)))
def cb(A):return [[bar(x) for x in row] for row in A]
def mm(A,B):return [[total(mul(A[i][t],B[t][j]) for t in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def minus(A,B):return [[sub(a,b) for a,b in zip(x,y)] for x,y in zip(A,B)]
def rref(A):
 A=[row[:] for row in A]; piv=[];i=0
 if not A:return A,piv
 for j in range(len(A[0])):
  row=next((t for t in range(i,len(A)) if A[t][j]!=Z),None)
  if row is None:continue
  A[i],A[row]=A[row],A[i];p=A[i][j];A[i]=[div(x,p) for x in A[i]]
  for t in range(len(A)):
   if t!=i and A[t][j]!=Z:
    c=A[t][j];A[t]=[sub(x,mul(c,y)) for x,y in zip(A[t],A[i])]
  piv.append(j);i+=1
  if i==len(A):break
 return A,piv
def inverse(A):
 n=len(A);R,piv=rref([row+e for row,e in zip(A,eye(n))]);assert piv[:n]==list(range(n))
 assert [row[:n] for row in R]==eye(n)
 return [row[n:] for row in R]
def det(A):
 if not A:return O
 A=[row[:] for row in A];d=O
 for j in range(len(A)):
  p=next((i for i in range(j,len(A)) if A[i][j]!=Z),None)
  if p is None:return Z
  if p!=j:A[j],A[p]=A[p],A[j];d=neg(d)
  v=A[j][j];d=mul(d,v)
  for i in range(j+1,len(A)):
   c=div(A[i][j],v)
   for t in range(j+1,len(A)):A[i][t]=sub(A[i][t],mul(c,A[j][t]))
   A[i][j]=Z
 return d
def power(x,j):
 out=O
 for _ in range(j):out=mul(out,x)
 return out
def normclass(x):
 assert x[1]==0 and x[0]!=0
 q=x[0]; factors={}
 for z,sign in [(abs(q.numerator),1),(q.denominator,-1)]:
  for p,e in sp.factorint(z).items():factors[int(p)]=factors.get(int(p),0)+sign*int(e)
 return {'sign':1 if q>0 else -1,'inert_odd':[p for p,e in sorted(factors.items()) if p%3==2 and e%2]}
def local_ab(g,H):
 A=minus(eye(len(g)),g);_,cols=rref(A)
 if not cols:return O
 E=[[row[j] for j in cols] for row in A]
 gram=mm(mm(tr(E),H),cb(E))
 _,rows=rref(tr(E));Esub=[E[i] for i in rows]
 AE=mm(A,E);X=mm(inverse(Esub),[AE[i] for i in rows])
 assert mm(E,X)==AE
 return mul(det(gram),det(X))
def block_tests():
 rows=[];wrong=0
 phases=[O,W,neg(O),neg(mul(W,W))]
 for r in (1,2,3):
  for ell in (2,3,4):
   for profile in range(3):
    T=eye(r)
    for i in range(r):
     for j in range(i+1,r):T[i][j]=k(i+1,j-profile)
    D=[[k([2,5,1][i]) if i==j else Z for j in range(r)] for i in range(r)]
    H=mm(mm(tr(T),D),cb(T))
    eig=[O]*r if profile==0 else [phases[(i+profile)%4] for i in range(r)]
    P0=[[eig[i] if i==j else Z for j in range(r)] for i in range(r)]
    P=mm(mm(inverse(T),P0),T)
    assert mm(mm(tr(P),H),cb(P))==H
    n=r*ell;g=[[Z]*n for _ in range(n)];Hg=[[Z]*n for _ in range(n)]
    for j in range(ell):
     for a in range(r):
      for b in range(r):
       Hg[j*r+a][j*r+b]=H[a][b]
       g[((j+1)%ell)*r+a][j*r+b]=P[a][b] if j==ell-1 else (O if a==b else Z)
    assert mm(mm(tr(g),Hg),cb(g))==Hg
    lhs=local_ab(g,Hg);p_ab=local_ab(P,H);dH=det(H)
    ratio=div(lhs,mul(p_ab,power(dH,ell-1)))
    nc=normclass(ratio);assert nc=={'sign':1,'inert_odd':[]}
    naive=normclass(div(lhs,p_ab));bad=naive!={'sign':1,'inert_odd':[]};wrong+=bad
    rows.append({'r':r,'ell':ell,'profile':profile,'det_H':str(dH[0]),'ratio':str(ratio[0]),'norm_class':nc,'omitted_factor_rejected':bad})
 return {'cases':len(rows),'pass':True,'omitted_factor_rejections':wrong,'results':rows}
def partitions(n,lo=1):
 if n==0:yield ();return
 for j in range(lo,n+1):
  for rest in partitions(n-j,j):yield (j,)+rest

def scalar_tests():
 total_parts=0
 for d in range(6,25):
  maxima={q:0 for q in (2,3,6)}
  for cyc in partitions(d+1):
   total_parts+=1
   for q in maxima:
    eigmult=sum(j%q==0 for j in cyc);maxima[q]=max(maxima[q],eigmult)
    assert eigmult<=(d+1)//q
  assert all(maxima[q]==(d+1)//q for q in maxima)
 triples=[v for v in combinations_with_replacement(range(1,6),3) if sum(v)%6==0]
 orders=lambda a:6//gcd(a,6)
 assert all(sum(F(1,orders(a)) for a in v)<=1 for v in triples)
 for d in range(6,10001):
  e=2*d-11;A=d-(d+1)//3-1;B=d-(d+1)//2-1
  assert 2*A+2*B>e  # eliminates t >= 4
  for v in triples:assert sum(d-(d+1)//orders(a)-1 for a in v)>e
 return {'dimensions_partition_checked':[6,24],'partitions_checked':total_parts,'scalar_budget_dimensions_checked':[6,10000], 'product_one_nontrivial_mu6_triples':triples,'t_ge_3_eliminated':True,'result_with_generation':'t=2; rank Per <= 12 (new strengthening, peer review pending)'}

def field_scope_example():
 # Deleted permutation representation of AGL(1,7), twisted by an independent cubic scalar.
 x=sp.Symbol('x'); n=7
 def matrix(a,b):
  P=sp.zeros(n)
  for j in range(n):P[(a*j+b)%n,j]=1
  V=sp.Matrix.hstack(*[sp.eye(n)[:,i]-sp.eye(n)[:,6] for i in range(6)])
  return (P*V)[:6,:]
 A=matrix(1,1);B=matrix(3,0)
 poly=A.charpoly(x).as_expr();assert poly==sp.cyclotomic_poly(7,x)
 w=(-1+sp.sqrt(-3))/2
 assert sp.Poly(poly,x,extension=w).is_irreducible
 chars=[int(sp.trace(matrix(a,b))) for a in range(1,7) for b in range(7)]
 assert sum(z*z for z in chars)==42
 assert B**6==sp.eye(6) and A**7==sp.eye(6)
 return {'group':'AGL(1,7) x mu3 on deleted permutation module tensor cubic character','d':6,'char_norm_AGL':1,'order7_charpoly':str(poly),'irreducible_over_K':True,'scope':'K-primitive but complex-monomial; excluded by monomial period bound. This is a field-of-block-definition warning, not a feasible nonsplit datum.'}

def spectra_tests():
 x=sp.Symbol('x');w=(-1+sp.sqrt(-3))/2
 polys=[(x+1)**2,(x-w)**2,(x-w.conjugate())**2,x*x+x+1,(x+w)**2,(x+w.conjugate())**2,x*x-x+1,x*x+1,x*x+w,x*x+w.conjugate()]
 results=[]
 for p in polys:
  po=sp.Poly(sp.expand(p),x,extension=w)
  # Companion matrix has finite order and no nontrivial rank-one power.
  _,a,b=po.all_coeffs();g=sp.Matrix([[0,-b],[1,-a]])
  # Repeated roots require the semisimple scalar matrix, not the companion Jordan block.
  disc=sp.simplify(a*a-4*b)
  if disc==0:g=(-a/2)*sp.eye(2)
  powerM=sp.eye(2);order=None;ranklist=[]
  for j in range(1,13):
   powerM=(powerM*g).applyfunc(sp.simplify)
   rr=(powerM-sp.eye(2)).rank();ranklist.append(rr)
   if rr==0:order=j;break
  assert order in (2,3,4,6,12) and 1 not in ranklist
  results.append({'polynomial':str(po.as_expr()),'order':order,'power_ranks':ranklist})
 return {'possible_K_orders':[2,3,4,6,12],'semisimple_spectra_cases':10,'results':results,'status':'new algebraic spectral screen, not a primitive-group classification'}

def main():
 result={'block_local_factor':block_tests(),'type_A_scalar_bound':scalar_tests(),'field_scope':field_scope_example(),'rank2_spectral_screen':spectra_tests()}
 out=Path(__file__).with_name('INDEPENDENT_RESULTS.json');out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print('BLOCK LOCAL FACTOR',result['block_local_factor']['cases'],'PASS')
 print('TYPE-A SPECTRUM PARTITIONS',result['type_A_scalar_bound']['partitions_checked'],'PASS')
 print('FIELD SCOPE EXAMPLE PASS')
 print('RANK-2 SPECTRA 10/10 PASS')
 print('ALL INDEPENDENT CHECKS PASS')
if __name__=='__main__':main()
