#!/usr/bin/env python3
"""Independent post-commit EDGEFLUX audit using ChatGPT's own pre-existing Artin engine.

Reads only roots/trees and independently generated monodromy outputs. No Claude
predictor, cup engine, certificate dump, or identity-check functions are imported.
The polynomial identity is checked against N reconstructed by elementary Artin
moves, not against N defined by the edge-flux identity under test.
"""
from pathlib import Path
import importlib.util, json, hashlib, argparse

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--audit-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); root=a.audit_root.resolve()
    module=root/'monodromy_rebuild.py'
    spec=importlib.util.spec_from_file_location('independent_monodromy',module)
    M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
    out={'date':'2026-10-23','scope':'post-commit independent identity check, not a new blind prediction',
         'engine_sha256':hashlib.sha256(module.read_bytes()).hexdigest(),
         'cases':[]}
    total_occ=0; total_distinct=0
    for name in ('NEW01','NEW02','NEW03','NEW04'):
        roots=M.decode(json.loads((M.INPUT/f'{name}_roots.json').read_text())['generating_reflection_roots'])
        trees=json.loads((M.INPUT/f'{name}_trees.json').read_text())['curves']
        stored=json.loads((root/'actual'/f'{name}_ACTUAL_MONODROMY.json').read_text())
        repeated,closure,cob,cc,B,project,gauge=M.build_quotient(roots)
        m,n,d=len(roots),len(roots[0]),len(cc)
        # Build tau as a linear operation on cochains, then pass to fresh quotient reps.
        Delta=[[M.ONE if k==2*i else M.neg(M.ONE) if k==2*i+1 else M.Z
                for k in range(2*m)] for i in range(m)]
        Tau=M.mm(Delta,M.tr(cc)) # 10 x 8; columns are images of quotient basis vectors
        rootmap=M.tr(roots)
        L=M.nullspace(rootmap)
        tau_rank=M.rank(Tau)
        assert tau_rank==m-n==4
        assert M.zero(M.mm(rootmap,Tau))
        assert M.zero(M.mm(Delta,M.tr(cob)))
        a3=[M.rank([[v[k] for j,v in enumerate(roots) if j!=i] for k in range(n)])==n for i in range(m)]
        assert all(a3)
        # Constructive surjectivity: a_(2i-1)=t_i, a_(2i)=0.
        lifts=[]
        for t in L:
            cochain=[x for ti in t for x in (ti,M.Z)]
            q=project(cochain)
            assert M.mv(Tau,q)==t
            lifts.append(q)
        ker=M.nullspace(Tau);ker_canonical=M.rref(ker)[0]
        S=[[M.cup_dw(x,y,repeated) for y in cc] for x in cc]
        assert S==M.decode(stored['S_gram'])
        assert cc==M.decode(stored['quotient_basis_coefficients'])
        assert M.rank(S)==d
        storedcurves={tuple(c['curve']):c for c in stored['curves']}
        cache={};tree_reports=[]
        for tree_index,curves in enumerate(trees):
            Ns=[];sign_bad_detected=False;scale_bad_detected=False
            for rawcurve in curves:
                curve=tuple(rawcurve);lo,hi=curve
                assert lo%2==1 and hi%2==0
                if curve not in cache:
                    T,N,operations=M.full_twist(lo,hi,repeated,B,project)
                    assert T==M.decode(storedcurves[curve]['T'])
                    assert N==M.decode(storedcurves[curve]['N'])
                    indices=range((lo-1)//2,hi//2)
                    Fe=[[M.sm(M.mul(roots[i][k],Tau[i][j]) for i in indices)
                         for j in range(d)] for k in range(n)]
                    edge_gram=M.mm(M.tr(Fe),M.mc(Fe))
                    lhs=M.mm(S,M.mc(N))
                    assert M.zero(M.ma(lhs,edge_gram)),(name,curve,'identity failure')
                    assert M.zero(M.mm(Tau,N)),(name,curve,'tau*N nonzero')
                    # Lemma 2, at cochain level, reconstructed independently from the full twist.
                    Ncols=[]
                    for j in range(d):
                        w=[Fe[k][j] for k in range(n)]
                        image=[]
                        for i,v in enumerate(roots):
                            coef=M.div(M.scale(M.inner(w,v),M.F(2)),M.inner(v,v)) if i in indices else M.Z
                            image.extend([coef,coef])
                        Ncols.append(project(image))
                    assert M.tr(Ncols)==N,(name,curve,'flux action not full twist')
                    sign_fail=not M.zero(M.ms(lhs,edge_gram))
                    fourG=[[M.scale(x,M.F(4)) for x in row] for row in edge_gram]
                    scale_fail=not M.zero(M.ma(lhs,fourG))
                    cache[curve]=(N,sign_fail,scale_fail)
                N,sbad,cbad=cache[curve];Ns.append(N)
                sign_bad_detected|=sbad;scale_bad_detected|=cbad
            I=M.independent_rows([col for N in Ns for col in M.tr(N)])
            assert M.rref(I)[0]==ker_canonical
            assert sign_bad_detected and scale_bad_detected
            entry_count=len(curves)*d*d
            total_occ+=len(curves)
            tree_reports.append({'tree_index':tree_index,'curves':len(curves),
              'identity_entries_checked':entry_count,'identity_mismatches':0,'tau_N_zero':True,
              'I_equals_kernel_tau':True,'wrong_sign_detected':sign_bad_detected,
              'tau_scaled_by_two_detected':scale_bad_detected,'flux_lemma_equals_full_twist':True})
        total_distinct+=len(cache)
        rec={'case_id':name,'roots_span_K_rank':M.rank(rootmap),'A3_all_roots_in_span_of_others':all(a3),
             'A3_checks':a3,'tau_K_rank':tau_rank,'kernel_tau_K_dimension':len(ker),
             'tau_annihilates_coboundaries':True,'tau_image_in_L':True,
             'explicit_surjective_lifts_pass':len(lifts),'tau_matrix':M.encode(Tau),
             'L_basis':M.encode(L),'kernel_tau_canonical_basis':M.encode(ker_canonical),
             'distinct_curves_rebuilt':len(cache),'trees':tree_reports}
        out['cases'].append(rec)
        print(name, 'tau rank',tau_rank,'A3',all(a3),'unique curves',len(cache),
              'identities',sum(t['identity_entries_checked'] for t in tree_reports),'PASS',flush=True)
    out['totals']={'tuples':4,'trees':12,'curve_occurrences':total_occ,
      'distinct_tuple_curve_pairs':total_distinct,'identity_entries_by_occurrence':total_occ*64,
      'distinct_identity_entries':total_distinct*64,'identity_mismatches':0,
      'A3_root_checks':40,'surjective_L_basis_lifts':16,'PASS':True}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out['totals'],indent=2),flush=True)
if __name__=='__main__':main()
