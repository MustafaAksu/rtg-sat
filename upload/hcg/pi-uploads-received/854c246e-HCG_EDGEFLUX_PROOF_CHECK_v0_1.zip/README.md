# HCG EDGEFLUX independent proof and post-commit exact audit

23 October 2026 — INTERNAL. No change to adopted HCG v0.1 or the Severn theorem status.

Read `HCG_EDGEFLUX_CHATGPT_PROOF_REVIEW_v0_1.md` first. The original theorem is checked in its explicit algebraic scope; the optional A3 weakening is a new ChatGPT session proposal, awaiting another reviewer.

## Reproduction

Requirements: Python 3.10+ and SymPy. No python-flint, Magma or SageMath required.

```sh
python -m pip install sympy
python replay.py
# Also rerun the full previous holdout audit:
python replay.py --full-prior
```

The package contains the **unaltered** previous full holdout verification ZIP (SHA-256 `702a4d6542f6b033284d2deef703282d9f123b78544afd186b9e05e59772fac3`) and Claude's postcheck ZIP as source evidence. The latter's code is not imported or executed by the independent check.

`replay.py` verifies the current manifest and the old manifest, extracts the old engine/inputs into a temporary directory, reconstructs the fresh quotient from roots, defines tau independently, reconstructs all 100 distinct Artin operators, and checks 204 curve occurrences / 13,056 identity entries. It checks coboundaries, surjectivity lifts, A3, tau*N, I=ker(tau), and wrong-sign/wrong-normalization controls. The optional `--full-prior` also replays the precommitted prediction comparison; no prediction bytes change.

The small A3-failure example is additional evidence for the separately proved weakening, not the proof itself.

The top-level SHA256SUMS manifest intentionally excludes itself. The archive hash is recorded in the delivery message/report, not recursively inside the ZIP.
