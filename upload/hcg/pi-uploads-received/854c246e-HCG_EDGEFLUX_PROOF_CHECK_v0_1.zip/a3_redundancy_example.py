#!/usr/bin/env python3
"""Exact small example: A1,A2 hold, A3 fails; conclusions remain valid.
A3 removal is justified separately by a general proof, not by this example.
"""
import sympy as s, json
from pathlib import Path
roots=[s.Matrix([1,0]),s.Matrix([1,1]),s.Matrix([1,1])]
n,m=2,3
R=s.Matrix.hstack(*roots);eye=s.eye(n)
ref=[eye-2*v*v.T/(v.dot(v)) for v in roots]
seen={tuple(eye)};stack=[eye]
while stack:
 g=stack.pop()
 for h in ref:
  q=g*h;k=tuple(q)
  if k not in seen:seen.add(k);stack.append(q)
assert len(seen)==8
# Nonorthogonal axes (1,0), (1,1) span V, so the finite reflection group is irreducible.
C=s.Matrix.hstack(*[c for v in roots for c in (v,-v)])
cob=s.Matrix([[(-2*v[k]/v.dot(v)) for v in roots for _ in range(2)] for k in range(n)]).T
Z=C.nullspace();allcols=list(cob.columnspace());qcols=[]
for z in Z:
 if s.Matrix.hstack(*(allcols+[z])).rank()>len(allcols):
  allcols.append(z);qcols.append(z)
B=s.Matrix.hstack(*qcols);assert B.shape==(6,2)
P=s.Matrix.hstack(B,cob)
def project(v):return P.gauss_jordan_solve(v)[0][:2,0]
Delta=s.Matrix([[1 if j==2*i else -1 if j==2*i+1 else 0 for j in range(6)] for i in range(3)])
tau=Delta*B
assert R*tau==s.zeros(2)
def cup(a,b):
 p=s.zeros(2,1);out=0
 for i,v in enumerate(roots):
  a0,a1=a[2*i:2*i+2];b0,b1=b[2*i:2*i+2]
  out+=(p.T*v)[0]*(b0-b1)+v.dot(v)*(a0*b0-2*a0*b1+a1*b1)/2
  p+=(a0-a1)*v
 assert p==s.zeros(2,1)
 return out
S=s.Matrix(2,2,lambda i,j:cup(B[:,i],B[:,j]));assert S.det()!=0
Ns=[]
for i,v in enumerate(roots):
 cols=[]
 for j in range(2):
  a=s.zeros(6,1);a[2*i]=a[2*i+1]=2*tau[i,j];cols.append(project(a))
 N=s.Matrix.hstack(*cols);Ns.append(N)
 Fe=v*tau[i,:]
 assert S*N+Fe.T*Fe==s.zeros(2)
I=s.Matrix.hstack(*Ns);tot=sum(Ns,s.zeros(2));assert tot.rank()==1
assert tau*I==s.zeros(3,6)
a3=[s.Matrix.hstack(*[v for j,v in enumerate(roots) if j!=i]).rank()==2 for i in range(3)]
assert a3==[False,True,True]
assert [N.rank() for N in Ns]==[0,1,1]
report={'group_order':len(seen),'root_span_rank':R.rank(),'A3_checks':a3,
 'quotient_dimension':B.cols,'tau_rank':tau.rank(),'S':str(S),
 'pair_N_ranks':[N.rank() for N in Ns],'common_image_dimension':I.rank(),
 'kernel_tau_dimension':len(tau.nullspace()),'sum_pair_N_rank':tot.rank(),
 'identity_all_pairs':True,
 'interpretation':'A3 guarantees each pair operator is nonzero; not necessary for total-image/full-rank conclusions.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
