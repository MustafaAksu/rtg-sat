#!/usr/bin/env python3
"""Validate this package and rerun its independent post-commit identity check.
Requires Python 3.10+ and SymPy. Does not import any Claude predictor/checker.
An additional --full-prior option runs the complete prior holdout replay too.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile,zipfile,shutil
ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--full-prior',action='store_true');a=ap.parse_args()
    for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
        h,name=line.split(None,1);p=(ROOT/name.strip()).resolve()
        if not p.is_relative_to(ROOT):raise RuntimeError('unsafe manifest path')
        if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise RuntimeError('hash mismatch '+name)
    print('PACKAGE MANIFEST PASS',flush=True)
    with tempfile.TemporaryDirectory(prefix='hcg_edgeflux_') as tmp:
        t=Path(tmp)
        with zipfile.ZipFile(ROOT/'HCG_H4_HOLDOUT_VERIFICATION_v0_1.zip') as z:
            for item in z.infolist():
                if not (t/item.filename).resolve().is_relative_to(t):raise RuntimeError('unsafe archive path')
            z.extractall(t)
        old=t/'HCG_H4_HOLDOUT_VERIFICATION_v0_1'
        for line in (old/'SHA256SUMS.txt').read_text().splitlines():
            h,name=line.split(None,1);p=(old/name.strip()).resolve()
            assert p.is_relative_to(old)
            assert hashlib.sha256(p.read_bytes()).hexdigest()==h,p
        print('PRIOR PACKAGE MANIFEST PASS',flush=True)
        if a.full_prior:
            subprocess.run([sys.executable,str(old/'replay.py')],check=True)
        dest=t/'fresh_identity_results.json'
        subprocess.run([sys.executable,str(ROOT/'check_tau_identity_independent.py'),
          '--audit-root',str(old),'--output',str(dest)],check=True)
        assert json.loads(dest.read_text())==json.loads((ROOT/'TAU_IDENTITY_RESULTS.json').read_text())
        shutil.copy2(ROOT/'a3_redundancy_example.py',t/'a3_redundancy_example.py')
        subprocess.run([sys.executable,str(t/'a3_redundancy_example.py')],check=True)
        assert json.loads((t/'a3_redundancy_example.json').read_text())==json.loads((ROOT/'a3_redundancy_example.json').read_text())
    print('FRESH POSTCHECK REPLAY PASS; byte-preserved inputs and scientific outputs agree.',flush=True)
if __name__=='__main__':main()
