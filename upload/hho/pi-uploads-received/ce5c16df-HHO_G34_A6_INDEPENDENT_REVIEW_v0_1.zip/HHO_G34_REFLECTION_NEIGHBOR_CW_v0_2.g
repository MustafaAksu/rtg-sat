# HHO, SESSION research-only / READ-ONLY CTblLib audit
# GAP 4.12+, CTblLib 1.3.7+
# Run: gap -q HHO_G34_REFLECTION_NEIGHBOR_CW_v0_2.g > HHO_G34_REFLECTION_NEIGHBOR_CW_v0_2_out.txt
# Does not modify repository files and does not invoke the shell or network.

if LoadPackage("ctbllib") <> true then
  Error("CTblLib is required");
fi;

HHO_G34_ReflectionAudit := function()
  local tab,irr,orders,sizes,blocks,mod5,chi,blockpos,bi,dm,ord,pos,scol,
        neighbours,near,reflectionClasses,refCount,j,tr,codim,m;
  tab := CharacterTable("6_1.U4(3).2_2");
  if tab = fail then Error("Character table missing"); fi;
  irr := Irr(tab);
  orders := OrdersClassRepresentatives(tab);
  sizes := SizesConjugacyClasses(tab);
  mod5 := tab mod 5;
  blocks := BlocksInfo(mod5);

  Print("TABLE=",Identifier(tab)," ORDER=",Size(tab),"\n");
  Print("LITERATURE_TOTAL_REFLECTIONS=126; expected single class size 126\n");

  for chi in [122..125] do
    if irr[chi][1] <> 6 then Error("Unexpected degree 6 candidate: ",chi); fi;
    blockpos := First([1..Length(blocks)],i -> chi in blocks[i].ordchars);
    if blockpos = fail then Error("p=5 block missing for character ",chi); fi;
    bi := blocks[blockpos];
    ord := bi.ordchars;
    dm := DecompositionMatrix(mod5,blockpos);
    pos := Position(ord,chi);
    if pos = fail then Error("Ordinary character not in its block"); fi;
    scol := Position(dm[pos],1);
    if scol = fail then Error("Expected leaf row not found"); fi;
    neighbours := Filtered([1..Length(ord)],i -> i<>pos and dm[i][scol]<>0);
    if Length(neighbours)<>1 then Error("Not a single Brauer-tree neighbour"); fi;
    near := ord[neighbours[1]];
    if irr[near][1]<>84 then Error("Neighbour character is not degree 84"); fi;

    reflectionClasses := Filtered([1..Length(orders)],
                  i -> orders[i]=2 and irr[chi][i]=4);
    refCount := Sum(reflectionClasses,i -> sizes[i]);
    Print("CHI_INDEX=",chi,
          " KERNEL_CLASSES=",ClassPositionsOfKernel(irr[chi]),
          " BLOCK=",blockpos,
          " BRAUER_NEIGHBOR_INDEX=",near,
          " REFLECTION_CLASS_INDICES=",reflectionClasses,
          " REFLECTION_CLASS_SIZES=",List(reflectionClasses,i->sizes[i]),
          " TOTAL_REFLECTION_CANDIDATES=",refCount,"\n");
    if Length(reflectionClasses)=1 and refCount=126 then
      Print("  REFLECTION_CLASS_CHECK=PASS (one class containing 126 reflections)\n");
    else
      Print("  REFLECTION_CLASS_CHECK=NOT ESTABLISHED by this candidate\n");
    fi;

    for j in reflectionClasses do
      tr := irr[near][j];
      codim := (84-tr)/2;
      m := -168 + 20*codim;
      Print("  CLASS=",j," SIZE=",sizes[j],
            " CHI6_TRACE=",irr[chi][j],
            " PSI84_INDEX=",near," PSI84_TRACE=",tr,
            " PSI84_MOVING_RANK=",codim,
            " M20=",m,"\n");
      if not IsInt(tr) or tr mod 2<>0 then
        Error("The involution trace is not an even integer");
      fi;
      if not IsInt(m) or m<12 or m mod 20<>12 then
        Error("Chevalley-Weil congruence/positivity failed");
      fi;
    od;
  od;
end;

HHO_G34_ReflectionAudit();
QUIT;
