"""HHO session: exact, standard-library proof checks for Addendum 6.

No GAP and no character table values are used. This verifies only the
mathematical consequences of the explicit one-reflection-class, order-two,
nontrivial-irreducible and genus-zero hypotheses.
"""
from pathlib import Path
import json

rank_reflection = 1
rank_representation = 6
target_parabolic_dimension = 8
r = (target_parabolic_dimension + 2 * rank_representation) // rank_reflection
assert r == 20
assert r * rank_reflection - 2 * rank_representation == target_parabolic_dimension

near_degree = 84
viable = []
for trace in range(-near_degree, near_degree + 1, 2):
    codim = (near_degree - trace) // 2
    m = -2 * near_degree + r * codim
    if m >= 0:
        assert m % 20 == 12
        assert m >= 12
        viable.append(dict(trace=trace,codim=codim,m=m))
assert len(viable) > 0
assert min(t['m'] for t in viable) == 12

# r-range tests are only arithmetically admissible; not group-realizable cases.
zero_cases = []
for t in range(3, 60):
    possible = []
    for trace in range(-84, 85, 2):
        codim = (84-trace)//2
        if -168 + t * codim == 0:
            possible.append(trace)
    if possible: zero_cases.append(t)
assert zero_cases == [3,4,6,7,8,12,14,21,24,28,42,56]

out = {
    'hypotheses':'genus-zero, 20 degree-6 reflection branches all in one conjugacy class',
    'target_multiplicity':target_parabolic_dimension,
    'forced_branch_count':r,
    'near_degree':near_degree,
    'congruence':'m84 = 672 - 10*x = 12 (mod 20) for x even',
    'lower_bound_for_nonnegative_m84':min(t['m'] for t in viable),
    'r_3_through_59_with_arithmetically_possible_zero_m84':zero_cases,
    'actual_trace':None,
    'actual_multiplicity':None,
    'gap_executed':False,
}
p=Path(__file__).with_name('HHO_G34_LEAF_VACUITY_EXACT_v0_1_results.json')
p.write_text(json.dumps(out,indent=2)+'\n')
print('EXACT ADDENDUM 6 CHECK PASS')
print(f'Rank-8 forces r={r}; m84 ≡ 12 (mod 20); nonnegative m84 >= 12')
print(f'Admissible r values with formal m84=0: {zero_cases}')
print('Actual 84-character trace not calculated (requires GAP/CTblLib)')
