#!/usr/bin/env python3
"""A compact explicit degree>1-neighbor counterexample to HHO-CONJ-NPL.
Group G=C3 × (C5 ⋊ C4), where a u a^-1 =u^2.
Target chi=omega ⊗ 1_G, neighbor psi=omega ⊗ rho4, rho4=Ind_C5^F20(zeta5).
All arithmetic combinatorial, standard library only.
"""
from collections import Counter
from fractions import Fraction
import json
# Representation data:
# on rho4, a is a 4-cycle, u is diagonal of primitive 5th roots.
# tuple: (omega,1)^5, (omega^2,1)^4, (omega^2,a), (1,a^-1), (1,u),(1,u^-1)
local=[]
local.extend([(1,'1')]*5)
local.extend([(2,'1')]*4)
local.extend([(2,'a'),(0,'a^-1'),(0,'u'),(0,'u^-1')])
assert len(local)==13
assert sum(j for j,_ in local)%3==0
assert [g for _,g in local if g!='1']==['a','a^-1','u','u^-1']
# F20 factors multiply to identity as written.
# (omega,1) and (1,u), (1,a) are generated, so image is full G.
# target chi sees omega^j; only ten nontrivial chi-branches.
cchi=[int(j!=0) for j,_ in local]
assert sum(cchi)==10
mchi=-2*1+sum(cchi)
assert mchi==8
h10=-1+sum(Fraction((3-j)%3,3) for j,_ in local if j!=0)
h01=-1+sum(Fraction(j,3) for j,_ in local if j!=0)
assert h10==h01==4,(h10,h01)
# neighbor psi=chi⊗rho4, where rho4(a) regular 4-cycle, rho4(u)
# has eigenvalues zeta5^1,zeta5^2,zeta5^3,zeta5^4.
# At a twisted by omega^2, none of the 4th-root eigenvalues equals omega.
cpsi=[]
for j,t in local:
    if t=='1':c=0 if j==0 else 4
    elif t=='a':
        assert j==2
        c=4
    elif t=='a^-1':
        assert j==0
        c=3
    elif t in ['u','u^-1']:
        assert j==0
        c=4
    else:raise ValueError(t)
    cpsi.append(c)
mpsi=-2*4+sum(cpsi)
assert sum(cpsi)==51 and mpsi==43
# C3 rank-one determinant (our target has only 5 omega & 5 omega²).
# (1-omega)(1-omega²)=3, hence det local =1/3^5.
raw_determinant=Fraction(1,3**5)
# This is a norm from Q(omega), since N(1-omega)=3.
assert mpsi%2==1 and mchi==8
out={'group':'C3 x (C5 semidirect C4), C4 acts on C5 by multiplication 2',
     'order':60,'inert_prime':5,'defect':1,
     'chi_degree':1,'psi_neighbor_degree':4,
     'brauer_tree':'star, 4 degree-1 leaves and 1 degree-4 central vertex',
     'number_of_all_branch_points':13,'number_chi_effective':10,
     'chi_local_exponents':dict(Counter(j for j,_ in local)),
     'chi_hodge_signature':[4,4], 'chi_parabolic_dimension':mchi,
     'psi_moving_rank_sum':sum(cpsi), 'psi_CW_multiplicity':mpsi,
     'parabolic_local_det':str(raw_determinant),
     'target_discriminant_class':'[1]',
     'neighbor_parity_predicted_class':'[5]',
     'NPL_refuted_without_D':True,
     'monodromy_tuple':[(int(j),g) for j,g in local]}
from pathlib import Path
Path(__file__).with_name('npl_counterexample.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
