#!/usr/bin/env python3
"""Complete HHO A8 reproduction using exact HCG engines and independent code.

Requires only Python standard library. Does not fetch network data, call GAP,
change original sources, or edit HCG/RTG adopted files.
"""
from pathlib import Path
from zipfile import ZipFile
from tempfile import TemporaryDirectory
from shutil import copy2
import os, sys, subprocess, hashlib, json
HERE=Path(__file__).resolve().parent

def h(b):return hashlib.sha256(b).hexdigest()

def run(program,workdir):
    env={**os.environ,'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1'}
    p=subprocess.run([sys.executable,program],cwd=workdir,env=env,text=True,capture_output=True,check=True)
    return p.stdout

# Check no file content was changed since packaging.
manifest=(HERE/'SHA256SUMS.txt').read_text().splitlines()
for line in manifest:
    sha,name=line.split('  ',1)
    assert h((HERE/name).read_bytes())==sha,name
print('PACKAGE MANIFEST',len(manifest),'PASS')

source=ZipFile(HERE/'SOURCE_HHO_C6_C3S3_TESTS_v0_1.zip')
source_files={name:source.read(name) for name in source.namelist()}
for line in source_files['SHA256SUMS.txt'].decode().splitlines():
    sha,name=line.split(None,1)
    assert h(source_files[name])==sha,name
print('SOURCE MANIFEST 7/7 PASS')

assert h((HERE/'generic_engine.py').read_bytes())=='66f2c253d7b8390858e9ca8cdf81b7b5579777721d7763e0d3b631be58fca505'
assert h((HERE/'cyclic_disc_claude.py').read_bytes())=='da76a25f57817fbeaf2b6deb749cda76cdefb5c8d59ec2d4b871a2778cf2afa9'

with TemporaryDirectory(prefix='hho_a8_replay_') as td:
    W=Path(td)
    for name in ('generic_engine.py','cyclic_disc_claude.py','independent_locality_audit.py',
                 'neighbor_parity_counterexample.py','verify_f20_counterexample.py'):
        copy2(HERE/name,W/name)
    copy2(HERE/'SOURCE_HHO_C6_C3S3_TESTS_v0_1.zip',W/'SOURCE_HHO_C6_C3S3_TESTS_v0_1.zip')
    for name in ('sweep.py','c3s3.py','c3s3_all.py'):
        (W/name).write_bytes(source_files[name])
    log=run('sweep.py',W)
    assert (W/'c6_sweep_r10.json').read_bytes()==source_files['c6_sweep_r10.json']
    print('C6 SWEEP JSON EXACT BYTE MATCH: 55 rows, 54 connected')
    assert run('c3s3_all.py',W).encode()==source_files['c3s3_all_out.txt']
    assert run('c3s3.py',W).encode()==source_files['c3s3_out.txt']
    print('C3xS3 REPLAY: 60/60, BYTE IDENTICAL')
    # Second method: exact local factors without importing either original engine.
    run('independent_locality_audit.py',W)
    assert (W/'independent_locality_audit.json').read_bytes()==(HERE/'independent_locality_audit.json').read_bytes()
    assert json.loads((W/'independent_locality_audit.json').read_text())['c3s3_locality_class_failures']==0
    print('INDEPENDENT LOCALITY ALGORITHM: 55 C6 AND 60 C3xS3 PASS')
    run('neighbor_parity_counterexample.py',W)
    assert (W/'npl_counterexample.json').read_bytes()==(HERE/'npl_counterexample.json').read_bytes()
    run('verify_f20_counterexample.py',W)
    assert (W/'f20_counterexample_verified.json').read_bytes()==(HERE/'f20_counterexample_verified.json').read_bytes()
    print('F20 CONNECTED COVER, p5 BRAUER TREE, NPL COUNTEREXAMPLE PASS')

for line in manifest:
    sha,name=line.split('  ',1)
    assert h((HERE/name).read_bytes())==sha,name
print('FULL FRESH REPLAY PASS; SOURCE ENGINES SHARED BUT LOCALITY AUDIT INDEPENDENT')
