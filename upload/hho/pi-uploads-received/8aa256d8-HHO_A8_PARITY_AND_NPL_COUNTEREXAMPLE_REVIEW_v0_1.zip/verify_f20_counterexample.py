#!/usr/bin/env python3
"""Fully independent rational/permutation audit of F20 neighbor-parity counterexample.
No CTblLib, GAP, or HCG engines. Standard-library arithmetic only.
"""
from fractions import Fraction
from collections import deque
from pathlib import Path
import json

p=5
# AGL_1(F5) elements (s,t): x -> s*x+t, s in F5^×.
def mul(x,y):return ((x[0]*y[0])%p, (x[0]*y[1]+x[1])%p)
I=(1,0);u=(1,1);u_inv=(1,4);a=(2,0);a_inv=(3,0)
assert mul(a,mul(u,a_inv))==mul(u,u)
assert mul(a,a_inv)==mul(u,u_inv)==I
# generated subgroup is full 20-element Frobenius group
G={I};frontier=[I]
while frontier:
 x=frontier.pop()
 for g in (u,a,u_inv,a_inv):
  y=mul(x,g)
  if y not in G:G.add(y);frontier.append(y)
assert len(G)==20
# Rational 4D standard representation of 5-point permutation action.
def std_matrix(g):
    s,t=g;perm=[(s*x+t)%5 for x in range(5)]
    return [[int(perm[i]==k)-int(perm[4]==k) for i in range(4)] for k in range(4)]
def rank(A):
    B=[[Fraction(x) for x in row] for row in A]; rr=0
    for c in range(len(B[0])):
        pivot=next((i for i in range(rr,len(B)) if B[i][c]),None)
        if pivot is None:continue
        B[rr],B[pivot]=B[pivot],B[rr]
        scale=B[rr][c];B[rr]=[x/scale for x in B[rr]]
        for i in range(len(B)):
            if i!=rr and B[i][c]:
                q=B[i][c];B[i]=[x-q*y for x,y in zip(B[i],B[rr])]
        rr+=1
    return rr
for g,expected in [(I,0),(u,4),(u_inv,4),(a,3),(a_inv,3)]:
    M=std_matrix(g)
    codim=rank([[int(i==j)-M[i][j] for j in range(4)] for i in range(4)])
    assert codim==expected,(g,codim,expected)
# Twisted by zeta3^2: no eigenvalue 1 on std(a) because eigenvalues are 4th roots.
# Check polynomial X^4-1 has no common root with X^2+X+1 in Q[X].
# Its coefficient matrix mod Q confirms the minimal polynomial of omega is
# disjoint from X^4-1, so twisted std(a) moving rank is 4.
# Compare the ordinary 4-dimensional Brauer character to 4 quotient linears.
# The restriction to the complement C4 is the regular representation:
chars=[sum(std_matrix(g)[i][i] for i in range(4)) for g in (I,a,mul(a,a),a_inv)]
assert chars==[4,0,0,0],chars
# Character degree count: four linear reps of C4 plus std4 => 4+16=20.
assert 4*1**2+4**2==len(G)

out={'presentation':'a*u*a^-1 = u^2, ord(a)=4, ord(u)=5',
 'F20_size':len(G),'std4_ranks_on_I_u_u^-1_a_a^-1':[0,4,4,3,3],
 'std4_C4_character_values':[4,0,0,0],
 'ordinary_degrees':[1,1,1,1,4],
 'p5_decomposition_matrix':[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1],[1,1,1,1]],
 'p5_brauer_tree':'star (4 leaves of degree 1 joined to one degree-4 center)',
 'chi_target_degree':1,'psi_neighbor_degree':4,
 'nontrivial_rank_psi_local':[4]*9+[4,3,4,4],
 'psi_multiplicity':43,'chi_multiplicity':8,
 'chi_signature':[4,4],'chi_discriminant_class':'[1]',
 'NPL_predicted_p5_parity':1, 'actual_p5_discriminant_parity':0}
assert sum(out['nontrivial_rank_psi_local'])==51
assert out['psi_multiplicity']==-8+sum(out['nontrivial_rank_psi_local'])
P=Path(__file__).with_name('f20_counterexample_verified.json')
P.write_text(json.dumps(out,indent=2)+'\n')
print('F20_GROUP_AND_BRAUER_TREE_AND_HODGE_COUNTEREXAMPLE_PASS')
