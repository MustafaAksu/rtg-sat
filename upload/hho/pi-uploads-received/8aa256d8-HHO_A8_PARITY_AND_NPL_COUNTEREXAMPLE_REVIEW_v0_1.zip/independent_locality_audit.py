#!/usr/bin/env python3
"""Independent exact K=Q(w) local determinant checks.
No import of the contributor's cyclic or parabolic engines.
Uses the previously verified parabolic determinant locality theorem as a hypothesis.
"""
from fractions import Fraction as F
from dataclasses import dataclass
from pathlib import Path
from collections import Counter
from zipfile import ZipFile
import ast, json

@dataclass(frozen=True)
class K:
    a:F=F(0)
    b:F=F(0)
    def __add__(x,y):return K(x.a+y.a,x.b+y.b)
    def __sub__(x,y):return K(x.a-y.a,x.b-y.b)
    def __mul__(x,y):return K(x.a*y.a-x.b*y.b, x.a*y.b+x.b*y.a-x.b*y.b)
    def __pow__(x,n):
        if n<0:return x.inv()**(-n)
        r=K(F(1))
        for _ in range(n):r=r*x
        return r
    def norm(x):return x.a*x.a-x.a*x.b+x.b*x.b
    def inv(x):
        n=x.norm();assert n
        c=K(x.a-x.b,-x.b)
        return K(c.a/n,c.b/n)
    def conj(x):return K(x.a-x.b,-x.b)
    def __truediv__(x,y):return x*y.inv()
    def __repr__(x):return f'K({x.a},{x.b})'
ONE=K(F(1));W=K(F(0),F(1));Z=ONE+W

def factor(n):
    n=abs(int(n)); out={}; q=2
    while q*q<=n:
        while n%q==0:
            n//=q;out[q]=out.get(q,0)+1
        q=3 if q==2 else q+2
    if n>1:out[n]=out.get(n,0)+1
    return out

def normclass(q):
    q=F(q)
    if q<0:return 'negative (not a norm)'
    facts=factor(q.numerator)
    for p,e in factor(q.denominator).items():facts[p]=facts.get(p,0)-e
    bad=sorted(p for p,e in facts.items() if p%3==2 and e%2)
    return '[1]' if not bad else '['+'*'.join(map(str,bad))+']'

def c6_local(e):return (ONE-Z**e).inv()

def c3s3_local(name):
    assert name.startswith('w^')
    a=int(name[2]); typ=name[3:]
    assert typ in ['1','r','r2','t','tr','tr2'],(name,typ)
    if typ=='1':
        assert a!=0
        return (ONE-W**a).inv()**2
    if typ in ('r','r2'):
        k={'r':1,'r2':2}[typ]
        out=ONE
        for e in ((a+k)%3,(a-k)%3):
            if e:out=out*(ONE-W**e).inv()
        return out
    # Scalar times an S3 transposition (all are unitary-conjugate).
    if a==0:return ONE           # 1-dimensional moving line, Gram 2, denominator 2
    return (ONE-W**(2*a)).inv()   # full moving 2-dimensional space

z=ZipFile(Path(__file__).with_name('SOURCE_HHO_C6_C3S3_TESTS_v0_1.zip'))
rows=json.loads(z.read('c6_sweep_r10.json'))
counts=Counter(); errors=[]; norm_ratios=set()
for ex,m,det_source,cls_source in rows:
    numerator=ONE
    for e in ex:numerator=numerator*c6_local(e)
    assert numerator.b==0,(ex,numerator)
    x=numerator.a
    cls=normclass(x)
    assert cls in ('[1]','[2]'),(ex,cls)
    predicted=cls
    if predicted!=cls_source:errors.append(('C6 class',ex,predicted,cls_source))
    if (m%2==1) != (cls_source=='[2]'):errors.append(('C6 parity',ex))
    ratio=F(det_source)/x
    norm_ratios.add(ratio)
    if normclass(ratio)!='[1]':errors.append(('C6 ratio not norm',ex,ratio))
    counts[(m,cls_source)]+=1
assert len(rows)==55 and not errors, errors
assert set(norm_ratios)=={F(81),F(243),F(324)},norm_ratios

records=[]
for ln in z.read('c3s3_all_out.txt').decode().splitlines()[2:]:
    records.append(ast.literal_eval(ln))
assert len(records)==60
c3_errors=[];detratios=set()
for labels,sig,ds,sourceclass in records:
    delta=ONE
    for g in labels:delta=delta*c3s3_local(g)
    if delta.b!=0:c3_errors.append(('nonrational',labels,delta));continue
    x=delta.a
    src=F(ds)
    ratio=src/x
    detratios.add(ratio)
    cl=normclass(x)
    if cl!=sourceclass:c3_errors.append(('class mismatch',labels,src,x,cl,sourceclass))
    if normclass(ratio)!='[1]':c3_errors.append(('ratio',labels,ratio))
assert not c3_errors,c3_errors[:2]
assert all(normclass(r)=='[1]' for r in detratios)
result={'c6_cases':len(rows),'c6_parity_failures':len(errors),'c6_det_ratio_norm_factors':sorted(map(str,norm_ratios)),
        'c6_class_by_m':sorted([[m,cl,n] for (m,cl),n in counts.items()]),
        'c3s3_cases':len(records), 'c3s3_signatures':dict((str(key),v) for key,v in Counter((tuple(x[1]),x[3]) for x in records).items()),
        'c3s3_locality_class_failures':len(c3_errors), 'c3s3_det_ratio_norm_factors':sorted(map(str,detratios))}
Path(__file__).with_name('independent_locality_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
