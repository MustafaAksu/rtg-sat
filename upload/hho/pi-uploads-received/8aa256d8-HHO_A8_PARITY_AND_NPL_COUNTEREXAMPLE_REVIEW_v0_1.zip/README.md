# HHO Addendum 8 independent review package

**Status:** Internal SESSION mathematics and reproducibility. Not an adopted HCG/RTG file or a human peer review.

Run `python replay.py` from the extracted directory (Python 3, standard library only). It verifies the SHA-256 manifests, restores the supplied user scripts **unchanged**, replays the original C6 and C3×S3 engines, checks frozen outputs, and independently computes local determinant factors with a separate exact rational-cyclotomic implementation. The C6 textual log has a nondeterministic elapsed time; the JSON output is byte-compared. The C3×S3 output is byte-compared.

## Included data

- `HHO_A8_PARITY_TESTS_AND_NPL_COUNTEREXAMPLE_v0_1.md`: full independent review, analytical C6 theorem, nonabelian split proof, and a connected explicit counterexample to unrestricted HHO-CONJ-NPL.
- `SOURCE_HHO_C6_C3S3_TESTS_v0_1.zip`: user's original archive, unmodified.
- `generic_engine.py`, `cyclic_disc_claude.py`: exact previously uploaded source engines with full SHA-256 checks in `replay.py`. They are included to make the original source scripts runnable; their replay is not counted as a new implementation.
- `independent_locality_audit.py`: independently implemented exact K=Q(ω) factors, comparing norm classes and norm-equivalent source determinants on all 55 C6 and all 60 C3×S3 source cases.
- `neighbor_parity_counterexample.py`, `verify_f20_counterexample.py`: independent combinatorial and affine-permutation proofs of the C3×F20 counterexample.
- `*.json`: frozen exact outputs of those checks.
- `SHA256SUMS.txt`: non-self-referential package manifest, generated only after all files are finalized.

**Crucial distinction:** The counterexample disproves unrestricted neighbor parity when χ has a kernel and sees fewer branch points than its Brauer neighbor. It does NOT disprove a faithful, all-branch-effective, or dominant version of the conjecture. None of the examples prove (L)+(D)⇒[1].
