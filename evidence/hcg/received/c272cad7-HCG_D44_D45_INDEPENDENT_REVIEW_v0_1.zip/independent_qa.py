#!/usr/bin/env python3
"""Independent arithmetic/log-consistency QA for Claude's degree-44/45 screen.
No GAP execution, no input code imports, and no character-table data fabricated.
"""
from pathlib import Path
from collections import Counter
import re, json, zipfile, hashlib
root=Path(__file__).resolve().parent
source_zip=root/'H3_D43_WEIL_REVIEW_CLAUDE_v0_1.zip'
with zipfile.ZipFile(source_zip) as z:
    s=z.read('gap/d44_45_screen_out.txt').decode('utf-8')
    manifest=z.read('BUNDLE_SHA256SUMS.txt').decode('utf-8')
    validated=0
    for line in manifest.splitlines():
        if not line.strip(): continue
        expected, name=line.split(maxsplit=1)
        name=name.strip().removeprefix('./')
        assert hashlib.sha256(z.read(name)).hexdigest()==expected, name
        validated+=1
    assert validated==9, validated
rows=[]
for line in s.splitlines():
    mm=re.match(r'^(.*?) d=(44|45) \|Z\|=(\d+) ind=(-?\d+) field=(.+?) inK=(true|false) minMovingRank=(\d+) -> (.*)$',line)
    if not mm: continue
    g,d,z,ind,field,inK,minc,verdict=mm.groups()
    d=int(d);minc=int(minc)
    if inK=='true':
        # rational FS = +/- 1, K-field FS = 0
        assert field in ('Rationals','CF(3)'), (g,field)
        threshold=6 if field=='Rationals' else 10
        assert minc>threshold and f'> {threshold}' in verdict, (g,d,minc,verdict)
    else:
        assert 'field not in K: excluded' in verdict
    rows.append({'group':g,'degree':d,'field':field,'rank_min':minc,'included_in_K':inK=='true','decision':verdict})
assert len(rows)==68, len(rows)
assert all('excluded' in x['decision'] for x in rows)
# Hiss-Malle corrected 2002 Table 2, ordinary-characteristic named entries;
# generic An and L2(q) families are handled separately.
ordinary={
    44:{'A11','U5(2)','M11','2.M12'},
    45:{'A8','A11','L3(4)','3.L3(4)','U4(2)','3_2.U4(3)','M11','M12','M22','3.M22','M23','M24'}
}
for d,names in ordinary.items():
    actual={r['group'] for r in rows if r['degree']==d and r['group'] in names}
    assert names==actual, (d,names-actual,actual-names)
# d=44 degree-44 modular-only entries in table = A12, 4_2.L3(4), M12, M23, M24
# d=45 modular-only entries = A8 (alternate +), L3(4) (+), 3_2.U4(3) (z3),
# M22 (+), 3.M22 (z3), M23 (+), M24 (+), J1, 3.McL, 3.O'N, A12.

def E(k,r): return 2*r+2*k*k-21*k+8

def T(r): return r-(r+1)//2
budget=[]
for d in (44,45):
    s=2*d+8
    for k in range(2,d+1):
        if d%k: continue
        r=d//k
        if r<6: continue
        budget.append({'d':d,'k':k,'r':r,'E_k':E(k,r),
                       'block_excluded_by_Aprime':k>=3 and E(k,r)<0})
    factor=[]
    for a in range(2,d+1):
        if a*a>d or d%a: continue
        b=d//a
        baseline=3*b+16*a
        if a==3 and 14<=b<=18:
            proof='three_pseudoreflection_lemma'
        elif baseline>s:
            proof='factorwise_rank_budget'
        else:
            proof='OPEN'
        factor.append((a,b,baseline,proof))
    assert all(f[3]!='OPEN' for f in factor)
    budget[-1]['tensor_cases']=[{'a':a,'b':b,'lower':lo,'proof':proof} for a,b,lo,proof in factor]
assert T(22)==11 and 2*(T(22)-1)==20>2*22-26==18
assert E(4,11)==-22
assert T(23)==11 and 2*(T(23)-1)==2*23-26==20

# Independently validate via cycle eigenvalue counting that a nontrivial scalar
# multiplying the standard S_{r+1} module attains T(r) at q=2 only (r=22,23).
for r in (22,23):
    n=r+1
    half=min(r,(n//2))
    assert r-half==T(r), (r,half)
    for q in (3,4,5,6,7,8,9,10):
        assert r-n//q>T(r), (r,q)

counts=Counter((x['degree'],x['included_in_K']) for x in rows)
out={'source_manifest':'9/9 PASS (verified separately)',
     'gap_log_verdict_lines':len(rows),'gap_log_verdicts_excluded':len(rows),
     'counts_by_dimension_and_field': {str(k):v for k,v in counts.items()},
     'hiss_malle_ordinary_char0_groups':{str(k):sorted(v) for k,v in ordinary.items()},
     'budgets':budget,
     'r22':{'E':18,'T':11,'minimum_nontrivial_scalar_excess':20,'finer_E4':-22},
     'r23':{'E':20,'T':11,'minimum_nontrivial_scalar_excess':20,'equality_scalar_order_2_only':True},
     'limitations':['Not an independent GAP character-table computation.',
                    'Primarily a source crosswalk and exact integer/logarithmic budget check.',
                    'Hiss-Malle generic families are checked against published formula; CTblLib output accepted as source-reported.']}
(root/'independent_qa_results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('D44-D45 SOURCE/ARITHMETIC QA PASS; 68/68 output verdicts; r22 and r23 checks PASS')
