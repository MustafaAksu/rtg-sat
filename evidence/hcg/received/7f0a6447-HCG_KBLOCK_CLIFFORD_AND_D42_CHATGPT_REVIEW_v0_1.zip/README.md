# HCG k-block/Clifford independent review replay

Scientific status: internal SESSION note. A′ and B are peer-reviewed in this report; the additional d=42 tensor exclusion is PROPOSED and needs independent peer audit. All mathematical source artifacts remain unmodified.

Files:
- `SOURCE_H3_KBLOCK_LEMMA_REVIEW_CLAUDE_v0_1.zip`: unmodified uploaded second-AI report and arithmetic package.
- `HCG_KBLOCK_CLIFFORD_CHATGPT_CROSS_AUDIT_v0_1.md`: independent detailed proof review and proposed d=42 lemma.
- `check_kblock_and_tensor_frontier.py`: bounded integer budget enumeration.
- `independent_budget_checks.json`: expected deterministic JSON output of the checker.
- `replay.py`: verifies source ZIP hashes and recomputes the independent JSON using the same stdlib script.
- `SHA256SUMS.txt`: hashes for all other files, excluding itself.

Run `python replay.py` in the extracted package. No network, unsafe deserialization, package installation, or execution of the untrusted source ZIP is needed. Mathematical proofs are written in the report, not established by the arithmetic enumerator.
