"""Bounded local replay with stdlib. Does not run source's code."""
import hashlib,json,subprocess,sys,zipfile,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h,fn=line.split('  ',1)
    assert hashlib.sha256((ROOT/fn).read_bytes()).hexdigest()==h,fn
print('PACKAGE MANIFEST PASS')
with zipfile.ZipFile(ROOT/'SOURCE_H3_KBLOCK_LEMMA_REVIEW_CLAUDE_v0_1.zip') as z:
    entries={name:z.read(name) for name in z.namelist()}
    for line in entries['BUNDLE_SHA256SUMS.txt'].decode().splitlines():
        h,n=line.split('  ',1)
        assert hashlib.sha256(entries[n]).hexdigest()==h,n
print('SOURCE MANIFEST 5/5 PASS')
expected=(ROOT/'independent_budget_checks.json').read_bytes()
with tempfile.TemporaryDirectory() as td:
    q=Path(td)
    (q/'check_kblock_and_tensor_frontier.py').write_bytes((ROOT/'check_kblock_and_tensor_frontier.py').read_bytes())
    p=subprocess.run([sys.executable,str(q/'check_kblock_and_tensor_frontier.py')],cwd=q,capture_output=True,text=True,check=True)
    assert p.stdout.strip().startswith('PASS'),p.stdout
    assert (q/'independent_budget_checks.json').read_bytes()==expected
print('FRESH INDEPENDENT BUDGET REPLAY PASS')
