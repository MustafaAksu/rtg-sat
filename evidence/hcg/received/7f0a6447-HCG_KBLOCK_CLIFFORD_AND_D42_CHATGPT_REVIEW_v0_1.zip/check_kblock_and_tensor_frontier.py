"""Independent, bounded integer-budget reproduction for the Clifford and d=42 arguments.
This script does not verify the Clifford theorem, the Hodge/Shapiro step,
or the projective-reflection lemma. Those have written proofs in the report.
"""
import json
from pathlib import Path

OUT=Path(__file__).parent
budget_rows=[]
for d in range(26,43):
    for k in range(3,d+1):
        if d % k: continue
        r=d//k
        if r<6: continue
        E=2*r + 2*k*k -21*k +8
        budget_rows.append({'d':d,'k':k,'r':r,'E_k':E})
assert budget_rows
assert all(row['E_k']<0 for row in budget_rows), budget_rows

scalar_rows=[]
for r in range(13,23):
    E=2*r-26
    T=r-(r+1)//2
    scalar_rows.append({'r':r,'d':2*r,'E':E,'T':T,'minimum_scalar_excess':2*(T-1)})
assert all(row['E']<row['minimum_scalar_excess'] for row in scalar_rows)

factorwise=[]
for a in range(2,8):
    for b in range(a,43):
        if a*b>42: continue
        if 2*a*b+8 >= 3*b+16*a:
            factorwise.append((a,b))
assert factorwise==[(3,14)],factorwise

# d=42, tensor 3 x 14, N_effective >= 19.
# If t local projective A images are nontrivial: movement >=14 each;
# for N-t projectively trivial A images, movement >=3 each.
feasible=[]
for N in range(19,47):
    for t in range(3,N+1):
        minimum=14*t+3*(N-t)
        if minimum<=92:
            feasible.append({'N':N,'t':t,'minimum':minimum,'slack':92-minimum})
assert feasible==[{'N':19,'t':3,'minimum':90,'slack':2}],feasible

out={
    'k_ge_3':budget_rows,
    'scalar_r_13_22':scalar_rows,
    'factorwise_d_le_42':factorwise,
    'd42_3x14_feasible_projective_activity':feasible,
    'source_limitations': 'Integer inequalities only; structural Clifford, unitary triple-reflection and Hodge arguments proved in companion note.'
}
p=(OUT/'independent_budget_checks.json')
p.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print('PASS', len(budget_rows),'k>=3 shapes;',len(scalar_rows),'scalar cases; d=42 one activity pattern')
