from pathlib import Path
import json

shapes = {
    26:[(2,13)],
    28:[(2,14)],
    30:[(2,15)],
    32:[(2,16)],
    33:[(3,11)],
    34:[(2,17)],
    35:[(5,7)],
    36:[(2,18),(3,12),(4,9),(6,6)],
    38:[(2,19)],
    39:[(3,13)],
    40:[(2,20),(4,10),(5,8)],
    42:[(2,21),(3,14),(6,7),(7,6)],
}

def multiblock_slack(k,r):
    return 2*r + 2*k*k - 21*k + 8

def scalar_threshold(r):
    return r - ((r+1)//2)

rows=[]
for d, ss in shapes.items():
    for k,r in ss:
        rows.append({
            "d":d,"k":k,"r":r,
            "multiblock_slack":multiblock_slack(k,r),
            "multiblock_impossible": (k>=3 and multiblock_slack(k,r)<0),
        })

two=[]
for r in range(13,22):
    E=2*r-26
    T=scalar_threshold(r)
    two.append({
        "r":r,"d":2*r,"E":E,"T":T,
        "min_excess_if_scalar_nontrivial":2*(T-1),
        "scalar_character_forced_trivial":E < 2*(T-1),
    })

Path("two_block_extension_results.json").write_text(json.dumps({"multiblock":rows,"two_block_scalar":two},indent=2,sort_keys=True)+"\n")
assert all(x["scalar_character_forced_trivial"] for x in two)
for x in rows:
    if x["k"]>=3 and x["d"]<=42:
        assert x["multiblock_impossible"], x
print("ALL EXACT INEQUALITY CHECKS PASS")
