"""Exact combinatorial probe of G34 756-vector/126-line intermediate covers.

Input: unchanged JSON from auditor round1/outputs/finite_root_orbit.json.
No external libraries and no external code execution. The orbit and generator
permutations are independently *counted* here, not reconstructed from matrices.
"""
import hashlib
import json
from collections import deque
from pathlib import Path

DIR = Path(__file__).resolve().parent
source = (DIR / 'G34_756_VECTOR_ORBIT_ORIGINAL.json').read_bytes()
obj = json.loads(source)
orb, generators = obj['orbit'], obj['generator_permutations']
D = len(orb)
assert D == 756 and len(generators) == 10
assert all(len(g) == D and sorted(g) == list(range(D)) for g in generators)
assert all(all(g[g[i]] == i for i in range(D)) for g in generators)

# Check the orbit is transitive under the ten displayed generating involutions.
seen = {0}; queue=deque([0])
while queue:
    x=queue.popleft()
    for g in generators:
        y=g[x]
        if y not in seen:
            seen.add(y); queue.append(y)
assert len(seen) == D

# Coordinates in Z[w]/(w^2+w+1). Six units acting by scalar multiplication.
units=((1,0),(-1,0),(0,1),(0,-1),(-1,-1),(1,1))
def mul(x,y):
    a,b=x;c,d=y
    return (a*c-b*d,a*d+b*c-b*d)
def line_key(v):
    return min(tuple(mul(tuple(z),u) for z in v) for u in units)
keys=[line_key(v) for v in orb]
line_reps=sorted(set(keys))
assert len(line_reps)==126
line_ids={v:i for i,v in enumerate(line_reps)}
vec_to_line=[line_ids[v] for v in keys]
assert all(vec_to_line.count(j)==6 for j in range(126))

# Descend each of the ten 756-point involutions to 126 projective lines.
line_generators=[]
for g in generators:
    p=[None]*126
    for i,j in enumerate(g):
        a,b=vec_to_line[i],vec_to_line[j]
        if p[a] is not None: assert p[a]==b
        else: p[a]=b
    assert all(j is not None for j in p)
    assert sorted(p)==list(range(126))
    assert all(p[p[i]]==i for i in range(126))
    line_generators.append(p)

def fixed_and_transpositions(p):
    fixed=sum(i==j for i,j in enumerate(p))
    return fixed,(len(p)-fixed)//2
vector_cycles=[fixed_and_transpositions(p) for p in generators]
line_cycles=[fixed_and_transpositions(p) for p in line_generators]
assert all(x==(270,243) for x in vector_cycles)
assert all(x==(46,40) for x in line_cycles)

# The paired W5 tuple consists of each of the ten involutions twice.
# Riemann-Hurwitz: 2g-2 = -2D + sum_{20 local} #(2-cycles).
ram_vec=2*sum(t for _,t in vector_cycles)
ram_line=2*sum(t for _,t in line_cycles)
assert (-2*756+ram_vec)%2==0
assert (-2*126+ram_line)%2==0
g_vec=1-756+ram_vec//2
g_line=1-126+ram_line//2
assert (g_vec,g_line)==(1675,275)

group_order=39191040
assert group_order%756==0 and group_order//756==51840

# Scalar w multiplication maps each orbit vector to one of the other six
# members of its line; on lines it acts trivially. Central scalar membership
# in G34 is an external group-theoretic input, not proved by this script.
by_vec={tuple(map(tuple,v)):i for i,v in enumerate(orb)}
scalar=[]
for v in orb:
    scalar.append(by_vec[tuple(mul(tuple(z),(0,1)) for z in v)])
assert all(vec_to_line[scalar[i]]==vec_to_line[i] for i in range(756))
assert all(scalar[scalar[scalar[i]]]==i for i in range(756))
assert all(g[scalar[i]]==scalar[g[i]] for g in generators for i in range(756))

out={
  'input_sha256':hashlib.sha256(source).hexdigest(),
  'generator_count':10,
  'vector_orbit_transitive':len(seen)==756,
  'vector_degree':756,
  'vector_fixed_and_transpositions':vector_cycles,
  'vector_genus_for_20_paired_involutions':g_vec,
  'vector_stabilizer_order_using_known_G34_order':group_order//756,
  'projective_line_degree':126,
  'projective_line_fixed_and_transpositions':line_cycles,
  'projective_line_genus_for_20_paired_involutions':g_line,
  'scalar_w_action_has_order_3_commutes_and_is_trivial_on_lines':True,
  'evidence_limit':'Input orbit/permutations taken from audited certificate; no independent derivation of 756 permutations from six-by-six matrices in this script.'
}
(DIR/'results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS: vector degree=756, 20-branch genus=1675; line degree=126, genus=275.')
print('PASS: 10 involutions, transitivity, unit-scaling compatibility, central order-three candidate.')
