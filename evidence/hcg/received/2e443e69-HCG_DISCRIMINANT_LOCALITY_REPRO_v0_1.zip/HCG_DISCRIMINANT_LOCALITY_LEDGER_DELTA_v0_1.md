# HCG — Proposed delta: local determinant and d=6 exclusion

**Date:** 2026-10-29. INTERNAL / SESSION. No PI acceptance entered; no adopted DSN modified.

| Proposed record / existing topic | Grade and review scope | Obligation |
|---|---|---|
| HCG-THM-PARABOLIC-DISC-LOCALITY (proposed identifier) | THM as a written implication under explicit hypotheses; PROPOSED review state | Independent audit of triangular cochain determinant proof |
| HCG-ALG-G34-RANK2-LOCAL (proposed identifier) | Exact 126-line/7,875-pair census plus Steinberg stabilizer theorem; PROPOSED | Peer verify all rank-two elements, not only sampled products |
| HCG-COR-D6-NONSPLIT-NOGO (proposed identifier) | PROPOSED conditional corollary | Requires the preceding two items and the existing d=6 screen/polarization bridge |
| Delta27 scan evidence | Source replay 7 paired + 9 merged cases; independent 320 sampled G333/G313 cases | W6/W7 root inputs not accessible in this turn |
| Source sample-count correction | 160 G333 + 160 G313 for the submitted version, not 120 + 480 | Preserve original note; add dated correction |
| HCG-OPEN-NONSPLIT8 | OPEN | Consider d>=7 after peer acceptance of d=6 exclusion |

Existing Severn Theorems A/B/C stay CLAIMED. No novelty claim is assigned to the local formula. The reduction's monomial exclusion and the cup-to-actual-polarization identification retain their own source dependencies.
