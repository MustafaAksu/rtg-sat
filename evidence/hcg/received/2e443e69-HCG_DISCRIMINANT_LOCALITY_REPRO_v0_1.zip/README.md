# HCG local discriminant proof and exact replay package

Date: 2026-10-29. Internal, noncanonical. Read the review and proof note before changing any scientific status.

## Main deliverables

- `HCG_PARABOLIC_DISCRIMINANT_LOCALITY_PROOF_v0_1.md`: complete proposed determinant proof and G34 d=6 consequence.
- `HCG_DISCRIMINANT_LOCALITY_CHATGPT_REVIEW_v0_1.md`: finite replay, sample-count corrections, evidence limitations.
- `HCG_DISCRIMINANT_LOCALITY_LEDGER_DELTA_v0_1.md`: proposed records only.
- `source/`: received originals and the previously delivered `generic_engine.py`, unchanged.
- `inputs/`: seven recoverable root tuples. W6/W7 are absent and are explicitly NOT counted as replayed.
- `scripts/`: path-only adapters plus four independent implementations.
- `expected/`: deterministic JSON reference outputs; `outputs/` includes original-turn logs and outputs.

## Replay

Use Python 3 and SymPy. The independent exact field and cohomology calculations use only the standard library. SymPy is used for the faithful permutation group's order, not floating-point linear algebra.

```
python replay.py
```

The script first verifies `SHA256SUMS.txt`, then works in a fresh temporary directory, runs the sampling census, all independent determinant tests, all 320 sampled tuples, and the rank-two root census. All four scientific JSON outputs must match byte-for-byte.

```
python replay.py --source-replay
```

This additionally reruns the producer's scripts with only path/import changes, checking the available G34 rows and the supplied G313 log. The original mathematical source code is preserved under `source/`.

## Scope

The root/cochain data are shared input evidence. The independent arithmetic engine does not import Claude's engine. The 320-case counts refer to the supplied script revision, not 600 cases claimed in prose. The general theorem is supported by a written proof; sample checks are not its proof. The rank-two G34 consequence also uses the classical Steinberg point-stabilizer theorem and the previously identified G34 representation. The geometric polarization comparison remains an explicit source dependency when interpreting the cup discriminant as an abelian factor's discriminant.

No PDF source is bundled: current Severn-v2 download attempts failed. The proof does not assume the unpublished “Theorem W”. External sources and actual reading extent are listed in the proof note.
