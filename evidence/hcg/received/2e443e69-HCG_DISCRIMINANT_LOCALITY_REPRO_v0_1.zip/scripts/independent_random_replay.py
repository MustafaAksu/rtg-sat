#!/usr/bin/env python3
"""Recompute all 320 actual accepted samples using independently written field/quotient code.
Inputs are deterministic sample indices recovered from the source sampler, not producer cup matrices.
"""
from local_determinant_independent import *
import json,itertools,collections,time
B=Path(__file__).resolve().parents[1]
samples=json.loads((B/'outputs/source_sampler_counts.json').read_text())
def wp(a):
 t=U
 for _ in range(a%3):t=mul(t,W)
 return t
out={}; start=time.monotonic()
for group in ['G333','G313']:
 refs=[];cls=[]
 for i,j in itertools.combinations(range(3),2):
  for a in range(3):
   M=eye(3);M[i][i]=M[j][j]=Z;M[i][j]=wp(a);M[j][i]=wp(-a);refs.append(M);cls.append(0)
 if group=='G313':
  for i in range(3):
   for a in (1,2):M=eye(3);M[i][i]=wp(a);refs.append(M);cls.append(a)
 rows=[];previous=set(); hist=collections.Counter()
 for batch in samples[group]['samples']:
  for j,idx in enumerate(batch['accepted_indices']):
   typ=tuple(sorted(cls[i] for i in idx));full=typ not in previous;previous.add(typ)
   result=parabolic_check([refs[i] for i in idx],full_block=full)
   hdim=result['H_dimension']; negdim=F(-3)+sum(F(1,2) if cls[i]==0 else (F(2,3) if cls[i]==1 else F(1,3)) for i in idx)
   assert negdim.denominator==1
   negdim=int(negdim);expected_sign=(-1)**negdim
   assert result['class']['sign']==expected_sign
   assert not result['class']['inert_odd_primes']
   rows.append({'N':batch['N'],'sample':j,'reflection_indices':idx,'classes':list(typ),'det_h':result['det_h'],'determinant_class':result['class'],'locality_identity_pass':True,'full_block_check':full})
   hist[(batch['N'],typ,str(result['class']))]+=1
  print(group,'N',batch['N'],'computed',len(batch['accepted_indices']),'elapsed',round(time.monotonic()-start,2),flush=True)
 out[group]={'count':len(rows),'tuples':rows,'summary':[{'N':N,'classes':list(c),'class':cl,'count':v} for (N,c,cl),v in sorted(hist.items())]}
(B/'outputs/independent_random_320.json').write_text(json.dumps(out,indent=2)+'\n')
print('320/320 INDEPENDENT EXACT QUOTIENT AND LOCALITY CHECKS PASS')
