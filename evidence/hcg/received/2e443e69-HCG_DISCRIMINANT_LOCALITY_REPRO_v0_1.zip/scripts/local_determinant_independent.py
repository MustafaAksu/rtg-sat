#!/usr/bin/env python3
"""Independent exact K=Q(w) linear algebra and parabolic discriminant test.
No import of the producer's generic_engine. h is linear in the first argument.
"""
from fractions import Fraction as F
from pathlib import Path
import json,itertools
Z=(F(0),F(0)); U=(F(1),F(0)); W=(F(0),F(1)); TH=(F(1),F(2))
def k(x=0,y=0):return (F(x),F(y))
def add(x,y):return (x[0]+y[0],x[1]+y[1])
def neg(x):return (-x[0],-x[1])
def sub(x,y):return (x[0]-y[0],x[1]-y[1])
def mul(x,y):return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]-x[1]*y[1])
def con(x):return (x[0]-x[1],-x[1])
def inv(x):
 q=x[0]**2-x[0]*x[1]+x[1]**2
 if not q:raise ZeroDivisionError
 c=con(x);return (c[0]/q,c[1]/q)
def div(x,y):return mul(x,inv(y))
def sm(xs):
 r=Z
 for x in xs:r=add(r,x)
 return r
def norm(x):return mul(x,con(x))[0]
def eye(n):return [[U if i==j else Z for j in range(n)] for i in range(n)]
def trans(A):return list(map(list,zip(*A))) if A else []
def adj(A):return [[con(x) for x in r] for r in trans(A)]
def mm(A,B):
 BT=trans(B)
 return [[sm(mul(x,y) for x,y in zip(a,b) if x!=Z and y!=Z) for b in BT] for a in A]
def mv(A,x):return [sm(mul(y,z) for y,z in zip(a,x) if y!=Z and z!=Z) for a in A]
def ms(A,B):return [[sub(x,y) for x,y in zip(a,b)] for a,b in zip(A,B)]
def ma(A,B):return [[add(x,y) for x,y in zip(a,b)] for a,b in zip(A,B)]
def scal(t,A):return [[mul(t,x) for x in r] for r in A]
def va(a,b):return [add(x,y) for x,y in zip(a,b)]
def vs(a,b):return [sub(x,y) for x,y in zip(a,b)]
def vm(t,a):return [mul(t,x) for x in a]
def inner(a,b,H):return sm(mul(mul(a[i],H[i][j]),con(b[j])) for i in range(len(a)) for j in range(len(b)) if a[i]!=Z and H[i][j]!=Z and b[j]!=Z)
def rr(A):
 a=[r[:] for r in A];piv=[];r=0
 if not a:return a,piv
 for c in range(len(a[0])):
  i=next((i for i in range(r,len(a)) if a[i][c]!=Z),None)
  if i is None:continue
  a[r],a[i]=a[i],a[r];q=inv(a[r][c]);a[r]=[mul(q,x) for x in a[r]]
  for j in range(len(a)):
   if j!=r and a[j][c]!=Z:
    v=a[j][c];a[j]=[sub(x,mul(v,y)) for x,y in zip(a[j],a[r])]
  piv.append(c);r+=1
  if r==len(a):break
 return a,piv
def rk(A):return len(rr(A)[1]) if A else 0
def ker(A,n=None):
 if n is None:n=len(A[0])
 a,p=rr(A);out=[]
 for j in range(n):
  if j in p:continue
  v=[Z]*n;v[j]=U
  for i,c in enumerate(p):v[c]=neg(a[i][j])
  out.append(v)
 return out
def solve(A,b):
 n=len(A[0]); R,p=rr([a+[y] for a,y in zip(A,b)])
 if n in p:raise ValueError('inconsistent')
 x=[Z]*n
 for i,c in enumerate(p):x[c]=R[i][-1]
 return x
def det(A):
 a=[r[:] for r in A];D=U;n=len(a)
 for j in range(n):
  i=next((i for i in range(j,n) if a[i][j]!=Z),None)
  if i is None:return Z
  if i!=j:a[i],a[j]=a[j],a[i];D=neg(D)
  D=mul(D,a[j][j]);d=inv(a[j][j])
  for i in range(j+1,n):
   if a[i][j]!=Z:
    t=mul(a[i][j],d)
    for c in range(j+1,n):a[i][c]=sub(a[i][c],mul(t,a[j][c]))
    a[i][j]=Z
 return D
def inverse(A):return trans([solve(A,e) for e in eye(len(A))])
def image(M):
 _,p=rr(M);return [[M[i][j] for i in range(len(M))] for j in p]
def norm_class(q):
 q=F(q)
 if not q:raise ValueError('zero determinant')
 s=-1 if q<0 else 1;q=abs(q);odd=[]
 for n in (q.numerator,q.denominator):
  p=2
  while p*p<=n:
   v=0
   while n%p==0:n//=p;v+=1
   if v%2 and p%3==2:odd.append(p)
   p+=1
  if n>1 and n%3==2:odd.append(n)
 return {'sign':s,'inert_odd_primes':sorted(odd)}
def reflect(v,H=None):
 if H is None:H=eye(len(v))
 q=inner(v,v,H);row=mv(H,[con(x) for x in v]);f=div(k(2),q)
 return [[sub(U if i==j else Z,mul(f,mul(v[i],row[j]))) for j in range(len(v))] for i in range(len(v))]
def local_product(gs,H=None):
 d=len(gs[0]);H=H or eye(d);prod=U;local=[]
 for g in gs:
  M=ms(eye(d),g);E=image(M);c=len(E)
  HE=[[inner(v,w,H) for w in E] for v in E]
  A=trans(E)
  ME=trans([solve(A,mv(M,v)) for v in E]) if c else []
  dh=det(HE);dt=det(ME);f=div(dh,dt)
  prod=mul(prod,f);local.append({'c':c,'hdet':[str(x) for x in dh],'one_minus_g_det':[str(x) for x in dt]})
 return prod,local

def parabolic_check(gs,H=None,full_block=True):
 d=len(gs[0]);r=len(gs);H=H or eye(d);P=eye(d);Qs=[];Es=[];Ls=[]
 for g in gs:
  assert mm(mm(trans(g),H),[[con(x) for x in row] for row in g])==H,'not unitary'
  Qs.append(P);P=mm(P,g)
  E=image(ms(eye(d),g));Es.append(E)
  # a preimage for every moving basis vector; choosing arbitrary complements is enough
  Ls.append([solve(ms(eye(d),g),v) for v in E])
 assert P==eye(d)
 cols=[mv(Q,v) for Q,E in zip(Qs,Es) for v in E];C=trans(cols);R=len(cols)
 assert rk(C)==d,'nonzero common fixed space: theorem assumes none'
 # Full triangular form B on the cochain moving space, not just its closed subspace.
 labels=[(i,j) for i,E in enumerate(Es) for j in range(len(E))]
 B=[[Z]*R for _ in range(R)]
 for a,(i,ia) in enumerate(labels):
  for b,(j,ib) in enumerate(labels):
   if i==j:B[a][b]=inner(Ls[i][ia],Es[j][ib],H)
   elif i<j:B[a][b]=inner(cols[a],cols[b],H)
 assert ma(B,adj(B))==mm(mm(trans(C),H),[[con(x) for x in row] for row in C])
 D=[]
 for e in eye(d):
  row=[]
  for g,E in zip(gs,Es):
   if E:row.extend(solve(trans(E),mv(ms(g,eye(d)),e)))
  D.append(row)
 assert rk(D)==d and all(x==Z for row in mm(C,trans(D)) for x in row)
 closed=ker(C);cur=D[:];QH=[];rank=d
 for z in closed:
  if rk(cur+[z])>rank:cur.append(z);QH.append(z);rank+=1
 q=len(QH);assert q==R-2*d and q%2==0
 S=mm(mm(QH,B),adj(QH));assert ma(S,adj(S))==[[Z]*q for _ in range(q)]
 assert det(S)!=Z
 hp=scal(TH,S);dh=det(hp);assert dh[1]==0
 lp,locals_=local_product(gs,H);assert lp[1]==0
 # relation det(h_par) = theta^(2n) local-product, modulo norms
 theta_pow=U
 for _ in range(q):theta_pow=mul(theta_pow,TH)
 model=mul(theta_pow,lp); ratio=div(dh,model)
 assert ratio[1]==0 and norm_class(ratio[0])=={'sign':1,'inert_odd_primes':[]}
 result={'coefficient_dimension':d,'cochain_dimension':R,'H_dimension':q,'det_h':str(dh[0]),'class':norm_class(dh[0]),'local_determinant_product':str(lp[0]),'predicted_representative':str(model[0]),'ratio_norm_class':norm_class(ratio[0]),'local_factors':locals_}
 if full_block:
  Urows=[solve(C,e) for e in eye(d)]
  X=D+QH+Urows;assert rk(X)==R
  BA=mm(mm(X,B),adj(X))
  assert BA[:d]==[[Z]*d+[Z]*q+[neg(x) for x in H[i]] for i in range(d)]
  assert det(BA)==mul(det(S),mul(det(H),det(H)))
  assert det(BA)==mul(k(norm(det(X))),det(B))
  assert det(B)==lp
  result.update({'adapted_basis_det_norm':str(norm(det(X))),'full_triangular_det_exact':True,'block_determinant_identity':True,'basis_change_identity':True})
 return result

def roots_for(label):
 base=Path(__file__).resolve().parents[1]
 a=json.loads((base/'inputs'/f'{label}_roots.json').read_text())
 if isinstance(a,dict):
  for key in ['generating_reflection_roots','roots','root_vectors','final_roots']:
   if key in a:a=a[key];break
 return [[k(*x) for x in row] for row in a]

def main():
 B=Path(__file__).resolve().parents[1];res={}
 for label in ['W5','NEW01','NEW02','NEW03','NEW04','BLOCK-01','ESCAPE']:
  s=[reflect(v) for v in roots_for(label)];gs=[g for x in s for g in (x,x)]
  res[label]=parabolic_check(gs,full_block=(label=='W5'))
  print(label,res[label]['det_h'],res[label]['class'],flush=True)
 s=[reflect(v) for v in roots_for('W5')]
 for i in range(9):
  gs=[]
  for j,g in enumerate(s):
   if j==i:gs.extend([g,mm(g,s[j+1])])
   elif j==i+1:gs.append(g)
   else:gs.extend([g,g])
  lab=f'W5_merge_{i+1}_{i+2}';res[lab]=parabolic_check(gs,full_block=False)
  print(lab,res[lab]['det_h'],res[lab]['class'],flush=True)
 # rank-one nonsplit and split controls, with faithful C6 exponents
 z6=add(U,W)
 def power(x,j):
  v=U
  for _ in range(j):v=mul(v,x)
  return v
 for lab,root,exp in [('C6_nonsplit',z6,[2]*5+[3]+[4]*3+[5]),('C3_split',W,[1]*5+[2]*5)]:
  res[lab]=parabolic_check([[[power(root,j)]] for j in exp]); print(lab,res[lab]['det_h'],res[lab]['class'],flush=True)
 # negative controls: deleting local norm data may accidentally work in special cases;
 # a missing (-1)^n sign fails for dimH=2.
 res['odd_n_sign_control']=parabolic_check([[[W]],[[W]],[[con(W)]],[[con(W)]]]);assert res['odd_n_sign_control']['class']['sign']==-1
 (B/'outputs/independent_locality_exact.json').write_text(json.dumps(res,indent=2)+'\n')
 print('ALL INDEPENDENT LOCALITY IDENTITIES PASS')
if __name__=='__main__':main()
