#!/usr/bin/env python3
"""Reproduce source sampler with independent exact monomial representation; no cup engine.
Original accepts up to 80 tuples per N, NOT 80 per local-class multiset.
"""
import itertools,random,collections,json
from pathlib import Path
B=Path(__file__).resolve().parents[1]
ID=((0,1,2),(0,0,0))
def mul(x,y):
 p,a=x;q,b=y
 return tuple(q[p[i]] for i in range(3)),tuple((a[i]+b[p[i]])%3 for i in range(3))
def inv(x):
 p,a=x;q=[0]*3;b=[0]*3
 for i in range(3):q[p[i]]=i;b[p[i]]=-a[i]%3
 return tuple(q),tuple(b)
def closure(gs):
 seen={ID};queue=[ID]
 for x in queue:
  for g in gs:
   y=mul(x,g)
   if y not in seen:seen.add(y);queue.append(y)
 return seen
all_results={}
for kind in ['G333','G313']:
 refs=[];classes=[]
 for i,j in itertools.combinations(range(3),2):
  for k in range(3):
   p=list(range(3));p[i],p[j]=j,i;a=[0]*3;a[i]=k;a[j]=-k%3
   refs.append((tuple(p),tuple(a)));classes.append(0)
 if kind=='G313':
  for i in range(3):
   for k in (1,2):
    a=[0]*3;a[i]=k;refs.append(((0,1,2),tuple(a)));classes.append(k)
 G=closure(refs);size=len(G);lookup={g:i for i,g in enumerate(refs)};rng=random.Random(20261029);out=[]
 for N in (8,10):
  tried=0;accepted=[];hist=collections.Counter()
  while len(accepted)<80 and tried<60000:
   tried+=1;inds=[rng.randrange(len(refs)) for _ in range(N-1)];P=ID
   for i in inds:P=mul(P,refs[i])
   final=lookup.get(inv(P))
   if final is None:continue
   inds.append(final)
   if len(closure([refs[i] for i in inds]))!=size:continue
   cls=tuple(sorted(classes[i] for i in inds));hist[cls]+=1;accepted.append(inds)
  out.append({'N':N,'attempts':tried,'accepted':len(accepted),'counts_by_class_multiset':[{ 'classes':list(c),'count':v} for c,v in sorted(hist.items())],'accepted_indices':accepted})
 all_results[kind]={'group_order':size,'samples':out}
 print(kind,'order',size)
 for t in out:print('N',t['N'],'accepted',t['accepted'],'attempts',t['attempts'],'counts',t['counts_by_class_multiset'])
(B/'outputs/source_sampler_counts.json').write_text(json.dumps(all_results,indent=2)+'\n')
