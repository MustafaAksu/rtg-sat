#!/usr/bin/env python3
"""Verify inputs, rebuild scientific outputs in a temporary copy, and compare byte-exactly.
Optional --source-replay also runs the unchanged mathematics of the supplied producer engines.
No network activity. Requires Python 3 and SymPy (only for faithful permutation-group order).
"""
import argparse,hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SCIENTIFIC=['source_sampler_counts.json','independent_locality_exact.json','independent_random_320.json','g34_rank2_local_census.json']
def verify_manifest():
 mf=ROOT/'SHA256SUMS.txt'
 if not mf.exists():return
 count=0
 for line in mf.read_text().splitlines():
  h,rel=line.split('  ',1);p=ROOT/rel
  assert p.is_file(),f'missing {rel}'
  assert hashlib.sha256(p.read_bytes()).hexdigest()==h,f'hash mismatch {rel}'
  count+=1
 print('MANIFEST PASS',count,flush=True)
def main():
 args=argparse.ArgumentParser();args.add_argument('--source-replay',action='store_true');args=args.parse_args()
 verify_manifest();report={}
 with tempfile.TemporaryDirectory(prefix='hcg_locality_replay_') as td:
  work=Path(td)
  for name in ['source','inputs','scripts']:
   shutil.copytree(ROOT/name,work/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  (work/'outputs').mkdir()
  commands=['audit_sampling_counts.py','local_determinant_independent.py','independent_random_replay.py','g34_rank2_local_census.py']
  for script in commands:
   print('REPLAY',script,flush=True)
   r=subprocess.run([sys.executable,'-B',str(work/'scripts'/script)],cwd=work,capture_output=True,text=True,check=True)
   (work/'outputs'/f'{script}.log').write_text(r.stdout)
  for name in SCIENTIFIC:
   got=(work/'outputs'/name).read_bytes();expected=(ROOT/'expected'/name).read_bytes()
   assert got==expected,f'scientific output differs: {name}'
   report[name]={'byte_equal':True,'sha256':hashlib.sha256(got).hexdigest()}
  if args.source_replay:
   source_runs=[('g34_scan_path_adapter.py',[]),('locality_path_adapter.py',[]),('locality_path_adapter.py',['G313'])]
   for i,(script,extra) in enumerate(source_runs):
    print('PRODUCER REPLAY',script,*extra,flush=True)
    r=subprocess.run([sys.executable,'-B',str(work/'scripts'/script),*extra],cwd=work,capture_output=True,text=True,check=True)
    if i==0:
     got=[s for s in r.stdout.splitlines() if not s.startswith(('W6 skip','W7 skip'))]
     exp=[s for s in (ROOT/'source/g34_disc_scan_out.txt').read_text().splitlines() if not s.startswith(('(a) W6','(a) W7'))]
     assert got==exp,'available G34 producer rows differ'
    elif i==2:assert r.stdout==(ROOT/'source/g313_disc_locality_out.txt').read_text(),'G313 producer log differs'
    else:assert r.stdout==(ROOT/'outputs/g333_replay.txt').read_text(),'G333 replay differs'
   report['source_replay']='PASS; W6/W7 deliberately absent and not counted'
 print(json.dumps(report,indent=2));print('FRESH REPLAY PASS')
if __name__=='__main__':main()
