#!/usr/bin/env python3
"""Self-contained replay; Python 3 and sympy needed (pip install sympy)."""
from pathlib import Path
import subprocess,sys,hashlib
root=Path(__file__).resolve().parent
cases={'W5':'g34_cert_W5_balanced.json','W6':'g34_cert_W6_comb.json','W7':'g34_cert_W7_comb.json'}
for name,filename in cases.items():
    path=root/'inputs'/filename
    print('===',name,'===',flush=True)
    for script,args in [
        ('severn_lemma62_formula_check_CLAUDE.py',[str(path)]),
        ('paired_reflection_cup_independent.py',[str(path), str(root/'outputs'/f'paired_cup_{name}.json')])]:
        p=subprocess.run([sys.executable,str(root/'scripts'/script),*args],check=True,capture_output=True,text=True)
        print(p.stdout,end='')
        (root/'outputs'/f'{name}_{script}.txt').write_text(p.stdout)
print('ALL 3 x 2 CHECKS PASSED')
