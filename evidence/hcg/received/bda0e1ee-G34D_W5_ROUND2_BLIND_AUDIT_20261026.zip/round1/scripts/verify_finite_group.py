#!/usr/bin/env python3
"""Independent finite-orbit and group-order proof for the W5 reflections.

Exact Eisenstein-integer arithmetic. The action on the orbit is faithful
because the script checks that all ten input roots are in its linear span.
SymPy is used only for rational rank and permutation group order.
"""
from __future__ import annotations
import argparse, collections, hashlib, json, time
from pathlib import Path
import sympy as s
from sympy.combinatorics import Permutation, PermutationGroup

def add(x,y):return (x[0]+y[0],x[1]+y[1])
def sub(x,y):return (x[0]-y[0],x[1]-y[1])
def mul(x,y):return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]-x[1]*y[1])
def conj(x):return (x[0]-x[1],-x[1])
def inner(x,y):
    z=(0,0)
    for a,b in zip(x,y):z=add(z,mul(a,conj(b)))
    return z

def main():
    p=argparse.ArgumentParser(description=__doc__)
    root=Path(__file__).resolve().parents[1]
    p.add_argument('--input',type=Path,default=root/'supplied/v0_2/roots_alt_5.json')
    p.add_argument('--output',type=Path,default=root/'outputs/finite_group.json')
    p.add_argument('--orbit-output',type=Path,default=root/'outputs/finite_root_orbit.json')
    if not __debug__: raise RuntimeError("Run without -O; assertions are required.")
    a=p.parse_args();start=time.time()
    raw=a.input.read_bytes();rs=[tuple(map(tuple,r)) for r in json.loads(raw)['generating_reflection_roots']]
    assert all(inner(r,r)==(6,0) for r in rs)
    def reflect(x,r):
        h=inner(x,r); v=[]
        for y,z in zip(x,r):
            prod=mul(h,z)
            assert prod[0]%3==0 and prod[1]%3==0,'Orbit left the checked Eisenstein lattice'
            v.append(sub(y,(prod[0]//3,prod[1]//3)))
        return tuple(v)
    orbit=[rs[0]];index={rs[0]:0};cursor=0
    while cursor<len(orbit):
        x=orbit[cursor]
        for r in rs:
            y=reflect(x,r)
            if y not in index:index[y]=len(orbit);orbit.append(y)
        cursor+=1
        assert len(orbit)<=10000,'Abort: finite orbit bound not reached'
    # Verify rank directly over K; do not infer it from a rational-coordinate rank.
    w=(-1+s.sqrt(-3))/2
    root_matrix=s.polys.matrices.DomainMatrix.from_Matrix(s.Matrix([[s.Rational(x)+s.Rational(y)*w for x,y in r] for r in rs])).convert_to(s.QQ.algebraic_field(w))
    root_rank=len(root_matrix.rref()[1]); assert root_rank==6
    assert all(r in index for r in rs),'Needed spanning input roots absent from orbit'
    perms=[]
    for r in rs:
        perm=[index[reflect(x,r)] for x in orbit]
        assert sorted(perm)==list(range(len(orbit))) and all(perm[perm[i]]==i for i in range(len(orbit)))
        perms.append(perm)
    group=PermutationGroup([Permutation(v) for v in perms])
    order=int(group.order())
    # Orbit graph verifies closure without classifying the group by its name.
    orbit_obj={'field':'Z[w], w^2+w+1=0','orbit':orbit,'generator_permutations':perms}
    a.orbit_output.parent.mkdir(exist_ok=True,parents=True)
    a.orbit_output.write_text(json.dumps(orbit_obj,separators=(',',':'))+'\n')
    result={'status':'PASS','root_input_sha256':hashlib.sha256(raw).hexdigest(),
        'orbit_size':len(orbit),'spanning_input_roots_in_orbit':True,'root_span_rank_K':root_rank,
        'action_faithful':True,'permutation_group_order':order,
        'finite_group_proved':True,'classification_name_verified_from_primary_classification':False,
        'orbit_file_sha256':hashlib.sha256(a.orbit_output.read_bytes()).hexdigest(),
        'sympy_version':s.__version__,'elapsed_seconds':time.time()-start,
        'scope':'Finiteness/order of this matrix group; not a braid-orbit identification with a different tuple.'}
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
