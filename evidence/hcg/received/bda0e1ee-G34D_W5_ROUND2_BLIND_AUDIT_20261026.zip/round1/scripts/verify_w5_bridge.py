#!/usr/bin/env python3
"""Independent exact checks for the supplied W5 geometric bridge.

Requires Python >=3.10 and SymPy. No Sage or external certificate code.
Arithmetic: QQ(w), w^2+w+1=0. All matrix tests are exact.
This script does not certify existence of a geometric family; that argument
is in GEOMETRIC_REPORT.md. It checks the algebra/topology used there.
"""
import argparse, hashlib, itertools, json, sys, time
from pathlib import Path
import sympy as sp
from sympy.polys.domains import QQ
from sympy.polys.matrices import DomainMatrix

K=QQ.algebraic_field((-1+sp.sqrt(-3))/2)
w=K.unit
Z=K.zero; O=K.one

def val(x): return K.convert(QQ(str(x)))
def el(x): return val(x[0])+val(x[1])*w

def pair(x):
    a=x.to_list(); a=[QQ.zero]*(2-len(a))+a
    return [str(a[1]),str(a[0])]

def cj(x):
    p,q=pair(x)
    return val(p)-val(q)-val(q)*w

def mat(a): return DomainMatrix(a,(len(a),len(a[0])),K).to_dense()
def arr(a): return a.to_dense().to_list()
def zeros(m,n): return mat([[Z]*n for _ in range(m)])
def eye(n): return mat([[O if i==j else Z for j in range(n)] for i in range(n)])
def conj(a): return mat([[cj(x) for x in row] for row in arr(a)])
def adj(a): return conj(a).transpose()
def ser(a): return [[pair(x) for x in row] for row in arr(a)]
def dm(a): return mat([[el(x) for x in row] for row in a])
def rank(a): return len(a.rref()[1])
def take(a,rows,cols): return a.extract(rows,cols)
def iszero(a): return all(not x for row in arr(a) for x in row)
def eq(a,b): return iszero(a-b)
def scalar(a,x): return a.scalarmul(x)
def columns(a): return list(map(list,zip(*arr(a))))
def fromcols(cols): return mat(list(map(list,zip(*cols))))
def dot(a,b): return sum((x*cj(y) for x,y in zip(a,b)),Z)
def addv(a,b): return [x+y for x,y in zip(a,b)]
def scalev(a,x): return [x*y for y in a]
def mv(a,b): return [sum((x*y for x,y in zip(row,b)),Z) for row in arr(a)]

def inertia(a):
    """Exact Hermitian inertia via Schur complements (all diagonal pivots rational)."""
    assert eq(a,adj(a))
    pos=neg=zero=0
    while a.shape[0]:
        n=a.shape[0]; aa=arr(a)
        k=next((i for i in range(n) if aa[i][i]),None)
        if k is None:
            ij=next(((i,j) for i in range(n) for j in range(i+1,n) if aa[i][j]),None)
            if ij is None: zero+=n;break
            i,j=ij
            # nonzero offdiagonal with zero diagonals gives a 2x2 (1,1) block
            ids=[i,j]+[k for k in range(n) if k not in (i,j)]
            a=take(a,ids,ids); b=take(a,[0,1],[0,1]); c=take(a,[0,1],list(range(2,n)))
            a=take(a,list(range(2,n)),list(range(2,n)))-adj(c)*b.inv()*c
            pos+=1;neg+=1;continue
        ids=[k]+[i for i in range(n) if i!=k]
        a=take(a,ids,ids); aa=arr(a); x=aa[0][0]
        p,q=pair(x); assert QQ(q)==0
        if QQ(p)>0: pos+=1
        else: neg+=1
        if n==1: break
        c=take(a,[0],list(range(1,n)))
        a=take(a,list(range(1,n)),list(range(1,n)))-scalar(adj(c)*c,O/x)
    return [pos,neg,zero]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=Path(__file__).resolve().parents[1]/'supplied/v0_2/g34_cert_tuple5_balanced.json')
    p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'outputs/bridge_exact.json')
    if not __debug__: raise RuntimeError("Run without -O; assertions are required.")
    args=p.parse_args(); t=time.time(); raw=args.input.read_bytes(); d=json.loads(raw)
    vs=[[el(x) for x in v] for v in d['roots']]
    assert len(vs)==10 and all(len(v)==6 for v in vs)
    refl=[]; norms=[]
    for v in vs:
        norm=dot(v,v); norms.append(pair(norm))
        s=eye(6)-scalar(mat([[x*cj(y) for y in v] for x in v]),val(2)/norm)
        assert eq(s*s,eye(6)) and eq(adj(s)*s,eye(6)) and rank(s-eye(6))==1
        refl.append(s)
    roots=fromcols(vs); root_rank=rank(roots)
    # Unitary reflection irreducibility: spanning roots, connected nonorthogonality graph.
    seen={0}
    while True:
        new=seen|{j for i in seen for j in range(10) if dot(vs[i],vs[j])}
        if new==seen:break
        seen=new
    assert root_rank==6 and len(seen)==10
    gs=[s for s in refl for _ in (0,1)]; rv=[v for v in vs for _ in (0,1)]
    prefixes=[eye(6)]
    for g in gs: prefixes.append(prefixes[-1]*g)
    assert eq(prefixes[-1],eye(6))
    closure=fromcols([mv(prefixes[i],rv[i]) for i in range(20)])
    # u_i=a_i v_i = (g_i-1)b, hence a_i=-2 h(b,v_i)/h(v_i,v_i)
    cob=mat([[-val(2)*cj(x)/dot(v,v) for x in v] for v in rv])
    basis=dm(d['H1par_basis_cocycles']).transpose()
    assert basis.shape==(20,8)
    hb=cob.hstack(basis)
    assert iszero(closure*basis) and iszero(closure*cob)
    assert rank(closure)==6 and rank(cob)==6 and rank(hb)==14
    rows=list(hb.transpose().rref()[1]); hh=take(hb,rows,list(range(14)))
    solver=hh.inv(); bcols=columns(basis)
    # Compute cup pairing from left-cocycle formula, separate from stored S.
    # DW theorem 2.6 translated to left action, linear-first Hermitian convention.
    def cup(a,b):
        total=Z; F=[Z]*6
        for i in range(20):
            u=scalev(rv[i],a[i]); v=scalev(rv[i],b[i])
            total+=dot(F,mv(prefixes[i],v))+dot(u,v)/val(2)
            F=addv(F,mv(prefixes[i],u))
        assert not any(F)
        return total
    S=mat([[cup(a,b) for b in bcols] for a in bcols])
    assert eq(S,dm(d['S_gram'])) and eq(S,-adj(S)) and rank(S)==8
    # DW direct RIGHT-cocycle implementation, theorem 2.6.
    # right row cocycle delta_i=-u_i^t, action g_i^t (reflections).
    # dual first cocycle is the conjugate, and v'_i=-delta_i/2.
    # Returns the negative of the linear-first left-cocycle Gram here;
    # this is the single global surface/pairing orientation conversion.
    def dw_direct(a,b):
        total=Z; prev=[Z]*6
        for i in range(20):
            ur=scalev(rv[i],-a[i]); vr=scalev(rv[i],-b[i]); v0=scalev(vr,-O/val(2))
            # first cocycle transported in dual action; after conjugation this
            # is the usual unitary row transport. row * g^t = (g col)^t.
            pg=mv(gs[i],prev)
            delta=addv(ur,[x-y for x,y in zip(pg,prev)])
            total+=dot(delta,v0)
            prev=addv(pg,ur)
        assert not any(prev)
        return total
    SDW=mat([[dw_direct(a,b) for b in bcols] for a in bcols])
    assert eq(SDW,-S)
    # Geometric interval twist c conjugates each included loop.
    curves=[]; Ns=[]; Ts=[]
    for j,c in enumerate(d['curves'],1):
        a,b=c['curve']; P=eye(6)
        for i in range(a-1,b): P=P*gs[i]
        assert eq(P,eye(6)),(a,b)
        newcols=[]
        for ac in bcols:
            uc=[Z]*6; pref=eye(6)
            for i in range(a-1,b):
                uc=addv(uc,mv(pref,scalev(rv[i],ac[i])));pref=pref*gs[i]
            out=ac[:]
            for i in range(a-1,b):
                # u(cg_i c^-1)=u_i+(1-g_i)u(c), since rho(c)=1.
                v=rv[i]
                out[i]+=val(2)*dot(uc,v)/dot(v,v)
            newcols.append(out)
        image=fromcols(newcols)
        x=solver*take(image,rows,list(range(8)))
        assert eq(hb*x,image)
        T=take(x,list(range(6,14)),list(range(8)));N=T-eye(8)
        assert eq(T,dm(c['T'])) and eq(N,dm(c['N'])) and iszero(N*N)
        assert eq(T.transpose()*S*conj(T),S)
        assert c['k']==1
        B=S*conj(N); assert eq(B,adj(B))
        assert iszero(take(N,list(range(4,8)),list(range(8))))
        assert iszero(take(N,list(range(8)),list(range(4))))
        assert inertia(take(B,list(range(4,8)),list(range(4,8))))==[0,rank(N),4-rank(N)]
        curves.append({'j':j,'interval':[a,b],'boundary_product_identity':True,'exact_return_k':1,
                       'nilpotent_rank_K':rank(N),'quotient_beta_inertia':inertia(take(B,list(range(4,8)),list(range(4,8))))})
        Ns.append(N);Ts.append(T)
    assert all(iszero(a*b) for a in Ns for b in Ns)
    J=Ns[0]
    for n in Ns[1:]: J=J.hstack(n)
    Icols=list(J.rref()[1]); I=take(J,list(range(8)),Icols)
    assert I.shape==(8,4) and iszero(I.transpose()*S*conj(I))
    assert all(iszero(n*I) for n in Ns)
    total=Ns[0]
    for n in Ns[1:]: total=total+n
    Bsum=take(S*conj(total),list(range(4,8)),list(range(4,8)))
    assert rank(total)==4 and inertia(Bsum)==[0,4,0]
    # Rank over Q and over K; latter directly guards rational-vs-complex rank.
    kcols=[[x for row in arr(n) for x in row] for n in Ns]
    qcols=[]
    for col in kcols:
        pp=[pair(x) for x in col]
        qcols.append([val(x[0]) for x in pp]+[val(x[1]) for x in pp])
    kr=rank(fromcols(kcols)); qr=rank(fromcols(qcols))
    assert kr==16 and qr==16
    blocks=[take(n,list(range(4)),list(range(4,8))) for n in Ns]
    flat=fromcols([[x for row in arr(b) for x in row] for b in blocks])
    piv=list(flat.rref()[1]); det=take(flat,list(range(16)),piv).det()
    assert det
    relation=flat.nullspace(); assert relation.shape==(1,17)
    # Symmetry/log constraints with correct conjugation for linear-first S.
    assert all(iszero(n.transpose()*S+S*conj(n)) for n in Ns)
    # Pants tree from laminar sets. Include the outer root; leafs are singleton marks.
    sets=[frozenset(range(a,b+1)) for a,b in [c['interval'] for c in curves]]
    assert len(set(sets))==17
    assert all(not A&B or A<=B or B<=A for A,B in itertools.combinations(sets,2))
    allmarks=frozenset(range(1,21)); verts=sets+[allmarks]
    records=[]
    for A in verts:
        children=[B for B in sets if B<A and not any(B<C<A for C in sets)]
        used=frozenset().union(*children) if children else frozenset()
        marks=sorted(A-used); flags=len(children)+len(marks)+(A!=allmarks)
        assert flags==3
        pairtype=len(marks)==2
        assert (pairtype and marks[1]==marks[0]+1 and marks[0]%2==1) or not marks
        fixed=5 if pairtype else 6
        defect=2 if pairtype else 0
        h0=defect-12+2*fixed
        assert h0==0
        records.append({'vertex':sorted(A),'children':[sorted(B) for B in children],'branch_labels':marks,
                        'flags':flags,'fixed_dim':fixed,'H0_contribution':h0})
    assert len(records)==18 and sum(bool(x['branch_labels']) for x in records)==10
    # Complementary [19,20] vs [1,18]: same on cohomology, not inverse.
    # Paired prefix/suffix: u(c_complement)=-u(c) by product-one closure.
    def twist_interval(a,b):
        newcols=[]
        for ac in bcols:
            uc=[Z]*6; pref=eye(6)
            for i in range(a-1,b):
                uc=addv(uc,mv(pref,scalev(rv[i],ac[i]))); pref=pref*gs[i]
            assert eq(pref,eye(6))
            out=ac[:]
            for i in range(a-1,b):
                out[i]+=val(2)*dot(uc,rv[i])/dot(rv[i],rv[i])
            newcols.append(out)
        image=fromcols(newcols);x=solver*take(image,rows,list(range(8)))
        assert eq(hb*x,image)
        return take(x,list(range(6,14)),list(range(8)))
    Tc=twist_interval(1,18)
    assert eq(Tc,Ts[9])
    # Every nonzero N is changed by sign; choose independent sign as negative control.
    common_sign_negative_control=(inertia(take(S*conj(-Ns[0]),list(range(4,8)),list(range(4,8))))==[1,0,3])
    assert common_sign_negative_control
    out={'status':'PASS','input_sha256':hashlib.sha256(raw).hexdigest(),
         'sympy_version':sp.__version__,'field':'Q(w), w^2+w+1=0',
         'root_norms':norms,'root_span_rank':root_rank,'root_graph_connected':True,
         'irreducibility_argument':'Unitary reflections; spanning roots and connected nonorthogonality graph.',
         'closure_rank':rank(closure),'coboundary_rank':rank(cob),'H1par_dim_K':8,
         'stored_basis_verified':True,'cup_gram_reconstructed':ser(S),'cup_matches_supplied':True,
         'DW_direct_matches_negative_gram':True,'cup_global_sign_note':'One global convention sign; no curvewise signs used.',
         'curves':curves,'all_289_products_zero':True,'common_image_dim_K':4,
         'common_image_isotropic':True,'sum_N_rank_K':rank(total),
         'sum_beta_inertia':inertia(Bsum),'sum_beta_gram':ser(Bsum),
         'rank_Q_N':qr,'rank_K_N':kr,'rank16_minor_curve_indices':[i+1 for i in piv],
         'rank16_block_minor_determinant':pair(det),'linear_relation':ser(relation),
         'pants_tree':records,'pants_count':18,'rational_double_cover_components_types':10,
         'trivial_cover_components_types':8,
         'graph_multiplicity_C1_dim_K':17*6,'graph_multiplicity_C0_dim_K':8*6+10*5,
         'graph_H1_multiplicity_dim_K':17*6-(8*6+10*5),
         'complement_19_20_equals_1_18_on_H1par':True,
         'negative_control_one_sign_flip_detected':True,
         'elapsed_seconds':time.time()-t,
         'scope':'Exact algebra and labelled-tree checks, not geometric theorem automation.'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['cup_gram_reconstructed','pants_tree','sum_beta_gram','linear_relation']},indent=2))

if __name__=='__main__': main()
