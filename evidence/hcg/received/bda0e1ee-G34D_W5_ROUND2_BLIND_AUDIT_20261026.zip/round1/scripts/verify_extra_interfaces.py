#!/usr/bin/env python3
"""Extra independent checks: character field, cup-matrix typing,
exact one-dimensional kernel of the 17 logarithm directions, and input identity.
Requires SymPy. Imports arithmetic helpers, not recorded outputs.
"""
from pathlib import Path
import hashlib, itertools, json
from verify_w5_bridge import *

if not __debug__: raise RuntimeError("Run without -O; assertions are required.")
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'supplied/v0_2/g34_cert_tuple5_balanced.json').read_text())
vs=[[el(x) for x in v] for v in d['roots']]
ss=[eye(6)-scalar(mat([[x*cj(y) for y in v] for x in v]),val(2)/dot(v,v)) for v in vs]
witness=None
for n in (1,2,3,4):
    for inds in itertools.product(range(10),repeat=n):
        g=eye(6)
        for i in inds:g=g*ss[i]
        tr=sum((arr(g)[i][i] for i in range(6)),Z)
        if QQ(pair(tr)[1]):witness={'reflection_word_1_based':[i+1 for i in inds],'trace':pair(tr)};break
    if witness:break
assert witness
# Entries are in K and one trace generates K, so the character field is exactly K.
Ns=[dm(x['N']) for x in d['curves']]
flat=fromcols([[arr(n)[i][j] for i in range(8) for j in range(8)] for n in Ns])
rr,piv=flat.rref();free=[i for i in range(17) if i not in piv]
assert len(piv)==16 and len(free)==1
v=[Z]*17;v[free[0]]=O
for i,j in enumerate(piv):v[j]=-arr(rr)[i][free[0]]
assert iszero(flat*fromcols([v]))
assert all(QQ(pair(x)[1])==0 for x in v)
# Normalize to primitive integral coefficients.
nums=[sp.Rational(pair(x)[0]) for x in v]
den=sp.ilcm(*[x.q for x in nums]);iv=[int(x*den) for x in nums]
gcd=sp.igcd(*iv);iv=[x//gcd for x in iv]
assert iszero(flat*fromcols([[val(x) for x in iv]]))
files=['g34_cert_tuple5_balanced.json','roots_alt_5.json']
ident={f:{'same_bytes':(root/'supplied/v0_1'/f).read_bytes()==(root/'supplied/v0_2'/f).read_bytes(),
'sha256':hashlib.sha256((root/'supplied/v0_2'/f).read_bytes()).hexdigest()} for f in files}
assert all(x['same_bytes'] for x in ident.values())
assert d['roots']==json.loads((root/'supplied/v0_2/roots_alt_5.json').read_text())['generating_reflection_roots']
S=dm(d['S_gram'])
naive_nonhermitian=[i+1 for i,n in enumerate(Ns) if not eq(S*n,adj(S*n))]
assert len(naive_nonhermitian)==16
output={'naive_S_times_N_nonhermitian_curve_indices':naive_nonhermitian,'status':'PASS','character_field':'Q(w), w^2+w+1=0','nonreal_character_witness':witness,
'absolute_irreducibility':'Spanning connected unitary-reflection root system; proved in main audit.',
'schur_index_over_K':1,
'logarithm_relation_coefficients_in_curve_order':iv,
'kernel_dimension_C':1,'dimension_claim':'The map C^17 -> tangent space C^16 is surjective, not injective.',
'input_versions_identical':ident,'root_serializations_agree':True,
'scope':'Exact interface checks, not a braid-orbit comparison with the manuscript gate tuple.'}
(root/'outputs/extra_interfaces.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
