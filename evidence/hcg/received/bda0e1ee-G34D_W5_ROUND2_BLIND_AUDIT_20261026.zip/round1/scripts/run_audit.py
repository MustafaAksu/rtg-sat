#!/usr/bin/env python3
"""Replay the independent W5 checks and rejection controls.

Run without -O: the exact checker intentionally uses assertions.
The driver tests arithmetic and provenance; it does not automate the geometric proof.
Outputs are regenerated in outputs/; elapsed times are not deterministic.
"""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    'g34_cert_tuple5_balanced.json': '172766a91017aeac62e5c299a72b2c7582b0bb186c4feaa8b1906144eafb952e',
    'roots_alt_5.json': '480cd6dc95f1a802943a621df632693eeb9aa7e8a9057ff5099e444950c9e35a',
}

def run(args: list[str], timeout: int = 120) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ)
    env.pop('PYTHONOPTIMIZE', None)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return subprocess.run([sys.executable, *args], cwd=ROOT, env=env,
                          text=True, capture_output=True, timeout=timeout, check=False)

def main() -> int:
    if not __debug__:
        raise RuntimeError('Do not use python -O; assertion checks are required.')
    start = time.time()
    out = ROOT / 'outputs'
    out.mkdir(exist_ok=True)
    integrity = []
    for version in ('v0_1', 'v0_2'):
        for name, expected in EXPECTED.items():
            digest = hashlib.sha256((ROOT/'supplied'/version/name).read_bytes()).hexdigest()
            integrity.append({'file': f'supplied/{version}/{name}', 'sha256': digest,
                              'matches_expected': digest == expected})
    if not all(r['matches_expected'] for r in integrity):
        raise RuntimeError('Supplied mathematical data do not match the frozen input hashes.')
    (out/'input_integrity.json').write_text(json.dumps(integrity, indent=2)+'\n')
    replays = []
    for script, log in [('verify_w5_bridge.py','bridge_console.txt'),
                        ('verify_finite_group.py','group_console.txt'),
                        ('verify_extra_interfaces.py','extra_console.txt')]:
        p = run(['scripts/'+script])
        (out/log).write_text(p.stdout + ('\nSTDERR:\n'+p.stderr if p.stderr else ''))
        replays.append({'script': script, 'exit_code': p.returncode, 'log': 'outputs/'+log})
        if p.returncode:
            raise RuntimeError(f'{script} failed; see outputs/{log}')
    original = json.loads((ROOT/'supplied/v0_2/g34_cert_tuple5_balanced.json').read_text())
    controls = []
    cases = []
    d=copy.deepcopy(original); d['S_gram'][0][0][0]=str(int(d['S_gram'][0][0][0])+1)
    cases.append(('NC01_cup_entry','One stored cup entry changed.',d))
    d=copy.deepcopy(original); d['curves'][0]['N'][0][4][0]=str(int(d['curves'][0]['N'][0][4][0])+1)
    cases.append(('NC02_log_entry','One stored logarithm entry changed.',d))
    d=copy.deepcopy(original); d['curves'][0]['k']=2
    cases.append(('NC03_return_exponent','The first exact return exponent changed from 1 to 2.',d))
    d=copy.deepcopy(original)
    # N^2=0: invert the first twist and logarithm together. This retains
    # individual unipotence but contradicts the fixed geometric braid convention.
    for i in range(8):
        for j in range(8):
            a,b=d['curves'][0]['N'][i][j]
            from fractions import Fraction
            a,b=Fraction(a),Fraction(b)
            d['curves'][0]['N'][i][j]=[str(-a),str(-b)]
            d['curves'][0]['T'][i][j]=[str(Fraction(i==j)-a),str(-b)]
    cases.append(('NC04_one_twist_inverted','Only the first twist is replaced by its inverse.',d))
    with tempfile.TemporaryDirectory(prefix='w5_negative_controls_') as tmp:
        td=Path(tmp)
        for key, description, data in cases:
            f=td/(key+'.json'); f.write_text(json.dumps(data))
            p=run(['scripts/verify_w5_bridge.py','--input',str(f),'--output',str(td/(key+'_output.json'))])
            log='negative_'+key+'.txt'
            (out/log).write_text(p.stdout+'\nSTDERR:\n'+p.stderr)
            row={'id':key,'mutation':description,'exit_code':p.returncode,
                 'rejected':p.returncode!=0,'log':'outputs/'+log}
            controls.append(row)
            if p.returncode==0:
                raise RuntimeError(f'Negative control unexpectedly passed: {key}')
    result={'status':'PASS','python_version':sys.version,'input_hashes_checked':len(integrity),
            'exact_script_replays':replays,'negative_controls':controls,
            'internal_mixed_sign_control':'Also executed by verify_w5_bridge.py; wrong sign gives inertia (1,0,3).',
            'geometric_proof_machine_verified':False,
            'elapsed_seconds':time.time()-start}
    (out/'audit_replay.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
