# Reproduction instructions and scope

## Environment

Executed with Python 3.13 and SymPy 1.14.0. Exact versions appear in the JSON outputs. The code uses rational arithmetic in Q(w), w²+w+1=0, and exact Eisenstein-integer arithmetic; it does not use floating eigenvalues, Sage, GAP, downloaded verification code or recorded PASS outputs as inputs.

```sh
python -m pip install -r requirements.txt
python scripts/run_audit.py
```

Run without optimization (`-O`); all scripts refuse optimized execution because assertions are part of their checks.

## What is recomputed

1. `verify_w5_bridge.py` rebuilds reflections and the parabolic cocycle quotient, checks the supplied basis as a complement rather than assuming it, computes the cup pairing in two conventions, reconstructs interval twists, verifies the logarithms and H0–H4, computes rational and K ranks, records the exact nonzero 16-minor, constructs the labelled pants tree and checks the complementary infinity-side twist.
2. `verify_finite_group.py` builds the 756-vector root orbit using exact integer pairs, checks it contains the spanning roots, constructs the faithful permutations and computes their group order. The complete orbit and permutations are saved.
3. `verify_extra_interfaces.py` checks a nonreal character value, the one-dimensional relation, matrix typing for the linear-first form, root serialization agreement and byte identity across input versions.

The driver checks four frozen input hashes and runs four altered-certificate controls. Their expected outcome is nonzero exit: changed cup entry; changed logarithm entry; changed exact return exponent; only one twist inverted. The bridge script also checks that one sign reversal changes a quotient-form inertia to (1,0,3). These controls test the stated implementations; they are not exhaustive software verification.

## Output interpretation

- `bridge_exact.json`: exact matrices, inertia and ranks, minor, tree and convention metadata.
- `finite_group.json`: group order and faithfulness argument inputs.
- `finite_root_orbit.json`: full finite witness, not a summary-only certificate.
- `extra_interfaces.json`: trace, primitive relation and input identity.
- `input_integrity.json`: frozen mathematical data hashes.
- `audit_replay.json`: script exit codes, negative controls and environment.
- `*_console.txt`, `negative_*.txt`: complete execution output.

All three valid replays passed; all four mutated-input subprocesses exited 1. All mathematical comparisons were exact. Timing fields and platform strings may differ in a new environment; byte equality of every generated JSON is not an appropriate universal replay criterion.

## Not automated

The existence of the admissible cover, the common plumbing orientation, coefficient-transport identification, construction of the polarized VHS, Schmid's theorem application, limiting mixed Hodge structure, and interior-rank argument are written mathematics in `GEOMETRIC_REPORT.md`. No script output is represented as a formal verification of those arguments.

The group name G34 was not separately matched to the original classification. No connecting braid to the manuscript's gate tuple was available. The global transfer chain was not checked. Original CKS 1986 full-text access was unsuccessful; the report supplies its alternative Schmid-based route explicitly.
