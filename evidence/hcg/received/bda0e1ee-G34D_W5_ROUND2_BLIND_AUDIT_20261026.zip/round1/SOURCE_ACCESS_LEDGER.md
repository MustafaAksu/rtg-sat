# Source-access and use ledger

**Access date:** 22 October 2026. The supplied v0.1 instructions and v0.2 correction were read completely. The mathematical papers were read at the sections recorded below; no blanket full-paper review is claimed. PDF passages were checked using parsed text and rendered-page screenshots. No local PDF bytes were successfully retained; this package contains references, not copied papers or invented PDF hashes.

## Accessed primary research texts

### SEVERN-MAIN
- Ben Severn, *Weil Classes on Every Abelian Sixfold of Weil Type for Q(sqrt(-3))*.
- Actual title page: **Draft v0.5, 16 October 2026**; Hexagon `2610.00387v1`; 17 pages.
- URL: https://hexagonmath.org/pdf/2610.00387v1
- Read: relevant conventions in §2; §4, especially Lemma 4.1 and Proposition 4.2 Steps 0–5; §6's statement of its boundary witness; Appendix A's curve/return table and repository pointers. Title page and relevant proof/table pages inspected visually.
- Use: proposition under review; not an authority establishing its own correctness. Its claims of earlier independent checks were not used as evidence.
- Boundary: not a full audit of §§3,5–8, the transfer applications, or global theorem.

### SEVERN-TRANSFER
- Ben Severn, *A Transfer Theorem for Weil Classes on Prym–Tyurin Factors of Galois Covers*.
- Actual title page: **Draft v0.15, 16 October 2026**; Hexagon `2610.00386v1`; 31 pages.
- URL: https://hexagonmath.org/pdf/2610.00386v1
- Read: title, stated transfer target and relevant factor/convention context. Title page inspected visually.
- Use: source identity and scope separation only. **The transfer theorem is NOT VERIFIED in this audit.**

### DW2006
- Michael Dettweiler and Stefan Wewers, *Variation of parabolic cohomology and Poincaré duality*, Séminaires & Congrès **13** (2006), 145–164.
- Accessed journal PDF: https://emis.de/ft/47210
- Original requested locator: https://www.emis.de/journals/SC/13/47210.pdf
- Read: §1 conventions, Theorem 1.3 and Remark 1.4; §2 pairing/signature discussion, Theorems 2.3 and 2.6 and the latter's proof/convention diagram. Relevant pages rendered as screenshots, including printed pp. 151 and 158–159.
- Use: braid action together with coefficient transport; cup-product reconstruction, not only a monodromy-invariance test. The independent right/dual-first evaluation gives minus the declared left/linear-first Gram, and that global convention sign is explicitly retained.

### DW2004
- Michael Dettweiler and Stefan Wewers, *Variation of local systems and parabolic cohomology*.
- Accessed original preprint: **arXiv:math/0310139v2, 5 January 2004**, 28 pages.
- URL: https://arxiv.org/pdf/math/0310139
- Read: cohomological setup, Lemma 2.2, §2.3/Definition 2.4, Theorem 2.5 and its braid/coefficient formulas. Relevant formula pages inspected visually.
- Use: explicit transport formula and the two alternatives for affine/infinity normalization.
- Numbering refers to the accessed preprint, not an assumed numbering of the later journal publication.

### SCHMID1973
- Wilfried Schmid, *Variation of Hodge Structure: The Singularities of the Period Mapping*, Inventiones Mathematicae **22** (1973), 211–319.
- Original journal scan: https://webhomes.maths.ed.ac.uk/~v1ranick/papers/schmid.pdf
- Read: §4 setup and theorem **(4.12)**, printed p. 233; §6 monodromy-weight setup and theorem **(6.16)**, printed p. 255. These pages inspected visually.
- Use: holomorphic untwisting on a full polydisc, then the one-variable limiting mixed Hodge structure on the diagonal. The full 109-page paper and proofs of every deep result were not independently rederived.

### ACV2001
- Dan Abramovich, Alessio Corti and Angelo Vistoli, *Twisted bundles and admissible covers*.
- Accessed original preprint: **arXiv:math/0106211v1**, arXiv header 25 June 2001, 36 pages.
- URL: https://arxiv.org/pdf/math/0106211
- Read: §3, especially **Theorem 3.0.2**; §4, especially **Theorem 4.3.2**; relevant local-node and rigidification discussion, including §7.1.4. The theorem pages inspected visually.
- Use: smooth deformation of twisted covers and the balanced/admissible-cover correspondence; combined with the explicit cut-and-glue construction.
- Edition warning: the retrieved PDF also displays a compilation/date line of 26 November 2024 and contains editorial placeholders. It is identified by its actual arXiv v1 header and is not represented as the final 2003 journal text.

## Original-author expositions inspected

### RW2006
- Matthieu Romagny and Stefan Wewers, *Hurwitz spaces*, Séminaires & Congrès **13** (2006), 313–341.
- Accessed journal PDF: https://emis.de/ft/47206
- Read: §3, including **Theorem 3.1** and the analytic Hurwitz construction; §5 admissibility and deformation, especially **Theorems 5.5–5.6**, printed pp. 334–335. Relevant deformation page inspected visually.
- Use: existence/routing of the marked cover and the independent root-of-smoothing-parameter description. For W5 all node inertia orders equal 1.
- This is an author-written treatment of the theory, not the original Harris–Mumford article; no such substitution is concealed.

### CK1989
- Eduardo Cattani and Aroldo Kaplan, *Degenerating variations of Hodge structure*, Astérisque **179–180** (1989), 67–96.
- URL: https://www.numdam.org/item/AST_1989__179-180__67_0.pdf
- Read: §§1–2, particularly **(2.1)** and **(2.3)**, printed pp. 73–74; relevant pages inspected visually.
- Use: corroborating original-author exposition of nilpotent orbits and polarized limiting mixed Hodge structures. Not misidentified as Cattani–Kaplan–Schmid 1986. The operative proof in this audit instead cites the directly read Schmid statements plus a diagonal restriction.

## Unavailable or not audited

### CKS1986 — METADATA ONLY / full-text inspection NOT VERIFIED
- Eduardo Cattani, Aroldo Kaplan and Wilfried Schmid, *Degeneration of Hodge structures*, Annals of Mathematics **123** (1986), 457–535.
- Journal metadata: https://annals.math.princeton.edu/1986/123-3/p02
- DOI: https://doi.org/10.2307/1971333
- Journal/JSTOR full-text attempts did not produce a readable original paper. Its exact statements (2.13), (4.4) and (4.5), cited by Severn, are **not** represented as directly inspected. No inaccessible theorem is silently treated as checked.

### HARRIS–MUMFORD1982 — full-text inspection NOT VERIFIED
- Joe Harris and David Mumford, *On the Kodaira dimension of the moduli space of curves*, Inventiones Mathematicae **67** (1982), 23–86.
- Metadata/search located; original full text not successfully inspected. The audit does not attribute a verified numbered theorem to this source. RW2006/ACV2001 and an explicit construction supply the stated degeneration argument.

### KNUDSEN1983 — full-text inspection NOT VERIFIED
- Finn F. Knudsen, *The projectivity of the moduli space of stable curves, II: The stacks M(g,n)*, Mathematica Scandinavica **52** (1983), 161–199.
- Metadata locator: https://journals.msp.org/mscand/article/view/1622
- The PDF request did not yield readable original text. No specific original theorem is claimed inspected. The explicit trivalent marked tree has the usual independent plumbing coordinates; the cited admissible-cover sources cover the deformation framework actually used.

### Other named results
- Original Shephard–Todd classification: not inspected. The group generated by the supplied matrices is proved finite and its order computed without depending on its classification name.
- Schoen, Milne, Brauer induction, Hilbert-scheme/Baire spreading, compensation and the global transfer chain: **not audited**. Their validity or applicability is not inferred from G34-D.

## Manuscript data access and component identity

The main draft points to:
https://github.com/benzsevern/hodge-fleet/tree/main/notes/transfer-theorem-review/certificates/g34-d3

The indicated directory could not be retrieved in the browser. A guessed raw path ending in `D/tuple_pairs_D3.json` returned 404; a guessed path failure is not evidence that the repository file does not exist. No previous-review subdirectory or author-provided verification implementation was opened.

Neither supplied ZIP contains the gate tuple or its 90-move braid. Thus the W5 component is well defined and audited, but its identity with the draft's separately chosen component remains unverified. This log records an access/evidence limitation, not mathematical non-equivalence.
