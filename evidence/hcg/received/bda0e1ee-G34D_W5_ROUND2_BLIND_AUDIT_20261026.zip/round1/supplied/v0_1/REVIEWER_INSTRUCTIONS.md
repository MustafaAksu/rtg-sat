# H3 / G34-D — First-round blind independent mathematical review
**Version 0.1 · 21 October 2026 · Not a proof, not an adoption record**

## Assignment to reviewer

Please assess, from the attached **raw mathematical data** and **primary literature**, whether a particular 20-branch-point Hurwitz-family construction proves dominance of the period map for the associated eight-dimensional Weil-type Hodge structure over K = Q(sqrt(-3)). Do not assume that the construction is correct.

The central question is whether the exact algebraic certificate can be realized as the *geometric* local monodromy of a polarized variation of Hodge structure, with the sign, orientation, and degeneration hypotheses needed to infer rank 16 for the period map at an interior point.

### Inputs supplied (not independently validated for this review)
- `g34_cert_tuple5_balanced.json`: ten roots in K^6, the paired 20-reflection tuple, an eight-dimensional parabolic cocycle quotient basis, a proposed skew-Hermitian cup Gram matrix S, and seventeen interval curves with claimed exact matrices T_j and N_j.
- `roots_alt_5.json`: the ten roots in a compact alternative serialization.
- Arithmetic convention: K = Q(w), w²+w+1=0; [p,q] represents p+qw. The ambient Hermitian form is h(x,y)=sum x_i conjugate(y_i), **linear in the first slot**. Reflection s_v(x)=x-2h(x,v)v/h(v,v).
- Tuple convention: (s_1,s_1,...,s_10,s_10), with generators g_1...g_20=1.
- Parabolic cocycles: u(g_i)=a_i v_i, sum_i (s_1...s_{i-1})a_i v_i=0; coboundaries u(g)=(rho(g)-1)w.
- The certificate records the proposed cup form and twist conventions in its `S_convention` and `twist_convention` fields. **Treat these as claims to audit, not definitions of the geometric intersection pairing.**

### Independent verification questions

**A. Finite exact certificate**
1. Reconstruct the reflection matrices and verify the tuple product and its group/irreducibility properties as needed for the geometric argument.
2. Recompute the parabolic cohomology quotient and the true cup/intersection pairing using a primary-source formula, not the supplied Gram matrix as an axiom.
3. Recompute each T_j from a geometric braid action and check whether its N_j is the correct logarithm. Test the conditions:
   - (H0) the required pants/boundary cohomology contributions;
   - (H1) N_j N_k=0 for all j,k;
   - (H2) I=sum im(N_j) has dim_K 4, is isotropic and N_j(I)=0;
   - (H3) beta_j(x,y)=S(x,N_j y) descends to V/I, all beta_j are semidefinite of a **common sign**, and their sum is definite;
   - (H4) the **Q-linear** span of the 17 N_j has rank 16 (not K-rank 16).
   Record the exact results, including any disagreement.

**B. Geometric bridge — primary priority**
4. Derive the exact braid/Gauss–Manin correspondence, including the Dettweiler–Wewers coefficient-transport term. Check whether a central scalar is present and whether any finite base change preserves the required cone.
5. Construct or justify the balanced 17-node degeneration *in the closure of the correct Hurwitz component*. Check admissible covers, local smoothing coordinates, potential automorphisms/rigidification, and whether trivial local inertia actually implies the claimed lifting.
6. Audit the point-at-infinity normalization and the equivalence of complementary interval curves; ensure no braid inverse or boundary loop is silently changed.
7. Prove or disprove that **all 17 positively oriented plumbing loops** produce a *uniform* choice of Dehn-twist direction, rather than independent signs.
8. State precisely which hypotheses of Schmid / Cattani–Kaplan–Schmid hold for the resulting polarized VHS, and whether (H0)–(H4) imply a Hodge–Tate limiting mixed Hodge structure and rank 16 at an **interior** point.
9. Separate statements true only after a finite cover from those true on the original moduli component. A finite cover is acceptable only if its effect on the nilpotent cone and period map is explicitly justified.

**C. Secondary transfer-chain review (only if time permits)**
10. Independently audit the applications of Schoen's algebraic cycles, Milne's S(A)-invariants, Brauer induction and the reality/simple-exponent argument, and the Hilbert-scheme/Baire spreading and transfer theorem. Do not infer validity from an AI review.

### Required report
For every numbered obligation, label **VERIFIED / CONDITIONAL / GAP FOUND / NOT VERIFIED**, with an explicit argument, theorem reference, and any exact calculation or counterexample. State which sources were actually read. Distinguish (i) correctness of the JSON matrices, (ii) their geometric realization, (iii) dominance, and (iv) any global algebraicity theorem. A failed attempt to verify is not a disproof. Do not declare the general Hodge conjecture solved.

### Primary reading list (reviewer must verify exact editions/theorem numbering)
1. Dettweiler–Wewers, *Variation of parabolic cohomology and Poincaré duality* (2006), especially monodromy/braid action and parabolic duality: https://www.emis.de/journals/SC/13/47210.pdf (if unavailable, locate the journal version).
2. Severn, *Weil classes on every abelian sixfold of Weil type for Q(sqrt(-3))* (2026), arXiv:2610.00387v1: https://arxiv.org/abs/2610.00387 — especially Lemma 4.1, Proposition 4.2 and Theorem 6.2. **Unrefereed claim, not an authority for its own correctness.**
3. Severn, companion transfer theorem, arXiv:2610.00386v1: https://arxiv.org/abs/2610.00386 — verify its exact title and statements in the original.
4. Milne, *Lefschetz classes on abelian varieties* (1999), https://www.jmilne.org/math/articles/1999aP.pdf, especially Lemma 3.1 and Theorem 3.2.
5. Schoen, Compositio Mathematica 65 (1988), Theorem 2.0 and Corollary 3.1 — locate original publication.
6. Schmid (1973), *Variation of Hodge Structure: The Singularities of the Period Mapping*; Cattani–Kaplan–Schmid (1986), *Degeneration of Hodge Structures*; original versions.
7. Appropriate original sources on stable pointed curves, plumbing, and admissible covers (e.g. Knudsen and Harris–Mumford); state the exact result used.

### Blindness protocol
No previous Claude or ChatGPT reviews, status ledgers, audit scripts, or claimed PASS summaries are provided. Please first submit your independent assessment **before** seeing those documents. They can be supplied in round two for an adversarial cross-review.

**No RTG DSN or canonical status is altered by this packet.**
