# Audit trail and boundaries

## 1. Original source error — retained

The v0.1 instructions called the two Hexagon document identifiers arXiv identifiers. The earlier source check found unrelated arXiv records; the user explicitly confirmed the discrepancy. The v0.2 correction withdrew the arXiv references and supplied the actual Hexagon URLs. Both original instruction files remain byte-preserved in `supplied/`. This is a corrected bibliographic error, not a mathematical disproof.

## 2. Identity and data preservation

The actual manuscripts were opened and their titles, displayed draft versions and dates checked. The W5 certificate and root files are byte-identical across the two ZIP versions. Original archive identities are in `INPUT_ARCHIVES.json`; all extracted files remain unmodified.

## 3. Blindness and independent work

No previous AI reports or their code were supplied or consulted. Statements in the manuscripts asserting previous checks were read as author claims, not used as evidence. Earlier conversation messages said an exact reconstruction had run, but its executable artifacts were not present in this sandbox. The present code and outputs are fresh reconstruction and replay, not a falsely claimed recovery of those files.

## 4. Source mismatch found during geometry review

The main draft's Appendix A uses a different interval system with three k=2 returns. W5 uses a paired interval system with all k=1. A source mismatch is recorded rather than silently reconciled. A different decomposition does not itself imply a different Hurwitz component. The original gate tuple and connecting braid are absent; repository access did not resolve this. The report constructs the W5 degeneration in its own marked component and leaves the further identification conditional.

## 5. Current evidence

All three independent exact scripts were replayed successfully; four modified-input subprocesses were rejected. The report supplies a separate written geometric argument. There is no automated formal geometry proof and no global transfer-theorem certification. Source access limitations, including CKS 1986, are stated explicitly.

## 6. Release identity

The final manifest hashes delivered files, not scientific truth. Reruns can change timing fields and hashes. No source PDF was retained locally and no PDF hash is supplied. No external notice, repository write, owner adoption or RTG canonical amendment was made.
