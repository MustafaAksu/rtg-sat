# First-round blind G34-D / W5 geometric audit

Start with **GEOMETRIC_REPORT.md**. It gives all ten obligation dispositions and the independent geometric argument.

**Conclusion:** simultaneous W5 realization and rank-16 dominance are verified for the Hurwitz component defined by the supplied W5 tuple. Identification with the main manuscript's separately selected gate-tuple component remains conditional on missing tuple/braid data. The transfer/global-algebraicity chain is not certified.

Files:
- `GEOMETRIC_REPORT.md`: mathematical assessment and explicit qualifications.
- `OBLIGATIONS.json`: structured dispositions, not a machine proof.
- `SOURCE_ACCESS_LEDGER.md`: editions, actual reading scope and inaccessible sources.
- `AUDIT_TRAIL.md`: bibliographic correction, data preservation and blindness boundaries.
- `REPLAY.md`: instructions and scope of executable checks.
- `scripts/`: newly written independent verification code; no prior AI review code used.
- `outputs/`: exact results, full finite root orbit, permutations and rejection-control logs.
- `supplied/`: both original extracted packages, including their unchanged instructions and hashes.
- `MANIFEST.json` and `SHA256SUMS.txt`: byte identities of delivered files, excluding those two self-referential manifest files.

Run:

```sh
python -m pip install -r requirements.txt
python scripts/run_audit.py
```

Do not use `python -O`. Rerunning changes timing fields and thus some output hashes, but not the mathematical values. The release manifest records the delivered bytes, not arbitrary future replay bytes.

This is an independent first-round review, not author adoption, an RTG DSN change, or certification of a general Hodge-conjecture claim.
