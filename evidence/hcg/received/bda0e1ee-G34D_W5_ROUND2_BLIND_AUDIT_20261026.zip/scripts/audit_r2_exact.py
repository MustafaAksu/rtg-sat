#!/usr/bin/env python3
"""Round-2 blinded exact checks (no preexisting report outputs as inputs).

Inputs: raw W5 JSON, supplied within the unchanged Round-1 archive.
Outputs: Round2 JSON record, including deliberately failing negative controls.
Checks are finite algebra only, not formal validation of geometry, Schoen, Milne,
relative Hilbert schemes, Baire or the public Severn theorem.
"""
from pathlib import Path
from fractions import Fraction
from math import gcd
import argparse, hashlib, json
import sympy as sp
from sympy.polys.domains import QQ
from sympy.polys.matrices import DomainMatrix

R2_ROOT=Path(__file__).resolve().parents[1]
RAW=R2_ROOT/'round1/supplied/v0_2/g34_cert_tuple5_balanced.json'
RAW_HASH='172766a91017aeac62e5c299a72b2c7582b0bb186c4feaa8b1906144eafb952e'
assert __debug__, 'Do not use Python -O'

def chk(bool_expr, key, tests, note):
    ok=bool(bool_expr)
    tests.append({'key':key,'passed':ok,'detail':note})
    if not ok: raise AssertionError(f'{key}: {note}')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',default=str(R2_ROOT/'outputs/round2_exact.json'))
    args=p.parse_args(); tests=[]
    chk(hashlib.sha256(RAW.read_bytes()).hexdigest()==RAW_HASH,'SOURCE_W5_HASH',tests,'Raw source frozen SHA-256, independent of archived output JSON')
    d=json.loads(RAW.read_text())
    K=QQ.algebraic_field((-1+sp.sqrt(-3))/2)
    w=K.unit; one=K.one;zero=K.zero
    def el(pair):return K.convert(QQ(str(pair[0])))+K.convert(QQ(str(pair[1])))*w
    def mat(rows):return DomainMatrix([[el(v) for v in r] for r in rows],(len(rows),len(rows[0])),K).to_dense()
    def pr(v):
        l=v.to_list();l=[QQ.zero]*(2-len(l))+l
        return [str(l[1]),str(l[0])]
    S=mat(d['S_gram'])
    detS=S.det()
    vartheta=one+K.convert(2)*w
    chk(pr(vartheta*vartheta)==['-3','0'],'THETA_SQUARE',tests,'vartheta=1+2w; vartheta^2=-3')
    chk(pr(detS)==['19683','0'],'DET_S',tests,'det(S)=3^9 in input basis')
    h=S.scalarmul(vartheta)
    chk(pr(h.det())==['1594323','0'],'DET_H',tests,'det(theta S)=3^13')
    alpha=K.convert(729)*(K.convert(2)+w)
    def conjugate(x):
        a,b=pr(x)
        return K.convert(QQ(a))-K.convert(QQ(b))-K.convert(QQ(b))*w
    chk(pr(alpha*conjugate(alpha))==['1594323','0'],'NORM_WITNESS',tests,'N(729(2+w))=3^13')
    Ns=[mat(c['N']) for c in d['curves']]
    chk(len(Ns)==17,'TWISTS_17',tests,'Raw logarithms count 17')
    relation=Ns[16]-Ns[8]-Ns[9]
    chk(all(not x for r in relation.to_list() for x in r),'N17_RELATION',tests,'N17=N9+N10')
    # Rebuild the coefficient map directly in the field, without importing Round-1 helper outputs.
    rows=[[] for _ in range(64)]
    for M in Ns:
        a=M.to_list()
        for i in range(8):
            for j in range(8):rows[8*i+j].append(a[i][j])
    linear_map=DomainMatrix(rows,(64,17),K).to_dense()
    rr,pivots=linear_map.rref()
    chk(len(pivots)==16,'K_RANK_16',tests,'64x17 exact field matrix rank 16')
    chk(16 not in pivots,'RELATION_UNIQUE',tests,'W5 linear relation has one free direction')
    # K=Q(w), w^2+w+1=0. w, w^2, and wbar^2 are non-rational.
    w2=w*w
    wc=conjugate(w)
    wc2=wc*wc
    chk(pr(w2)[1]!='0' and pr(wc2)[1]!='0','NONRATIONAL_SQUARE',tests,'w^2 and conjugate(w)^2 are not rational')
    chk(pr(wc2)==['0','1'],'CONJ_SQUARE',tests,'conjugate(w)^2=w')
    # Under compensation contraction the second generator has relative K-coordinate w.
    # Independence of 1,w over Q is witnessed by nonzero determinant of two coordinate rows.
    basis_coordinates=[[sp.Integer(1),sp.Integer(0)], [sp.Integer(pr(wc2)[0]),sp.Integer(pr(wc2)[1])]]
    chk(sp.Matrix(basis_coordinates).det()==1,'COMPENSATOR_Q_RANK2',tests,'contracted classes with alpha=1 and alpha=w have Q-rank 2')
    # Negative control: alpha=1 and alpha=2, ratio 4 in Q, cannot yield two lines.
    fake_coordinates=sp.Matrix([[1,0],[4,0]])
    chk(fake_coordinates.det()==0,'NEGATIVE_RATIONAL_ALPHA',tests,'alpha=2 does not establish two Q-independent classes')
    samples=[Fraction(-1),Fraction(-2),Fraction(-3,5),Fraction(-7,11),Fraction(-17,4),Fraction(-999,1001)]
    witnesses=[]
    for t in samples:
        # n=4, delta=1: pick m=a*b for t=-a/b in lowest terms.
        a=abs(t.numerator);b=t.denominator;m=a*b
        target=t*Fraction(-m)
        chk(target==Fraction(a*a),'COMPENSATOR_DISC_'+str(a)+'_'+str(b),tests,'t='+str(t)+'; m='+str(m)+'; t*(-m)='+str(target)+'=Norm_Qsqrt-3('+str(a)+')')
        witnesses.append({'t':str(t),'m':m,'product_disc_representative':str(target),'norm_witness_integer':a})
    # Formal algebraic cycle class facts are NOT evaluated by a numeric script.
    result={'status':'PASS','source':str(RAW.relative_to(R2_ROOT)),
            'source_sha256':RAW_HASH,'field':'Q(w) with w^2+w+1=0','checks':tests,
            'W5':{'det_S':pr(detS),'det_h':pr(h.det()),'norm_alpha':pr(alpha),'theta':pr(vartheta),
                  'twist_count':17,'linear_map_rank_K':len(pivots),'relation':'N17=N9+N10'},
            'compensation':{'alpha_choices':['1','w'],'surviving_coefficient_ratio':pr(wc2),
                            'rational_rank':2,'discriminant_examples':witnesses},
            'not_automated':['Geometric realization of W5','polarization identification',
                             'Schoen cycle construction','Milne invariant theorem','Hilbert-scheme spreading',
                             'Baire irreducibility','Landherr isogenies','global public theorem']}
    op=Path(args.output);op.parent.mkdir(parents=True,exist_ok=True)
    op.write_text(json.dumps(result,indent=2)+'\n')
    print(f"PASS {len(tests)} exact tests; rank={len(pivots)}, det_h={pr(h.det())}, compensation Q-rank=2")
    return 0

if __name__=='__main__': raise SystemExit(main())
