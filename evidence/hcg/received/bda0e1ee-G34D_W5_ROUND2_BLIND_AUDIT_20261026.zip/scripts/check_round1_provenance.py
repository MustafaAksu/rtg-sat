#!/usr/bin/env python3
"""Immutable Round-1 archive audit and replay invariant check.

Checks mathematical invariants separately from volatile stdout/timing/file-system paths.
Does not repair or rewrite the archived first-round manifest or outputs.
"""
import hashlib,json,zipfile
from pathlib import Path
P=Path(__file__).resolve().parents[1]
ORIG=P/'round1'
REPLAY=P/'round1_replayed'
ARCHIVE=P/'artifacts/G34D_W5_FIRST_ROUND_GEOMETRIC_AUDIT_v0_1.zip'
assert __debug__
h=lambda b:hashlib.sha256(b).hexdigest()
expected=[line.split('  ',1) for line in (ORIG/'SHA256SUMS.txt').read_text().splitlines() if '  ' in line]
results=[]
for digest,name in expected:
 p=ORIG/name
 actual=h(p.read_bytes());results.append({'file':name,'manifest_sha256':digest,'archive_bytes_sha256':actual,'matches':digest==actual})
mis=[r['file'] for r in results if not r['matches']]
assert mis==[],f'Archive-integrity problem: {mis}'
with zipfile.ZipFile(ARCHIVE,'r') as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(r['file'] for r in results)|{'MANIFEST.json','SHA256SUMS.txt'}
 for r in results:
  assert z.read(r['file'])==(ORIG/r['file']).read_bytes(),r['file']
 assert z.read('MANIFEST.json')==(ORIG/'MANIFEST.json').read_bytes()
 assert z.read('SHA256SUMS.txt')==(ORIG/'SHA256SUMS.txt').read_bytes()
for fn in ['scripts/run_audit.py','scripts/verify_w5_bridge.py','scripts/verify_finite_group.py',
           'scripts/verify_extra_interfaces.py','supplied/v0_2/g34_cert_tuple5_balanced.json',
           'supplied/v0_2/roots_alt_5.json']:
 assert (ORIG/fn).read_bytes()==(REPLAY/fn).read_bytes()
mathematical={}
for fn in ['bridge_exact.json','finite_group.json','extra_interfaces.json']:
 a=json.loads((ORIG/'outputs'/fn).read_text())
 b=json.loads((REPLAY/'outputs'/fn).read_text())
 for k in ['elapsed_seconds','python_version']:a.pop(k,None);b.pop(k,None)
 assert a==b,fn
 mathematical[fn]={'status':'PASS','matches_except_volatile_fields':True}
rep=json.loads((REPLAY/'outputs/audit_replay.json').read_text())
assert rep['status']=='PASS' and len(rep['negative_controls'])==4
assert all(x['rejected'] for x in rep['negative_controls'])
assert all(x['exit_code']==0 for x in rep['exact_script_replays'])
assert len([r for r in results if r['matches']])==len(results)
record={'status':'PASS_ORIGINAL_ARCHIVE_AND_REPLAY',
        'immutable_round1_zip_sha256':h(ARCHIVE.read_bytes()),
        'source_manifest_entries':len(results),
        'manifest_pass_count':len(results)-len(mis),
        'manifest_fail_count':len(mis),
        'mismatching_files':mis,
        'mismatch_scope':'None in independently re-extracted pristine ZIP.',
        'initial_check_correction':'Initial five-file failure arose from inadvertently replaying code in a mutable extraction before checking; the immutable ZIP passes all checks. This was an audit-procedure error, not a defect in the original archive.',
        'zip_entries_match_extracted_bytes':True,
        'replay_invariant_checks':mathematical,
        'replay_driver_status':rep['status'],
        'replay_negative_controls':rep['negative_controls'],
        'mathematical_conclusion':'Original archive manifests pass and finite invariant results are stable under fresh executable replay.'}
(P/'outputs/round1_provenance_audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k in ['status','immutable_round1_zip_sha256','source_manifest_entries','manifest_pass_count','manifest_fail_count','mismatching_files','replay_driver_status']},indent=2))
