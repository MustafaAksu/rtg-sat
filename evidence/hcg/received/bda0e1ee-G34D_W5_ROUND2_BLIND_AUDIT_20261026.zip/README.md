# G34-D / W5: Round-2 independent blind audit

**Read `ROUND2_FINAL_REPORT.md` first.** This bundle preserves the complete, original Round-1 executable audit and its SHA-256 manifest, plus a fresh, independent Round-2 exact algebra script and a cross-round provenance checker.

- `ROUND2_FINAL_REPORT.md`: all R2 obligation dispositions A1–A3, B4–B7; proof assumptions, counterchecks, unresolved dependencies and public-status firewall.
- `SOURCE_ACCESS_LEDGER_R2.md`: primary manuscripts, Schoen, Milne, sources, versions, page references and access limits.
- `REPLAY.md`: byte-integrity and reproducibility instructions, with original-R1-extraction handling correction.
- `round1/`: **pristine extracted** archived Round-1 package, including all R1 scripts, original instructions, source corrections, raw W5 JSON, SHA256SUMS, detailed geometric audit and replay outputs.
- `artifacts/G34D_W5_FIRST_ROUND_GEOMETRIC_AUDIT_v0_1.zip`: unmodified 71KB original ZIP, nested for audit provenance.
- `round1_replayed/`: copied Round-1 package after a fresh successful replay, providing independently regenerated finite outputs and rejection-control logs; its original SHA manifest is not expected to match regenerated volatile output bytes.
- `scripts/audit_r2_exact.py`: exact field determinant, norm witness, independent N_j rank, and compensation/rational-independence checks; rejects nonrational-factor substitution with a negative control.
- `scripts/check_round1_provenance.py`: checks all original R1 manifest entries against the pristine extraction, ZIP byte identity, the three stable mathematical replay outputs and all four negative controls.
- `outputs/`: scripted JSON outputs and verification logs.
- `SHA256SUMS.txt`, `BUNDLE_MANIFEST.json`: precise delivered-member identities (not scientific proof).

Computational and conceptual evidence have **different scopes**. The scripts are exact computations of finite algebra; the geometric, Hodge-theoretic and cycle-transfer arguments require named external theorems and mathematical reasoning. Both Severn manuscripts are unrefereed.

No prior AI reviews were used as mathematical proof sources; original erroneous arXiv labels are preserved rather than silently edited.
