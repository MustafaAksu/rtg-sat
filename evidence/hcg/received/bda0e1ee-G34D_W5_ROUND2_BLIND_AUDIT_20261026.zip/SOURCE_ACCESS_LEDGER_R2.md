# Independent Round-2 source-access ledger

| Source | Exact edition / locator | Audit action | Access limit |
|---|---|---|---|
| Severn main | *Weil Classes on Every Abelian Sixfold of Weil Type for Q(√−3)*, Draft v0.5, 16 Oct 2026, 17 pp.; `https://hexagonmath.org/pdf/2610.00387v1` | Source title and text verified; Thm3.1, Prop4.2 Step4, Lemma5.1, Prop5.2 and stated powers condition checked | Unrefereed draft; no full PDF bytes archived |
| Severn companion | *A Transfer Theorem for Weil Classes on Prym–Tyurin Factors of Galois Covers*, Draft v0.15, 16 Oct 2026, 31 pp.; `https://hexagonmath.org/pdf/2610.00386v1` | Def2.2, Prop3.7, Cor3.8, Prop5.1, Lemmas6.1–6.2, Thm7.1, Remarks5.3/7.3–7.4 checked | Unrefereed draft; no full PDF bytes archived |
| Schoen | *Hodge classes on self-products of a variety with an automorphism*, Compositio Math. 65 (1988) 3–32; `https://www.numdam.org/article/CM_1988__65_1_3_0.pdf` | Thm2.0 and Cor3.1, branch exponent admissibility verified against original | No PDF-byte SHA available |
| Milne | *Lefschetz classes on abelian varieties*, Duke Math. J. 96 (1999); `https://www.jmilne.org/math/articles/1999aP.pdf` | Thm3.2/Lemma3.1, invariant classes from divisors and centralizer role checked | No PDF-byte SHA available |
| Dettweiler–Wewers and Schmid | See `round1/SOURCE_ACCESS_LEDGER.md` for original first-round exact bibliography and actual inspection scope | W5 cup / monodromy, Schmid 4.12/6.16 retained from R1 | CKS 1986 original full text not directly inspected |

## Source identity correction retained

Original v0.1 package inaccurately labelled Hexagon identifiers `2610.00387` and `2610.00386` as arXiv identifiers. Their true source is Hexagon Math at the two URLs above. The original unmodified instructions and v0.2 correction are both preserved within Round-1 supplied archives. This is a bibliographic error, not evidence against the mathematical proposition.

## Privacy/blindness boundary

No earlier independently prepared AI reports were used as mathematical input in Round 2. Only the supplied W5 data, the audit's own Round-1 work, the blind review question and publicly accessible primary texts were used in the scientific argument. The internal recipient/intake workflow is not an evidence source for a mathematical claim.
