#!/usr/bin/env python3
"""Fresh replay of exact arithmetic and the unchanged peer source script.
Python 3 standard library only. No network. No writes to archived inputs.
"""
from __future__ import annotations
import argparse, hashlib, shutil, subprocess, sys, tempfile
from pathlib import Path

BASE=Path(__file__).resolve().parent

def verify_manifest(root:Path, name:str)->int:
    count=0
    for line in (root/name).read_text().splitlines():
        if not line.strip():continue
        digest,rel=line.split(maxsplit=1); rel=rel.lstrip('*')
        pp=Path(rel)
        if pp.is_absolute() or '..' in pp.parts:raise ValueError(f'Unsafe path: {rel}')
        p=root/pp
        actual=hashlib.sha256(p.read_bytes()).hexdigest()
        if actual!=digest:raise RuntimeError(f'Hash mismatch: {rel}')
        count+=1
    return count

def main()->None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--quick',action='store_true',help='Skip only the source weighted-twist enumeration.')
    args=ap.parse_args()
    n=verify_manifest(BASE,'SHA256SUMS.txt')
    ns=verify_manifest(BASE/'source','BUNDLE_SHA256SUMS.txt')
    print(f'BUNDLE MANIFEST: {n}/{n} PASS',flush=True)
    print(f'SOURCE MANIFEST: {ns}/{ns} PASS',flush=True)
    with tempfile.TemporaryDirectory(prefix='hcg_tensor_frontier_replay_') as td:
        temp=Path(td)
        for script,result in [('independent_tensor_frontier_checks.py','INDEPENDENT_CHECKS.json'),
                              ('d25_rank3_spectral_screen.py','D25_RANK3_SPECTRA.json')]:
            p=temp/script;shutil.copy2(BASE/script,p)
            run=subprocess.run([sys.executable,'-I',str(p)],cwd=temp,capture_output=True,timeout=90)
            if run.returncode:
                raise RuntimeError(script+' failed:\n'+run.stderr.decode(errors='replace'))
            if (temp/result).read_bytes()!=(BASE/result).read_bytes():
                raise RuntimeError(f'Output mismatch: {result}')
            print(script+': BYTE-IDENTICAL PASS',flush=True)
        if not args.quick:
            script='d15_24_checks_claude.py';p=temp/script
            shutil.copy2(BASE/'source'/script,p)
            run=subprocess.run([sys.executable,'-I',str(p)],cwd=temp,capture_output=True,timeout=240)
            if run.returncode:raise RuntimeError(run.stderr.decode(errors='replace'))
            expected=(BASE/'source'/'d15_24_checks_claude_out.txt').read_bytes()
            if run.stdout!=expected:raise RuntimeError('Peer source stdout mismatch')
            print('UNCHANGED CLAUDE SOURCE: BYTE-IDENTICAL PASS',flush=True)
    # Verify execution did not mutate any archived source or expected output.
    assert verify_manifest(BASE,'SHA256SUMS.txt')==n
    print('FRESH REPLAY PASS'+(' (QUICK; SOURCE EXECUTION SKIPPED)' if args.quick else ''),flush=True)

if __name__=='__main__':main()
