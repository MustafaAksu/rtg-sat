#!/usr/bin/env python3
"""Proposed finite spectral screen for rank-three elements in the remaining d=25 case.

Assumption: every nonidentity power is noncentral and has age > 1;
coefficient field K=Q(sqrt(-3)); moving polynomial degree three.
This is not a group or family search. Pure Python standard library.
"""
from fractions import Fraction as Q
from itertools import product, combinations_with_replacement
from math import gcd
from pathlib import Path
import json

def phi(n):
    return sum(gcd(k,n)==1 for k in range(1,n+1))

def main():
    # Exhaustive: phi(q)<=6 forces primes<=7 and these prime-power exponents.
    all_q=sorted({(2**a)*(3**b)*(5**c)*(7**d)
                 for a,b,c,d in product(range(4),range(3),range(2),range(2))
                 if phi((2**a)*(3**b)*(5**c)*(7**d))<=6})
    orders=[]
    for q in all_q:
        if q==1: continue
        degree=phi(q)//2 if q%3==0 else phi(q)
        if 3%degree==0: orders.append(q)
    assert orders==[2,3,6,9,18]
    survived=[];rejected=[]; candidates=0
    for q in orders:
        units=[j for j in range(1,q) if gcd(j,q)==1]
        aut=[u for u in units if q%3!=0 or u%3==1]
        for roots in combinations_with_replacement(units,3):
            if any(sorted(u*x%q for x in roots)!=list(roots) for u in aut):
                continue
            candidates+=1
            allpowers=[]
            for power in range(1,q):
                exp=[(power*x)%q for x in roots]
                age=sum((Q(x,q) for x in exp),Q(0))
                assert all(x!=0 for x in exp)  # all three eigenvalues primitive qth roots
                allpowers.append((power,age))
            bad=next(((k,a) for k,a in allpowers if a<=1),None)
            row={'order':q,'primitive_exponents':list(roots),
                 'age':str(sum((Q(x,q) for x in roots),Q(0))),
                 'inverse_age':str(sum((Q(q-x,q) for x in roots),Q(0))),
                 'determinant_argument_mod_1':str(sum((Q(x,q) for x in roots),Q(0))%1)}
            if bad:
                row.update({'rejected_power':bad[0],'rejected_age':str(bad[1])}); rejected.append(row)
            else: survived.append(row)
    assert candidates==13 and len(survived)==5
    assert {(x['order'],tuple(x['primitive_exponents'])) for x in survived}=={
        (2,(1,1,1)),(3,(1,1,2)),(3,(1,2,2)),(6,(1,1,5)),(6,(1,5,5))}
    result={'status':'PROPOSED_SPECTRAL_SCREEN_EXACT_CHECK_PASS',
            'all_orders_with_phi_at_most_6':all_q,
            'admissible_orders_before_terminal_check':orders,
            'Galois_stable_moving_spectra_checked':candidates,
            'surviving_spectra':survived,'rejected_spectra':rejected,
            'limitations':'Necessary element-level spectra only. No group, product-one tuple, nonnorm discriminant, supplier condition, or dominance witness constructed.'}
    text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    (Path(__file__).resolve().parent/'D25_RANK3_SPECTRA.json').write_text(text)
    print(text)

if __name__=='__main__':main()
