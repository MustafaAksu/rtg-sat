# HCG tensor/frontier independent review package v0.1

Date: 2026-10-29. INTERNAL. No PI adoption or repository edits.

## Read first

- `HCG_TENSOR_FRONTIER_CHATGPT_CROSS_REVIEW_v0_1.md`: the review, proofs, source-scope clarification and limits.
- `HCG_D25_TERMINAL_LOCAL_SIEVE_PROPOSED_v0_1.md`: a separately labelled new SESSION proposal (no-junior centre refinement and five rank-three moving spectra). It has NOT received peer review.
- `HCG_TENSOR_FRONTIER_LEDGER_PROPOSAL_v0_1.md`: suggested dispositions; no owner or PI fields were modified.

## Replay

Requires Python 3.10 or later, standard library only.

```
python -I replay.py
```

The driver checks all hashes, executes both independent scripts in a fresh temporary directory, compares their complete JSON outputs byte-for-byte, executes the unchanged Claude source script in the same temporary workspace and compares its complete stdout, then rechecks the immutable archive hashes.

For just the independent arithmetic tests:

```
python -I replay.py --quick
```

The original supplied ZIP is preserved byte-for-byte; its extracted contents are under `source/`. The two implementations share the mathematical input claims but do not import each other's code. Finite tests are not proofs of external classification or of Hodge-theoretic factorization. No group or nonsplit family of dimension 25, 42, 50 or 256 is constructed.

## Primary-source access

GT source inspection was targeted parsed text; PDF screenshot/direct-download attempts failed. Candelori Theorem 3.1 was inspected in text and by PDF screenshot. The sources' complete classification/proof chains were not re-established. Exact links and section scope are in the review; primary PDF binaries are not included.

`SOURCE_REPLAY_RECEIPT.json` records the actual source replay during this review, including elapsed time. It is an execution receipt, not a trusted timestamp or mathematical adoption certificate. The manifest excludes itself by design.
