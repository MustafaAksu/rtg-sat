#!/usr/bin/env python3
"""Independent exact arithmetic checks for the HCG tensor/frontier review.

Standard library only. Does not import the submitted Claude script.
These finite checks accompany written proofs; they do not prove GT classification,
Chevalley-Weil, existence of a cover, or dominance of any family.
"""
from __future__ import annotations
from fractions import Fraction as Q
from itertools import combinations_with_replacement
from math import gcd, lcm
from pathlib import Path
import json


def partitions(n: int, least: int = 1):
    if n == 0:
        yield ()
        return
    for first in range(least, n + 1):
        for tail in partitions(n - first, first):
            yield (first,) + tail


def orbit_number(a: int, cycle_lengths: tuple[int, ...]) -> int:
    """Burnside count for the cyclic factor permutation on [a]^m."""
    order = lcm(*cycle_lengths)
    total = sum(a ** sum(gcd(length, j) for length in cycle_lengths)
                for j in range(order))
    assert total % order == 0
    return total // order


def cyclic_orbit_checks():
    rows = []
    checks = 0
    negative_controls = 0
    for a in range(2, 13):
        for m in range(2, 9):
            d = a ** m
            for shape in partitions(m):
                if shape == (1,) * m:
                    continue
                fixed = orbit_number(a, shape)
                lower = Q(a ** (m-1) * (a-1), 2)
                assert d - fixed >= lower
                checks += 1
            shape = (1,) * (m-2) + (2,)
            achieved = d - orbit_number(a, shape)
            assert achieved == Q(a ** (m-1) * (a-1), 2)
            # Omitting the 1/2 would incorrectly reject this exact example.
            assert achieved < a ** (m-1) * (a-1)
            negative_controls += 1
    for a, m in [(2,4),(4,2),(5,2)]:
        d = a ** m
        actual = min(d - orbit_number(a, sh) for sh in partitions(m)
                     if sh != (1,) * m)
        expected = {(2,4):4,(4,2):6,(5,2):10}[(a,m)]
        assert actual == expected
        rows.append({'a':a,'m':m,'dimension':d,
                     'minimum_factor_permutation_rank':actual,
                     'base_nonscalar_rank_bound':a**(m-1)})
    return {'cycle_type_checks':checks,
            'missing_half_negative_controls':negative_controls,
            'special_shapes':rows}


def tensor_spectrum_checks():
    """Exhaust small multiplicity vectors of sixth roots for A and B."""
    total=0
    def spectra(n):
        for seq in combinations_with_replacement(range(6),n):
            mult=[seq.count(i) for i in range(6)]
            yield mult
    for a in range(2,5):
        aa=list(spectra(a))
        for b in range(a,7):
            bb=list(spectra(b))
            for x in aa:
                for y in bb:
                    moving=a*b-sum(x[i]*y[-i%6] for i in range(6))
                    if max(x)<a:
                        assert moving>=b
                    if max(y)<b:
                        assert moving>=a
                    total+=1
    return total


def budget_checks():
    factorwise=[]
    for a in range(2,128):
        for b in range(a,512):
            if 3*b+16*a <= 2*a*b+8:
                factorwise.append((a*b,a,b))
                break
    fwmin=min(factorwise)
    assert fwmin==(42,3,14)

    induced=[]
    tested=0
    # This is an exhaustive arithmetic exclusion below 256: a^m < 256.
    for a in range(2,257):
        m=2
        while a**m<=65536:
            d=a**m
            perm=Q(a**(m-1)*(a-1),2)
            base=a**(m-1)
            # Need >=2 factor movers, but the remaining branches can also move factors.
            need=2*perm+17*min(perm,base)
            if d<256:
                assert need>2*d+8
                tested+=1
            if need<=2*d+8:
                induced.append((d,a,m))
            m+=1
    imin=min(induced)
    assert imin==(256,16,2)

    frontier=[]
    for d in range(25,42):
        shapes=[]
        for k in range(2,d+1):
            if d%k==0:
                r=d//k
                if r>=6 and r+2*k>=17:
                    shapes.append([k,r])
        if shapes:
            frontier.append({'d':d,'k_r_shapes':shapes})
    assert [z['d'] for z in frontier]==[26,28,30,32,33,34,35,36,38,39,40]
    return {'factorwise_minimum_budget_tuple':list(fwmin),
            'tensor_induced_minimum_budget_tuple':list(imin),
            'tensor_induced_excluded_shapes_below_256':tested,
            'K_defined_imprimitive_dimension_lower_bound':50,
            'complex_imprimitive_frontier_25_41':frontier}


def age_checks():
    cases=[('W5',6,[Q(1,2)]*20,4,4),
           ('C6',1,[Q(k,6) for k in [2]*5+[3]+[4]*3+[5]],4,4),
           ('C3',1,[Q(k,3) for k in [1]*5+[2]*5],4,4),
           ('odd_n',1,[Q(1,3),Q(1,3),Q(2,3),Q(2,3)],1,1)]
    out=[]
    for name,d,angles,p,q in cases:
        sa=sum(angles,Q(0)); sb=sum((1-x for x in angles),Q(0))
        assert sa==d+p and sb==d+q
        out.append({'name':name,'age_sum':str(sa),'inverse_age_sum':str(sb)})
    # Convention-sensitive asymmetric control: in Candelori's convention,
    # h^{1,0}_rho=-d+sum age(g^-1), h^{1,0}_bar(rho)=-d+sum age(g).
    angles=[Q(1,6),Q(1,6),Q(1,6),Q(1,2)]
    d=1
    assert -d+sum((1-x for x in angles),Q(0))==2
    assert -d+sum(angles,Q(0))==0
    out.append({'name':'asymmetric_dual_convention_control',
                'sum_age':str(sum(angles,Q(0))),
                'sum_inverse_age':str(sum((1-x for x in angles),Q(0))),
                'holomorphic_multiplicity_rho':2,'holomorphic_multiplicity_bar_rho':0})
    # d=25: all c>=3 and sum c=58 => N=19, one c=4, eighteen c=3.
    feasible=[]
    for N in range(19,30):
        if 3*N<=58:
            feasible.append({'N':N,'rank_surplus_above_three':58-3*N})
    assert feasible==[{'N':19,'rank_surplus_above_three':1}]
    return {'checks':out,'d25_pattern':{'N':19,'ranks':[3]*18+[4],
            'sum_ranks':58,'age_sum_each_orientation':29},
            'central_scalar_age_lower_bound_d25':'25/6'}


def main():
    output={'status':'ALL_EXACT_CHECKS_PASS',
            'permutation_tensor':cyclic_orbit_checks(),
            'tensor_spectrum_checks':tensor_spectrum_checks(),
            'budgets':budget_checks(),
            'age_checks':age_checks(),
            'scope':'Finite arithmetic checks and negative controls; not a proof of external classification or a family construction.'}
    text=json.dumps(output,indent=2,sort_keys=True)+'\n'
    (Path(__file__).resolve().parent/'INDEPENDENT_CHECKS.json').write_text(text)
    print(text)

if __name__=='__main__':
    main()
