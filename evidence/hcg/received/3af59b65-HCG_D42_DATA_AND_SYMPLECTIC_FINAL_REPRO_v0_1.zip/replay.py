#!/usr/bin/env python3
"""Replay exact character checks from shared CTblLib bytes (no GAP or network).

Python >=3.9, standard library only. No original evidence is overwritten.
The finite tests do not prove the external classifications or the new d=26 proof.
"""
from pathlib import Path
import hashlib
import os
import runpy
import contextlib
import io
import sys
import tempfile
import shutil

ROOT=Path(__file__).resolve().parent

def check_manifest(root: Path, manifest_name: str) -> int:
    count=0
    for line in (root/manifest_name).read_text().splitlines():
        if not line.strip():continue
        digest,relative=line.split(None,1)
        relative=relative.strip().lstrip('*')
        p=(root/relative).resolve()
        if root.resolve() not in p.parents:
            raise RuntimeError('Manifest path escapes package: '+relative)
        if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Hash mismatch: '+relative)
        count+=1
    return count

def main() -> None:
    package_count=check_manifest(ROOT,'SHA256SUMS.txt')
    source_count=check_manifest(ROOT/'source','BUNDLE_SHA256SUMS.txt')
    print('INITIAL MANIFESTS PASS',flush=True)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    with tempfile.TemporaryDirectory(prefix='hcg_d42_replay_') as temp:
        t=Path(temp)
        shutil.copytree(ROOT/'checks',t/'checks')
        inp=t/'all_candidate_character_data.json'
        inp.write_bytes((ROOT/'source/all_candidate_character_data.json').read_bytes())
        old_argv = sys.argv[:]
        old_path = sys.path[:]
        old_bytecode = sys.dont_write_bytecode
        sys.path.insert(0,str(t/'checks'))
        sys.dont_write_bytecode=True
        try:
            out=t/'raw_data_and_bounds.json'
            charout=t/'character_results.json'
            capture=io.StringIO()
            sys.argv=[str(t/'checks/audit_raw_data_and_bounds.py'),str(inp),str(out),str(charout)]
            with contextlib.redirect_stdout(capture):
                runpy.run_path(sys.argv[0],run_name='__main__')
            if charout.read_bytes()!=(ROOT/'expected/verify_out_chatgpt.json').read_bytes():
                raise RuntimeError('Character output differs from frozen expected output')
            if out.read_bytes()!=(ROOT/'expected/raw_data_and_bounds.json').read_bytes():
                raise RuntimeError('Raw-data or bound output differs from expected output')
            print(capture.getvalue(),end='',flush=True)
        finally:
            sys.argv=old_argv
            sys.path[:]=old_path
            sys.dont_write_bytecode=old_bytecode
    if check_manifest(ROOT,'SHA256SUMS.txt')!=package_count:
        raise RuntimeError('Package manifest changed')
    if check_manifest(ROOT/'source','BUNDLE_SHA256SUMS.txt')!=source_count:
        raise RuntimeError('Source manifest changed')
    print(f'PACKAGE MANIFEST {package_count}/{package_count} PASS')
    print(f'SOURCE MANIFEST {source_count}/{source_count} PASS')
    print('CHARACTER OUTPUT: 20/20; BYTE-IDENTICAL TO SOURCE VERIFY_OUT.JSON')
    print('FRESH REPLAY PASS — NO GAP EXECUTED; SHARED CTBLLIB INPUT')

if __name__=='__main__':main()
