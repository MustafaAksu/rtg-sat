# Proposed HCG ledger delta — 30 October 2026

INTERNAL / SESSION. PI adoption field left blank. Existing HCG v0.2 remains unchanged.

| Result | Proposed review status | Scope/dependencies |
|---|---|---|
| Exact raw-character data: all 20 characters, 9 group-degree pairs, outer fusion | CHECKED | GAP source computation plus separate exact Python reconstruction; shared CTblLib 1.3.7 bytes. Source JSON SHA-256 78030350699ee7ccce0db8b5d78ec2f1db564d0080dbe815a6d8f417c58b63e3. |
| 25<=d<=42 primitive exclusion | CHECKED | Complex-primitive, factorwise tensor-indecomposable, not tensor-induced branch only. Completeness from Hiss–Malle, reduction from GT08, missing 2.S8(3) table handled by repaired Weil estimate, not by this JSON. |
| All-dimensional symplectic-type exclusion | CHECKED | N>=19 and sum c_j=2d+8; normal irreducibly acting symplectic-type subgroup, possibly after scalar normalization. Same proof works for all primes. |
| Existing nonsplit lower bound d>=26 | CHECKED, unchanged | No new global lower bound adopted. |
| New non-K-defined two-block d=26 obstruction | PROPOSED | New Galois/Clifford plus reflection-generation argument. Peer review required. |
| Candidate improvement d>=28 | PROPOSED, contingent on previous row | Uses previously checked d=27 exclusion; no existence assertion at d=28. |
| d=42 factorwise tensor and imprimitive branches | OPEN | Not excluded by the primitive result. |
| HCG-OPEN-NONSPLIT8 | OPEN | Research continues; no candidate family is constructed here. |
| Severn A/B/C | CLAIMED, unchanged | No adoption or new human-referee decision. |
