# HCG D42 data closure, symplectic-type proof, and degree-26 proposal

Internal session evidence, 30 October 2026. No changes to adopted documents.

Run from the extracted folder with Python >=3.9:

```text
python replay.py
```

The script checks the package manifest and the eight source-manifest entries, then runs the original exact Python character verifier and an additional raw-data audit in one temporary workspace. Repeated exact cyclic spectra are memoized; no previously computed rank is used as input. All output JSON is compared byte-for-byte. No GAP installation, network access, or third-party Python packages are needed.

- `source/`: received Claude report, shared CTblLib data, exporter, source outputs and original manifest, unchanged.
- `SOURCE_*.zip`: unchanged received source ZIP.
- `checks/verify_character_export.py`: original ChatGPT verifier recovered from the preceding package, unchanged. Its old introductory comment describes that earlier session; the present report records that it has now been run on the actual data.
- `checks/audit_raw_data_and_bounds.py`: independent additional schema, power-order, scalar-class, Fourier, negative-control and budget checks.
- `expected/`: results produced in this session, including the byte-identical 20-character output.
- `reports/`: completed character/symplectic review and separately PROPOSED degree-26 Galois/reflection obstruction.

The source's `weil_trace_sanity.g` and exporter are included as evidence but not executed by this replay. CTblLib values/fusions are common data, not independently reconstructed finite groups. The Hiss–Malle classification and classical Weil formula remain external theorem inputs. Numeric budget checks do not validate the Galois/Clifford/classification proof in the degree-26 proposal.

The new degree-26 proof is NOT CHECKED or adopted merely because the computational replay passes. It requires independent mathematical peer review.
