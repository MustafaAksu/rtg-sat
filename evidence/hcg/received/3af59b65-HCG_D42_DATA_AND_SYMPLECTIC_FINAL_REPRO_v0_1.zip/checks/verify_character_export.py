#!/usr/bin/env python3
"""Independent exact character-to-eigenvalue check using only Python stdlib.
Raw GAP table export is needed for a real table replay. In this session only
--self-test was executed, NOT the absent 20-character data export.
"""
from functools import lru_cache
from fractions import Fraction as Q
from math import gcd,lcm
import json,sys

def divexact(a,b):
    a=list(a);out=[0]*(len(a)-len(b)+1)
    while len(a)>=len(b):
        c=a[-1];k=len(a)-len(b);out[k]=c
        for j,x in enumerate(b):a[k+j]-=c*x
        while a and a[-1]==0:a.pop()
    assert not a
    return tuple(out)
@lru_cache(None)
def cyclo(n):
    a=[-1]+[0]*(n-1)+[1]
    for d in range(1,n):
        if n%d==0:a=divexact(a,cyclo(d))
    return tuple(a)
@lru_cache(None)
def powers(n):
    p=cyclo(n);D=len(p)-1;v=[1]+[0]*(D-1);res=[]
    for k in range(n):
        res.append(tuple(v));q=[0]+v;c=q.pop()
        v=[q[j]-c*p[j] for j in range(D)]
    assert v==[1]+[0]*(D-1)
    return tuple(res)

def eigen_multiplicities(traces):
    o=len(traces);M=lcm(o,3);ps=powers(M);D=len(ps[0]);out=[]
    for k in range(o):
        coeff=[Q(0)]*D
        for j,(a,b) in enumerate(traces):
            e=(-j*k*(M//o))%M
            for h in range(D):coeff[h]+=a*ps[e][h]+b*ps[(e+M//3)%M][h]
        coeff=[v/o for v in coeff]
        assert all(v==0 for v in coeff[1:]),(o,k,coeff)
        assert coeff[0].denominator==1 and coeff[0]>=0,(o,k,coeff)
        out.append(int(coeff[0]))
    assert sum(out)==traces[0][0] and traces[0][1]==0
    return out

def selftest():
    cases=[([(Q(27),Q(0)),(Q(15),Q(0))],[21,6]),
           ([(Q(2),Q(0)),(Q(-1),Q(0)),(Q(-1),Q(0))],[0,1,1]),
           ([(Q(3),Q(0)),(Q(-1),Q(1)),(Q(-2),Q(-1))],[0,2,1]),
           ([(Q(4),Q(0)),(Q(0),Q(0)),(Q(-4),Q(0)),(Q(0),Q(0))],[0,2,0,2])]
    for traces,expected in cases:assert eigen_multiplicities(traces)==expected
    # A negative control: this cannot be an honest cyclic restriction.
    try:eigen_multiplicities([(Q(3),Q(0)),(Q(2),Q(0))])
    except AssertionError:pass
    else:raise AssertionError('Negative eigen-multiplicity control failed')
    return {'synthetic_positive_tests':len(cases),'negative_control':True,'real_gap_tables_tested':False}

def run(data):
    records=[]
    expected={('3.O7(3)',27):(2,6),('3.G2(3)',27):(4,12),('U4(2)',30):(2,12),
              ('2.U4(2)',36):(2,18),('3_2.U4(3)',36):(2,16),('6.A7',36):(2,24),
              ('6.L3(4)',36):(2,16),('U4(2)',40):(2,20),('S8(3)',41):(2,16)}
    seen=set()
    for t in data['tables']:
        name=t['name'];d=t['dimension'];key=(name,d);seen.add(key)
        number,min_expected=expected[key];assert len(t['characters'])==number
        center=set(t['center']);o=t['orders']
        for ch in t['characters']:
            values=[(Q(a),Q(b)) for a,b in ch['values']]
            mrs=[];pmrs=[]
            for i,oi in enumerate(o):
                if i in center:continue
                f=t['powers'][i];assert len(f)==oi and f[0]==0
                es=eigen_multiplicities([values[j] for j in f])
                mrs.append(d-es[0]);pmrs.append(d-max(es))
            r={'name':name,'d':d,'row_id':ch['row_id'],'min_moving_rank':min(mrs),'min_projective_moving_rank':min(pmrs)}
            assert r['min_moving_rank']==min_expected,r
            if name=='3.O7(3)':
                assert min(pmrs)==6
                assert t['outer_index']==2
                fusion=t['outer_fusion'];fibers={};bad=[]
                for i,a in enumerate(fusion):
                    if a in fibers and values[i]!=values[fibers[a]]:bad.append([fibers[a],i])
                    else:fibers[a]=i
                assert bad,'No independent outer-invariance obstruction'
                r['outer_character_not_fixed']=True;r['fusion_witness']=bad[0]
            records.append(r)
    assert seen==set(expected)
    return {'gap_version':data['gap_version'],'ctbllib_version':data['ctbllib_version'],'characters_checked':len(records),'records':records}
if __name__=='__main__':
    if len(sys.argv)==2 and sys.argv[1]=='--self-test':print(json.dumps(selftest(),indent=2))
    elif len(sys.argv)==2:
        with open(sys.argv[1],encoding='utf-8') as f:result=run(json.load(f))
        print(json.dumps(result,indent=2))
    else:raise SystemExit('usage: verify_character_export.py --self-test | all_candidate_character_data.json')
