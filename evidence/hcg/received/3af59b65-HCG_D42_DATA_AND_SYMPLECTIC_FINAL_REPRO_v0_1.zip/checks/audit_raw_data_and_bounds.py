#!/usr/bin/env python3
"""Independent source-data consistency and exact arithmetic checks.

The character data are shared CTblLib input. This program does not reconstruct
CTblLib or prove classification completeness, symplectic-type theorems, or Hodge
factorization. Its output checks raw table consistency and finite consequences.
Uses only the Python standard library.
"""
from __future__ import annotations
from fractions import Fraction as Q
from math import gcd
from pathlib import Path
from collections import Counter
from copy import deepcopy
import json
import sys
import verify_character_export as verifier
from functools import lru_cache

# Repeated classes often have identical cyclic trace vectors. Memoize only this
# pure exact calculation; no stored moving-rank answer is used as input.
_original_eigen_multiplicities = verifier.eigen_multiplicities
@lru_cache(maxsize=None)
def _cached_spectrum(traces):
    return tuple(_original_eigen_multiplicities(traces))
def _spectrum_with_cache(traces):
    return list(_cached_spectrum(tuple(traces)))
verifier.eigen_multiplicities = _spectrum_with_cache


def ensure(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def audit(data: dict) -> dict:
    counts = Counter()
    summary = []
    for t in data['tables']:
        d = t['dimension']; orders = t['orders']; nclasses = len(orders)
        power_maps = t['powers']; center = set(t['center'])
        ensure(orders[0] == 1, 'Identity class must have order 1')
        ensure(len(power_maps) == nclasses, 'Missing power maps')
        ensure(len(center) == len(t['center']), 'Duplicated central class')
        for i, order in enumerate(orders):
            f = power_maps[i]
            ensure(int(t['group_order']) % order == 0, 'Class order does not divide group order')
            ensure(len(f) == order and f[0] == 0, 'Wrong power-map length or identity')
            if order > 1:
                ensure(f[1] == i, 'First power must return the original class')
            for j, pos in enumerate(f):
                ensure(0 <= pos < nclasses, 'Power position out of range')
                ensure(orders[pos] == order // gcd(order, j), 'Power order inconsistent')
                counts['power_entries_checked'] += 1
        rowids = [c['row_id'] for c in t['characters']]
        ensure(len(rowids) == len(set(rowids)), 'Duplicate character row')
        chars = []
        for ch in t['characters']:
            values = [(Q(a), Q(b)) for a, b in ch['values']]
            ensure(len(values) == nclasses and values[0] == (Q(d), Q(0)), 'Wrong degree')
            ensure(any(b != 0 for a, b in values), 'Character is not genuinely K-valued')
            ensure(all(a.denominator == 1 and b.denominator == 1 for a,b in values),
                   'Nonintegral Eisenstein coefficient in character value')
            scalar = {i for i,(a,b) in enumerate(values) if a*a-a*b+b*b == d*d}
            ensure(scalar == center, 'Center does not match the scalar character classes')
            ensure([i for i,v in enumerate(values) if v == (Q(d), Q(0))] == [0],
                   'Character has a nontrivial kernel')
            for i, f in enumerate(power_maps):
                mult = verifier.eigen_multiplicities([values[j] for j in f])
                ensure(sum(mult) == d, 'Wrong total eigenspace multiplicity')
                counts['cyclic_restrictions_checked_including_center'] += 1
                counts['individual_eigenmultiplicities_checked'] += len(mult)
            chars.append(tuple(values))
            counts['characters_checked'] += 1
        for vals in chars:
            conj = tuple((a-b,-b) for a,b in vals)
            ensure(conj in chars, 'Complex-conjugate character missing')
        counts['tables_checked'] += 1
        summary.append({'name':t['name'], 'degree':d, 'classes':nclasses,
                        'characters':len(chars), 'central_classes':len(center)})
    return {'status':'PASS', 'counts':dict(counts), 'tables':summary}


def negative_checks(data: dict) -> list[dict]:
    out=[]
    for name, mutation in [
        ('corrupt_character_degree', 'degree'),
        ('corrupt_first_power', 'power'),
        ('remove_genuine_scalar_class', 'center')]:
        x=deepcopy(data)
        if mutation=='degree':
            x['tables'][0]['characters'][0]['values'][0][0]='28'
        elif mutation=='power':
            x['tables'][0]['powers'][3][1]=0
        else:
            x['tables'][0]['center'].remove(1)
        try:
            audit(x)
        except (AssertionError,ValueError,IndexError,KeyError) as exc:
            out.append({'control':name,'rejected':True,'reason':str(exc)})
        else:
            raise AssertionError('Negative raw-data control not rejected: '+name)
    x=deepcopy(data)
    n=len(x['tables'][0]['outer_fusion'])
    x['tables'][0]['outer_fusion']=list(range(n))
    try:
        verifier.run(x)
    except AssertionError:
        out.append({'control':'replace_outer_fusion_by_injective_map','rejected':True})
    else:
        raise AssertionError('Negative outer-fusion control not rejected')
    return out


def bounds() -> dict:
    # Proof of the all-dimensional inequality is in the mathematical report;
    # this finite regression only checks representative degrees and margins.
    symp=[]
    for p in (2,3,5,7,11):
        for a in range(1,9):
            d=p**a
            if d<3: continue
            upper=Q(4*d+16,19)
            lower=Q(d*(p-1),p)
            ensure(upper < Q(d,2) <= lower,'Symplectic-type inequality regression')
            symp.append({'p':p,'a':a,'d':d,'upper':str(upper),'lower':str(lower)})
    types=[]
    for k in range(2,27):
        if 26%k: continue
        r=26//k
        if r>=6 and r+2*k>=17:
            types.append([k,r])
    ensure(types==[[2,13]], 'Unexpected degree-26 block structure')
    equality=[]
    # gamma=0 is inherited from the previously checked period factorization.
    # J=2 implies exactly two swapping local monodromies.
    for N in range(19,31):
        minimum=2*13+2*(N-2)
        if minimum <= 60:
            equality.append({'N':N,'min_moving_sum':minimum,'defect':60-minimum})
    ensure(equality==[{'N':19,'min_moving_sum':60,'defect':0}], 'Unexpected slack')
    return {'symplectic_regression':symp,
            'd26_possible_block_shapes':types,
            'd26_equality_cases':equality,
            'd26_rank_pattern':[13,13]+[2]*17,
            'd26_upstairs_effective_points_if_blocks_Galois_exchanged':34,
            'interpretation':'Arithmetic checks only; Galois descent and classification are proved in the separate proposed note.'}


def main() -> None:
    if len(sys.argv) not in (3,4):
        raise SystemExit('usage: audit_raw_data_and_bounds.py INPUT_JSON OUTPUT_JSON [CHARACTER_OUTPUT_JSON]')
    data=json.loads(Path(sys.argv[1]).read_text())
    out={'raw_data_audit':audit(data), 'negative_controls':negative_checks(data),
         'exact_budget_checks':bounds()}
    Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n')
    if len(sys.argv)==4:
        verified=verifier.run(data)
        Path(sys.argv[3]).write_text(json.dumps(verified,indent=2)+'\n')
    print(json.dumps(out['raw_data_audit']['counts'],indent=2))
    print('NEGATIVE CONTROLS',len(out['negative_controls']))
    print('ALL RAW-DATA AND EXACT BUDGET CHECKS PASS')

if __name__=='__main__':main()
