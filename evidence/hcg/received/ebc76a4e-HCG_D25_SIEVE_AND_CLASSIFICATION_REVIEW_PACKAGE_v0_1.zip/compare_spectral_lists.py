"""Compare every moving eigenvalue tuple, not only counts, against the frozen peer log."""
from pathlib import Path
from fractions import Fraction as Q
import json,re
B=Path(__file__).resolve().parent
v=json.loads((B/'independent_sieve_result.json').read_text())
tokens={'z6':Q(1,6),'z6b':Q(5,6),'w':Q(1,3),'wb':Q(2,3),'-1':Q(1,2),'i':Q(1,4),'-i':Q(3,4)}
sets={3:set(),4:set()};rank=None
for line in (B/'source/d25_terminal_sieve_claude_out.txt').read_text().splitlines():
    if line.startswith('rank '):rank=int(line.split(':',1)[0].split()[1])
    m=re.match(r'\s+\(([^()]*)\)\s+order',line)
    if m:
        vals=[]
        for atom in m.group(1).split(','):
            vals.append(tokens[atom] if atom in tokens else Q(atom.removeprefix('e^')))
        sets[rank].add(tuple(sorted(vals)))
for rank in [3,4]:
    ours={tuple(Q(a) for a in row['spectrum']) for row in v[str(rank)]['terminal_spectra']}
    assert sets[rank]==ours,(rank,sets[rank]^ours)
    print('RANK',rank,'EXACT SPECTRUM SET EQUALITY',len(ours),'PASS')
assert v['terminal_budget']['spectrum_level_count']==6548
assert v['GT13_budget']['age_level_count']==92 and v['GT13_budget']['spectrum_level_count']==210
print('LOCAL COUNT CROSSCHECK PASS')
