"""Independent local cyclotomic-orbit sieve, exact rational ages and algebraic traces.
No producer modules are imported. Rank-4 ages and actual spectra are counted separately.
"""
from fractions import Fraction as Q
from math import gcd,lcm,prod
from collections import Counter
from itertools import product
import json
from pathlib import Path
import sympy as s
BASE=Path(__file__).resolve().parent
X=s.Symbol('X');w=(-1+s.sqrt(-3))/2

def phi(n): return sum(gcd(j,n)==1 for j in range(1,n+1))
# If [Q(zeta_q):K]<=4 then phi(q)<=8. p-1|phi(q) gives p<=7,
# and p^(a-1)(p-1)<=8 gives q|2^4*3^2*5*7. Exhaust this finite set.
orders=sorted({2**a*3**b*5**c*7**d for a,b,c,d in product(range(5),range(3),range(2),range(2)) if 1<2**a*3**b*5**c*7**d and phi(2**a*3**b*5**c*7**d)<=8})
orbits=[]; factor_degrees={}
for q in orders:
    U=[u for u in range(1,q) if gcd(u,q)==1 and (q%3!=0 or u%3==1)]
    rem={a for a in range(1,q) if gcd(a,q)==1}
    local=[]
    while rem:
        a=min(rem); orb=tuple(sorted({Q(a*u%q,q) for u in U}));rem-={int(v*q) for v in orb}
        local.append(orb)
    # independent exact factorization over K corroborates orbit sizes
    factors=s.factor_list(s.cyclotomic_poly(q,X),X,extension=s.sqrt(-3))[1]
    assert sorted(s.degree(f,X) for f,m in factors for _ in range(m)) == sorted(map(len,local))
    factor_degrees[str(q)]=sorted(map(len,local))
    orbits.extend(orb for orb in local if len(orb)<=4)
orbits.sort()

def spectra(c):
    out=set()
    def rec(j,left,v):
        if left==0:out.add(tuple(sorted(v)));return
        if j==len(orbits):return
        o=orbits[j]
        for n in range(left//len(o)+1):rec(j+1,left-n*len(o),v+o*n)
    rec(0,c,())
    return sorted(out)

def ordspec(v):return lcm(*(x.denominator for x in v))
def powv(v,k):return tuple(sorted((x*k)%1 for x in v))
def terminal(v):return all(sum(powv(v,k),Q(0))>1 for k in range(1,ordspec(v)))

def exact_trace(v,d=25):
    # The roots of an orbit have sum in K. Reduce in Q[z]/Phi_M, M=lcm(3,orders).
    M=lcm(3,*(a.denominator for a in v)); poly=s.Poly(s.cyclotomic_poly(M,X),X,domain=s.QQ)
    f=s.Poly(d-len(v)+sum(X**int(a*M) for a in v),X,domain=s.QQ).rem(poly)
    base=s.Poly(X**(M//3),X,domain=s.QQ).rem(poly)
    if base.degree()==0:raise AssertionError('Unexpected K generator')
    j=base.degree();b=f.nth(j)/base.nth(j);a=f.nth(0)-b*base.nth(0)
    assert (f-s.Poly(a,X)-b*base).rem(poly).is_zero
    return a,b

def trace_sq(v,d=25):
    a,b=exact_trace(v,d);return s.factor(a*a-a*b+b*b)

def GT_pass(v,d=25):
    for k in range(1,ordspec(v)):
        p=tuple(x for x in powv(v,k) if x)
        # p is nonidentity with fixed eigenspace >=21, never scalar or a scalar reflection
        assert 1<len(p)<=4
        x=trace_sq(p,d)
        # need Delta=d-sqrt(x)>=8-4sqrt(2), equivalently x <= (d-8+4sqrt2)^2.
        # x rational; threshold A+B sqrt2, A=(d-8)^2+32, B=8(d-8)>0.
        A=(d-8)**2+32;B=8*(d-8)
        excess=x-A
        if excess>0 and excess**2>2*B**2:return False
    return True

def row(v):
    a,b=exact_trace(v)
    return {'spectrum':[str(x) for x in v],'order':ordspec(v),'age':str(sum(v,Q(0))),
            'trace_a_plus_b_w':[str(a),str(b)],'trace_norm':str(trace_sq(v))}

def distributions(v3,v4):
    ages3=[sum(v,Q(0)) for v in v3];ages4=Counter(sum(v,Q(0)) for v in v4)
    counts=Counter()
    def rec(i,left,total):
        if i==len(ages3)-1:
            a=Q(29)-total-left*ages3[i]
            if a in ages4:counts[a]+=1
            return
        for t in range(left+1):rec(i+1,left-t,total+t*ages3[i])
    rec(0,18,Q(0))
    return {'rank3_ages':[str(x) for x in ages3],'rank4_age_multiplicities':{str(k):v for k,v in sorted(ages4.items())},'solutions_by_rank4_age':{str(k):v for k,v in sorted(counts.items())},'age_level_count':sum(counts.values()),'spectrum_level_count':sum(counts[a]*ages4[a] for a in counts)}

out={'candidate_orders_phi_le_8':orders,'K_factor_degrees':factor_degrees}
good={};primit={}
for c in [3,4]:
    cand=spectra(c);good[c]=[v for v in cand if terminal(v)];primit[c]=[v for v in good[c] if GT_pass(v)]
    out[str(c)]={'candidate_count':len(cand),'terminal_count':len(good[c]),'terminal_spectra':[row(v) for v in good[c]],'primitive_GT13_pass_count':len(primit[c]),'primitive_GT13_pass':[row(v) for v in primit[c]],'primitive_GT13_reject':[row(v) for v in good[c] if v not in primit[c]]}
out['terminal_budget']=distributions(good[3],good[4]);out['GT13_budget']=distributions(primit[3],primit[4]);
assert out['3']['candidate_count']==54 and out['4']['candidate_count']==150
assert len(good[3])==5 and len(good[4])==28
assert out['terminal_budget']['age_level_count']==2545
(BASE/'independent_sieve_result.json').write_text(json.dumps(out,indent=2)+'\n')
for c in [3,4]:print('Rank',c,'candidates',len(spectra(c)),'terminal',len(good[c]),'GT13 survive',len(primit[c]));print('GT13 rejected',[list(map(str,v)) for v in good[c] if v not in primit[c]])
print('ORIGINAL',out['terminal_budget']);print('NEW',out['GT13_budget']);print('PASS')
