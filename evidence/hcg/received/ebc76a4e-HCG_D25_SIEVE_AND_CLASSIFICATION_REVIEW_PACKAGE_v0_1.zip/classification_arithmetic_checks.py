"""Arithmetic checks supporting, NOT proving, the published degree-25 classification.
Only SymPy is required. No network, no imported peer implementation.
"""
from pathlib import Path
from math import gcd
import json
import sympy as s
BASE=Path(__file__).resolve().parent
x=s.Symbol('x')
w=(-1+s.sqrt(-3))/2
# Generic degree formulas from Hiss--Malle's original Table 2.
def prime_power(q):
    return q>1 and len(s.factorint(q))==1
candidates=[]
for q in range(4,501):
    if not prime_power(q):continue
    if q==25:candidates.append({'group':f'PSL2({q})','degree_formula':'q','type':'orthogonal'})
    if (q+1)==50 and q%4==1:candidates.append({'group':f'PSL2({q})','degree_formula':'(q+1)/2','type':'orthogonal'})
    # Remaining generic formula values cannot give dimension 25 at a prime power.
    assert q-1!=25 and q+1!=25
    assert s.Rational(q-1,2)!=25
assert [z['group'] for z in candidates]==['PSL2(25)','PSL2(49)']
# Atlas b7, with a complete algebraic check of its polynomial and field mismatch.
phi7=s.Poly(s.cyclotomic_poly(7,x),x,domain=s.QQ)
b=s.Poly(x+x**2+x**4,x,domain=s.QQ)
assert (b*b+b+s.Poly(2,x)).rem(phi7).is_zero
irr=s.factor_list(x*x+x+2,x,extension=s.sqrt(-3))[1]
assert len(irr)==1 and s.degree(irr[0][0],x)==2
assert s.discriminant(x*x+x+2,x)==-7
# The quasisimple perfect subgroup has scalar centre with orders dividing both 25 and 6.
assert gcd(25,6)==1
assert all(s.simplify(z**5-1)!=0 for z in [w,w**2,-1,-w,-w**2])
# Strictness of the large-fixed-space/similitude lemma.
B=s.BlockMatrix([[s.zeros(2),s.eye(2)],[s.eye(2),s.zeros(2)]]).as_explicit()
g=s.diag(1,1,w,w)
assert (g-s.eye(4)).rank()==2
assert all(s.simplify(z)==0 for z in g.T*B*g-w*B)
assert all(s.simplify(z)==0 for z in g**3-s.eye(4))
# Positive elementary example at dimension 25.
q=s.diag(*([-1]*3+[1]*22))
assert q.T*q==s.eye(25) and (q-s.eye(25)).rank()==3
result={
 'generic_degree25_cases':candidates,
 'alternating_standard_case':'A26: degree n-1 = 25, type + (source input)',
 'exceptional_characteristic_zero_case':'PSp4(7): degree 25, b7 (source input)',
 'excluded_modular_row':'3D4(2), degree 25 exists in table only for characteristic 3',
 'b7_polynomial':'x^2+x+2', 'b7_discriminant':-7,
 'b7_not_in_Q_sqrt_minus3':True,
 'gcd_25_6':1,
 'extraspecial_central_scalar_order5_incompatible_with_K':True,
 'large_fixed_space_threshold':'strictly greater than d/2',
 'threshold_negative_control':{'d':4,'fixed_dim':2,'similitude_multiplier':'w != 1','order':3},
 'degree25_small_support_generator':{'fixed_dim':22,'movement_rank':3,'preserves_symmetric_form':True},
 'scope':'Arithmetic/sanity checks only; classification is an external theorem input, not computed here.'
}
(BASE/'classification_arithmetic_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print('CLASSIFICATION ARITHMETIC / SIMILITUDE SANITY PASS')
