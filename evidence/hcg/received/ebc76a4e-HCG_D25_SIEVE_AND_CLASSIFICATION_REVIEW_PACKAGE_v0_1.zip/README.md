# HCG d=25 independent sieve review and proposed classification exclusion

2026-10-30. Internal research, not an adopted DSN, not a human-referee report.

Run `python replay.py` from any directory after installing SymPy. No network access is used. The source archive is unchanged. The replay script verifies the archive's frozen manifest and the package manifest, runs the original peer script and two separately authored scripts in a temporary directory, compares the outputs byte-for-byte, and checks equality of all 33 terminal spectrum tuples. It leaves the frozen output files unchanged.

The scripts certify local arithmetic and code reproduction only. They do not certify the completeness of the Hiss--Malle classification, the Guralnick--Tiep structural theorem or the geometric assumptions (H). The proposed d=25 proof invokes those published theorems with the exact scope stated in its note. Relevant primary-source passages were text-accessible, but PDF screenshots failed; visual inspection and PDF-byte identity are not claimed. Source PDFs are not included.

Files:
- `HCG_D25_SIEVE_CHATGPT_CROSS_REVIEW_v0_1.md`: source review, independent counts, deviation refinement.
- `HCG_D25_CLASSIFICATION_EXCLUSION_PROPOSED_v0_1.md`: full new proof candidate.
- `independent_sieve.py` and JSON: exact cyclotomic enumeration and all-power trace-gap checks.
- `compare_spectral_lists.py`: compares every spectrum against the original source log.
- `classification_arithmetic_checks.py` and JSON: arithmetic/threshold sanity checks, not a computed classification.
- `source/` and `SOURCE_H3_D25_SIEVE_REVIEW_CLAUDE_v0_1.zip`: original peer files.

The original 2545 is an age-profile count; 6548 distinguishes rank-4 spectra. GT1.3 reduces these to 92 and 210 respectively, before the separate group-theoretic argument.
