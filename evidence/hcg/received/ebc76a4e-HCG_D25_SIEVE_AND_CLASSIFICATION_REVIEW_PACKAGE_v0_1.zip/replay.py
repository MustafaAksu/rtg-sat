#!/usr/bin/env python3
"""Repeat finite checks in a scratch directory, preserving all frozen inputs and results."""
from pathlib import Path
import hashlib,shutil,subprocess,sys,tempfile
BASE=Path(__file__).resolve().parent

def verify(root,manifest):
    lines=(root/manifest).read_text().splitlines();n=0
    for line in lines:
        if not line.strip():continue
        digest,name=line.split('  ',1)
        path=(root/name).resolve()
        if not path.is_relative_to(root.resolve()):raise ValueError('Manifest path escape')
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,name
        n+=1
    print(manifest,n,'/',n,'PASS')

verify(BASE,'SHA256SUMS.txt');verify(BASE/'source','BUNDLE_SHA256SUMS.txt')
with tempfile.TemporaryDirectory(prefix='hcg_d25_replay_') as temp:
    work=Path(temp)
    for item in BASE.iterdir():
        if item.is_dir():shutil.copytree(item,work/item.name)
        else:shutil.copy2(item,work/item.name)
    result=subprocess.run([sys.executable,str(work/'source/d25_terminal_sieve_claude.py')],capture_output=True,check=True)
    assert result.stdout==(BASE/'source/d25_terminal_sieve_claude_out.txt').read_bytes()
    print('SOURCE SCRIPT BYTE-IDENTICAL PASS')
    for script,out in [('independent_sieve.py','independent_sieve_result.json'),('classification_arithmetic_checks.py','classification_arithmetic_checks.json')]:
        result=subprocess.run([sys.executable,str(work/script)],capture_output=True,check=True)
        assert (work/out).read_bytes()==(BASE/out).read_bytes(),out
        print(script,'BYTE-IDENTICAL PASS')
    result=subprocess.run([sys.executable,str(work/'compare_spectral_lists.py')],capture_output=True,check=True)
    print(result.stdout.decode(),end='')
verify(BASE,'SHA256SUMS.txt')
print('FRESH REPLAY PASS')
