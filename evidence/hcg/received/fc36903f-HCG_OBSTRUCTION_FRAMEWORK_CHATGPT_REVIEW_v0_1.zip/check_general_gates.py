"""HCG research-only. Independent integer proof checks for T' and b=25/26 S_{b+1} screens.
Pure standard library; no provenance claim for the group classification inputs.
"""
from math import ceil
import json
from pathlib import Path


def min_delta_sum(a, t, prime):
    if prime:
        return max(t, a + ceil(a / (t - 1)))
    return max(t, a)


def best_cost(a, b, prime):
    admissible_t = range(3, 2 * a + 10)
    return min((b * min_delta_sum(a, t, prime) + max(19 - t, 0) * a,
                t, min_delta_sum(a, t, prime)) for t in admissible_t)

expected = {3:(14,19), 4:(13,16), 5:(13,15), 6:(12,13), 7:(11,12), 8:(10,11)}
thresholds = {}
for a, pair in expected.items():
    old = next(b for b in range(a,200) if best_cost(a,b,False)[0] <=2*a*b+8)
    new = next(b for b in range(a,200) if best_cost(a,b,True)[0] <=2*a*b+8)
    assert (old,new) == pair
    thresholds[a] = dict(old=old, euler=new)
assert best_cost(4,13,True)[0] > 2*4*13+8
assert best_cost(3,17,True)[0] > 2*3*17+8

# Standard S_26/S_27 permutation spectra give the following index maxima.
# b=25: active costs 25,25,26; Jmax = 13,13,2, plus 16 inactive transpositions.
assert 13+13+2+16 == 44 < 2*25

# b=26: three active, with c>=26; the four cost patterns are exhaustive by
# N>=19, t=3, c_inactive even >=2 and sum c=112.
patterns = [
    dict(active=(26,26,26), inactive_index=17, name='N=19, inactive 2^15 4'),
    dict(active=(26,26,28), inactive_index=16, name='N=19, inactive 2^16'),
    dict(active=(26,27,27), inactive_index=16, name='N=19, inactive 2^16'),
    dict(active=(26,26,26), inactive_index=17, name='N=20, inactive 2^17'),
]
# Permutation-index maxima at these active costs. For cost <=28 and J>=9,
# the only compatible A' spectrum is {1,-1}, hence det A'=-1.
index_max = {26:13,27:2,28:14}
out=[]
for x in patterns:
    bound=sum(index_max[c] for c in x['active'])+x['inactive_index']
    if bound < 52:
        reason='RH contradiction'
    else:
        # At every RH-feasible pattern, even if other two are at their maxima,
        # each active needs J>=9, hence three determinant -1 factors.
        lows=[52-x['inactive_index'] - sum(index_max[c2]
              for j,c2 in enumerate(x['active']) if i!=j)
              for i in range(3)]
        assert min(lows)>=9
        reason='three active det(Aprime)=-1: product det=-1, contradiction'
    out.append({'pattern':x['name'],'active':x['active'], 'max_total_J':bound,
                'reason':reason})
assert len(out)==4

result={'lemma_Tprime_thresholds':thresholds,'S26_2x25_RH_max':44,
        'S27_2x26_patterns':out,
        'comment':'Exact integer consequences; external classification not reproduced.'}
Path(__file__).with_name('general_gates_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print('GENERAL GATES EXACT CHECK PASS: Tprime, 2x25, 2x26')
