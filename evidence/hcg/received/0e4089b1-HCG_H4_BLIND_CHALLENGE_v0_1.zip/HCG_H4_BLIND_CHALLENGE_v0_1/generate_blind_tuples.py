#!/usr/bin/env python3
"""Generate fresh G34 paired-reflection Nielsen inputs without invoking monodromy or edge prediction.
Reflection orbit constructed by exact Eisenstein arithmetic from W5 ten generators.
Check projective generator subgroup order on 126 reflection lines (centre mu6 acts trivially).
"""
import json,hashlib,random,pathlib
from collections import deque
from sympy.combinatorics import Permutation, PermutationGroup
seed=202610221947
src=pathlib.Path(__file__).resolve().parent/'W5_BASELINE_ROOTS.json'
out=pathlib.Path(__file__).resolve().parent/'BLIND_INPUT';out.mkdir(exist_ok=True)
roots=[[tuple(int(z) for z in c) for c in x] for x in json.loads(src.read_text())['generating_reflection_roots']]
Z=(0,0);UNITS=((1,0),(-1,0),(0,1),(0,-1),(-1,-1),(1,1))
def add(x,y):return(x[0]+y[0],x[1]+y[1])
def sub(x,y):return(x[0]-y[0],x[1]-y[1])
def mul(x,y):a,b=x;c,d=y;return(a*c-b*d,a*d+b*c-b*d)
def conj(x):return(x[0]-x[1],-x[1])
def inn(x,y):
 s=Z
 for a,b in zip(x,y):s=add(s,mul(a,conj(b)))
 return s
def canon(v):return min(tuple(mul(u,c) for c in v) for u in UNITS)
def ref(v,x):
 h=inn(x,v)
 assert h[0]%3==h[1]%3==0,(h,v,x)
 c=(h[0]//3,h[1]//3)
 return tuple(sub(xi,mul(c,vi)) for xi,vi in zip(x,v))
origin=canon(roots[0]);orbit={origin};q=deque([origin])
while q:
 x=q.popleft()
 for v in roots:
  y=canon(ref(v,x))
  if y not in orbit:orbit.add(y);q.append(y)
print('orbit',len(orbit));assert len(orbit)==126
lines=sorted(orbit); idx={v:i for i,v in enumerate(lines)}
perms=[]
for v in lines:
 img=[idx[canon(ref(v,x))] for x in lines]
 assert len(set(img))==126
 perms.append(Permutation(img))
base_picks=[idx[canon(v)] for v in roots];grp=PermutationGroup([perms[i] for i in base_picks]);print('base_group_order',grp.order());assert grp.order()==6531840
rng=random.Random(seed)
selected=[];trials=0
while len(selected)<4 and trials<300:
 trials+=1
 picks=rng.sample(range(126),10)
 # prevent overlap with W5 roots; generate sets not just reorderings
 if len(set(picks)&set(base_picks))>=4:continue
 if PermutationGroup([perms[i] for i in picks]).order()!=6531840:continue
 selected.append(picks)
print('selected',len(selected),'trials',trials);assert len(selected)==4
# The action on the 126 reflection *lines* kills mu6. Check candidate subgroups on the
# 756 distinct minimal vectors, where the central scalars act faithfully.
full_vectors=sorted({tuple(mul(u,c) for c in v) for v in lines for u in UNITS})
assert len(full_vectors)==756
full_idx={v:i for i,v in enumerate(full_vectors)}
def full_perm(v):return Permutation([full_idx[ref(v,x)] for x in full_vectors])
for j,picks in enumerate([base_picks]+selected):
 H=PermutationGroup([full_perm(lines[i]) for i in picks])
 order=H.order()
 print('faithful_756_group',j,order)
 assert order==39191040


def bracket(lo,hi):
 if hi-lo==1:return [(lo,hi)]
 mid=rng.randrange(lo+1,hi)
 return bracket(lo,mid)+bracket(mid,hi)+[(lo,hi)]
def make_tree():
 # choose root split with both sides >=2 pairs for predictable 17 curves and nontrivial complement
 mid=rng.randrange(2,9)
 pieces=bracket(0,mid)+bracket(mid,10)
 pieces.remove((mid,10))
 c=[(2*a+1,2*b) for a,b in pieces]
 assert len(c)==17 and len(set(c))==17
 return sorted(c)
metas=[]
for j,picks in enumerate(selected,1):
 rid=f'NEW{j:02d}'
 r=[[list(c) for c in lines[i]] for i in picks]
 inp={'generating_reflection_roots':r}
 p=out/f'{rid}_roots.json';p.write_text(json.dumps(inp,indent=2)+'\n')
 trees=[];used=set()
 while len(trees)<3:
  t=make_tree();key=tuple(t)
  if key in used:continue
  used.add(key);trees.append(t)
 (out/f'{rid}_trees.json').write_text(json.dumps({'case_id':rid,'curves':trees},indent=2)+'\n')
 metas.append({'case_id':rid,'root_indices_in_frozen_126_line_orbit':picks,'root_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'trees_sha256':hashlib.sha256((out/f'{rid}_trees.json').read_bytes()).hexdigest()})
(out/'INPUT_MANIFEST.json').write_text(json.dumps({'seed':seed,'generation':'exact 126-line orbit from W5 with generated reflection permutations; projective subgroup order verified 6531840 = 39191040 / 6','cases':metas,'number_of_trees_per_case':3,'prediction_values':'NOT COMPUTED','monodromy_values':'NOT COMPUTED'},indent=2)+'\n')
for p in sorted(out.glob('*.json')):
 print(p.name,hashlib.sha256(p.read_bytes()).hexdigest())
