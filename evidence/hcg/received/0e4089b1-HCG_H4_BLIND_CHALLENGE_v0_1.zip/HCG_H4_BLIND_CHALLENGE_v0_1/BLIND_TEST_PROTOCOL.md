# HCG-H4 precommitted holdout — blind input v0.1

**Date:** 2026-10-22. **Status:** CHALLENGE INPUT ONLY, not a result, not a theorem, not a G34-D certificate. Standalone HCG/RTG-motivated exploratory work, outside Severn's proof chain.

## Data

- Four previously unused ordered paired-reflection tuples: `BLIND_INPUT/NEW01_roots.json` ... `NEW04_roots.json`; each has ten Eisenstein root vectors (6 coordinates each).
- Three previously unused, laminar, pair-containing pants decompositions per tuple: `BLIND_INPUT/NEWxx_trees.json`; each tree is an ordered list of **17** `[a,b]` intervals in 1-based branch-point coordinates (10 pair curves + 7 other curves).
- `BLIND_INPUT/INPUT_MANIFEST.json` gives per-file SHA-256 values and the fixed generation seed 202610221947.
- `W5_BASELINE_ROOTS.json` and `generate_blind_tuples.py` permit deterministic regeneration of all inputs; no monodromy or edge-form predictor is imported or executed by that generator. Requires Python 3 and `sympy` for faithful permutation-group membership/order checking.
- Exact group verification: from W5 generators, the 126 reflection lines were enumerated by reflection orbit. For each new 10-root set, the faithful permutation representation on **756** minimal vectors has group order **39,191,040**; the action on 126 reflection lines has order **6,531,840** (quotient by the central μ₆). Root representatives need not match the original 126-line indexing.

## Blind protocol (strict ordering)

1. Claude receives **this input archive only** (plus its previously frozen `edgeform_predict.py`). Do not send any ChatGPT monodromy analysis, future outputs, or intermediate actual ranks.
2. Claude computes **without running any monodromy/braid/cocycle routine**, and files `H4_HOLDOUT_PREDICTIONS.json` recording the 12 cases: `(case_id, tree_index)` where tree_index=0,1,2; an exact root-span K-dimension, predicted 17 individual K-ranks, predicted Q-span rank, and preferably an exact **canonical rational left-nullspace basis** of the 17 × 16 Hermitian-form coordinate matrix (the basis may be obtained as RREF rows of the left nullspace; define normalization in the prediction report).
3. Claude computes SHA-256 of the committed prediction file, sends its hash and a dated statement to the PI. The PI stores a byte-preserved copy and the hash **before any comparison result is disclosed to Claude**. Prediction file must not be edited after commitment. The tree curve order in JSON is fixed and must be preserved for linear relations.
4. Only after this commitment, ChatGPT or another reviewer independently computes each full monodromy logarithm `N_e`, and records the exact 17 × 128 rational flattening (real/Eisenstein components), individual K-ranks, Q-span ranks and canonical left-nullspace bases. Source and executable hashes go into an evidence bundle.
5. Compare per-tree ranks, **all coefficient-wise linear relations**, and optionally the common correspondence over the **union of curves across the three trees of each tuple**. Report each mismatch with a minimal exact counterexample. Do not infer H0–H3 or geometric dominance from rank matching.
6. Report results as finite `[ALG cert]` only. A universal `[THM]` requires an algebraic or geometric proof and source comparison. The auditor's blind Round 2 Priority A/B remains isolated from all H4 inputs and reports.

**Interpretation:** This is a genuine out-of-sample *precommitted* test, not an algorithm-blind test: the formula is known to the predictor, but these 4×3 inputs have not been evaluated by it in this packet. The inputs are drawn from the same Coxeter–Todd G34 reflection orbit as previous tests; no cross-group generalization is claimed.

**No outputs:** Neither the edge-form ranks nor monodromy ranks were computed for these twelve cases by the generator; none is included in this archive.
