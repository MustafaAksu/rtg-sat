#!/usr/bin/env python3
"""Independent integer checks for Lemmas B', T and the d=48 tight tensor case.
No imports from the contributor's programs or frozen results.
"""
from fractions import Fraction
from itertools import product
import json
from pathlib import Path

# B': exact projective scalar-cycle rank inequalities
bprime=[]
for r in range(13,30):
    available=2*r-26
    q2=r-(r+1)//2
    q3=r-(r+1)//3
    preserving=2*(q3-1)
    involving_swap=q3+min(q2,2*(q2-1))
    # finer two-block Clifford systems with total k>=4 blocks
    finer=[]
    for t in range(2,r+1):
        if r%t or r//t<6: continue
        k=2*t; rb=r//t
        excess=2*rb+2*k*k-21*k+8
        finer.append((k,rb,excess))
    assert preserving>available,(r,preserving,available)
    assert involving_swap>available,(r,involving_swap,available)
    assert 17>available/2
    assert all(x[2]<0 for x in finer)
    bprime.append(dict(r=r,Emax=available,R2=q2,R3=q3,cost_preserving=preserving,cost_swap=involving_swap,finer=finer))

# T: use direct minimization over number of A-active elements, not Claude's formula
factor=[]
for a,b in ((2,23),(2,24),(2,25),(3,16),(4,12),(6,8),(7,7)):
    candidates=[]
    for N in range(19,61):
        for t in range(3,N+1):
            min_active_codim_sum=max(t,a)
            cost=b*min_active_codim_sum + a*(N-t)
            candidates.append((cost,N,t))
    cost,N,t=min(candidates)
    factor.append(dict(a=a,b=b,d=a*b,mincost=cost,budget=2*a*b+8,N=N,t=t,feasible=cost<=2*a*b+8))
assert next(x for x in factor if x['a']==4 and x['b']==12)['mincost']==108
assert next(x for x in factor if x['a']==2 and x['b']==24)['mincost']==104

# d=48 exact equality leaves N=19, 3 A-active elements (16 inactive).
d,budget=48,104
matches=[]
for N in range(19,60):
    for t in range(3,N+1):
        if 24*t + 2*(N-t)<=budget:
            matches.append((N,t))
assert matches==[(19,3)],matches
# for a connected degree-25 S25 permutation cover, all w_i involutions
# imply index <=12. 16 inactive w_i are transpositions with index 1.
# RH on genus gamma >=0 requires sum of 3 active indices >=48-16=32.
# At most two nonzero involutions give <=24. Thus all 3 are nonidentity,
# and factor-A matrices are genuine order-2 reflections (det -1 each).
possible_indices=[triple for triple in product(range(13),repeat=3) if sum(triple)>=32]
assert possible_indices and all(all(x>0 for x in row) for row in possible_indices)
assert (-1)**3 != 1

# conditional K-induced lower bound: if rank r < 46 cannot be nonsplit dominant
k_defined_cutoff=2*46
out={"bprime":bprime,"factorwise":factor,"tight_2x24":{
"N_t_solutions":matches,"RH_min_three_indices":32,"involution_max_index":12,
"possible_index_triples_count":len(possible_indices),"all_three_nontrivial":True,
"det_product":-1,"required_det_product":1},
"K_imprimitive_cutoff_using_checked_d_ge_46":k_defined_cutoff}
Path(__file__).with_name('independent_budget_qa.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('INDEPENDENT BUDGET QA PASS')
print('Bprime r range',bprime[0]['r'],bprime[-1]['r'])
print('T 4x12 min',next(x['mincost'] for x in factor if x['a']==4 and x['b']==12))
print('T 2x24 min',next(x['mincost'] for x in factor if x['a']==2 and x['b']==24))
print('2x24 genus/parity: all',len(possible_indices),'index triples force three nontrivial involutions; determinants contradict')
print('K-imprimitive dimension floor:',k_defined_cutoff)
