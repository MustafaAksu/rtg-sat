# HCG DSN — pending deltas for v0.2 (noncanonical accumulation log)

**Base:** `HCG_HODGE_SESSION_DSN_v0_1_ADOPTED.md` (SHA-256 75b5f58c30d6d1cd3ce0a8ff0fd93f1a5c14731795d7fca487fbf5e80f6c86b7). The base is left byte-unchanged; the ChatGPT replay confirmed the release byte-exactly.
**Rule:** this file collects proposed changes. They enter the DSN only through an owner-approved v0.2. PI-decision fields are blank.
**Distribution:** INTERNAL. Not for the blind auditor (SG-10).

## Δ1 — HCG-OPEN-LEMMA62 (OPEN 5) — 22 Oct 2026

**Evidence:**
- Claude, `H3_LEMMA62_SOURCE_REVIEW_CLAUDE_v0_1.md` (0695407389ccf310…).
- ChatGPT, `H3_LEMMA62_CHATGPT_INDEPENDENT_CROSS_REVIEW_v0_1.md`, together with its ledger delta and repro package.
- Claude checked the repro package: manifest verified (15/15 OK); the inputs are byte-identical to the session certificates (172766a9…, ae904878…, 45097b30…); `replay_all.py` re-run in this workspace gave "ALL 3 x 2 CHECKS PASSED".

| RID | Proposed state | Scope |
|---|---|---|
| HCG-OPEN-LEMMA62 | **PARTIAL** | See the two sub-items below. |
| └ W5-FORMULA-APPLICATION | CHECKED | Formula identical to the session S, term by term. Exact on W5/W6/W7: 64/64 by Claude's source-formula script and 64/64 by ChatGPT's paired-reflection script. Algebra re-derived by both AIs. W5 additionally matches the published DW06 Thm 2.6 (HCG-ALG-CUPVAL). |
| └ GENERAL-DELTA-COMPLEX-PROOF | OPEN | The reduction of the Alexander–Whitney cup on the Δ-complex to S_simp, and the edge relations, are not reconstructible from the printed proof. Severn's Certificate E has not been accessed. |
| HCG-ALG-CUPVAL | unchanged | The published-principle (DW06) basis covers W5 only, not W6/W7. |
| HCG-EXT-PO6 | PROPOSED (unchanged) | For W5, the `[assuming: Lemma 5.2 / [19, Lemma 6.2]]` may be replaced by "W5: DW06 Thm 2.6 via HCG-ALG-CUPVAL". Still open: Prop 5.1 Steps 1–4 (multiplicity space and polarized-factor comparison); auditor R2 Priority A. |
| HCG-EXT-SEVERN-62 | CLAIMED (unchanged) | — |

**Proof improvement credited to ChatGPT.** Claude's review supported coboundary vanishing by a telescoping remark and supported preimage independence by a proof plus random tests. ChatGPT gave general, data-free proofs of both:
- choosing a_i = −u gives Q_i⁻¹F_i + a_i = −Q_i⁻¹u, so the pairing reduces to −h(u, F_{n+1}) = 0;
- for preimage independence, im(1 − T_i) = ker(1 − T_i)^⊥, because 1 − T_i is normal.

These are the versions to record in v0.2.

**Shared-input limitation.** All three exact checks use the same root tuples and cocycle bases. They are algorithmically independent, not geometrically independent.

## Δ2 — Auditor R2 Priority A item 2: the component requirement — 22 Oct 2026

**Evidence:** `auditor_r2/AUDITOR_R2_ITEM2_COMPONENT_received.md` (third-family; blind; given without access to the Claude/ChatGPT assessments).

| RID | Proposed state | Scope |
|---|---|---|
| HCG-THM-ANYCOMP | **THIRD-FAMILY CHECKED** (was CHECKED) | Thm 7.1 needs (D) and the polarized discriminant on the *same chosen* component; identification with Appendix A is not a hypothesis (Rem 5.3, 7.3). The three verdicts are independent and agree: Claude, ChatGPT, auditor. |
| HCG-RESULT-SW5-SUFFICES | `[from: HYP]` unchanged; premise list sharpened | S_W5 suffices **provided** that (i) its datum satisfies Def 2.2 and (ii) the computed cup form is correctly identified with the factor's polarization. (i) is covered by auditor R1 obligations 1–2 (group, irreducibility, character field, dimension, Hodge numbers). (ii) is HCG-EXT-PO6, still PROPOSED; auditor assessment pending. |
| HCG-OPEN-COMPONENT / HCG-OPEN-APPA-REPLAY | unchanged (OPEN) | Reclassified by the auditor as a certificate-identification issue, not a premise of the transfer theorem. This agrees with §6.17. |
| HCG-EXT-PO6, HCG-EXT-SEVERN-62 | unchanged | Remaining auditor items: polarization identification, supplier cycles, full-plane spreading, compensation. |

**Blindness:** the auditor's statement agrees with the sealed Claude assessment (`auditor_r1/H3_G34D_AUDITOR_R1_ASSESSMENT_CLAUDE_v0_1.md` §2), which the auditor has not seen. The rule (SG-10) stays in force until Priority A/B are complete.

**Δ2 addendum (ChatGPT, 22 Oct 18:42):** agrees with Δ2. ChatGPT re-checked Def 2.2, Thm 7.1 and Rem 5.3/7.3 in the source. Additional rows:

| RID | Proposed state |
|---|---|
| HCG-OPEN-AUDITOR-R2 | PARTIAL. Closed: the item 1 arithmetic (det h) and item 2 (component). Open: the item 1 bridge (PO-6), item 3, and Priority B items 4–7. |
| HCG-OPEN-COMPONENT | OPEN / DEFERRED. The mathematical equivalence question is unsolved; it is not a premise of the main chain. |

## Δ3 — H4 selection: edge-form predictor (exploratory branch) — 22 Oct 2026

**Evidence:** `h4sel/edgeform/H3_H4SEL_EDGEFORM_CLAUDE_v0_1.md` and its scripts/outputs (Claude only; ChatGPT replication requested).

| RID | Proposed state | Scope |
|---|---|---|
| HCG-ALG-H4-EDGEFORM-FINITE (new) | `[ALG cert]` PROPOSED | Predicted rank = actual dim_ℚ span N_j in 216/216 cases (27 tuples × 8 decompositions). Identical linear relations in 24/24 joint tests. |
| HCG-HYP-EDGEFORM | `[HYP]`, formula made explicit | β_e(t) = h(Σ_{i∈P(e)} t_i v_i, ·) on L = ker(t ↦ Σ t_i v_i). Proof route: Picard–Lefschetz plus σ-projection (not written). |
| HCG-OPEN-H4SEL | ACTIVE | Remaining: written proof; blind test (frozen rule); literature comparison; ChatGPT replication. |
| (note) | — | Six prediction-level rank-16 candidates on further tuples. Not certificates; not used in the main chain. |

## Δ4 — Edge-flux theorem (H4 selection) — 22 Oct 2026

**Evidence:**
- `h4sel/theorem/H3_H4SEL_EDGEFORM_THEOREM_CLAUDE_v0_1.md`: written proof, Lemmas 1–2, Prop 3, Theorem §4.
- `check_edgeform_identity.py` with `check_out.txt`: Prop 3 holds exactly on W5/W6/W7 (17 curves × 64 entries), and (A3) holds.

**ChatGPT input:** the six-cell cross-check `HCG_H4_EDGE_CROSS_REVIEW_v0_1` (edge ranks, Y forms and characteristic polynomials CHECKED; it requested a proof and a common-isomorphism test). The theorem supplies both. The isomorphism is τ, and S(x, N_e y) = −B_e(τx, τy) holds with the factor −1 for every curve.

| RID | Proposed state |
|---|---|
| HCG-THM-EDGEFLUX (new) | `[THM]` [assuming: A1 irreducible + roots span; A2 S nondegenerate; A3 v_i ∈ span of the others] PROPOSED. For pair-containing decompositions: (H0)–(H3) are automatic, I = ker τ does not depend on the decomposition, and (H4) ⇔ the B_e span Herm(L). |
| HCG-HYP-EDGEFORM | superseded by HCG-THM-EDGEFLUX within the pair-containing scope. |
| HCG-ALG-H4-OBS | CHECKED for the six cells (Claude + ChatGPT: Y ranks, inertia, characteristic polynomials). |
| HCG-OPEN-H4SEL | PARTIAL. Open: ChatGPT proof check; literature comparison; unpaired / higher-order generalisation. |

**Effect on the main chain:** for W5, (H1)–(H3) now follow from a proof, not only from computation, given (A1)–(A3) and the session S. The geometric links remain HCG-ALG-CUPVAL and HCG-THM-G34D-SW5. No status in the Severn chain changes.

## Δ5 — Precommitted holdout test of the edge-flux predictor — 23 Oct 2026

**Protocol:** `HCG_H4_BLIND_CHALLENGE_v0_1`.
- 4 new G₃₄ tuples × 3 new trees, generated by ChatGPT with seed 202610221947.
- Claude's predictions were committed before any monodromy computation: `H4_HOLDOUT_PREDICTIONS.json`, SHA-256 bab327f3cf5639a25bdef7e881a33e63831c2173434ba15a888f46228536bab1; addendum 49713bf3…; predictor `edgeform_predict.py` 93d748a9….
- The prediction file is unchanged after the comparison (rechecked by Claude).

**Result** (ChatGPT, independent monodromy implementation built from the roots; `cg_holdout_in/`):
- Q-span ranks: 12/12.
- Individual K-ranks: 204/204.
- Full canonical relation spaces (RREF): 12/12.
- Relation rows annihilating the actual N_e: 40/40.
- H1/H2/H3: 12/12.
- I identical across the three trees of each tuple: 4/4.
- Negative controls detected: 12/12.
- Positive control W5-balanced: rank 16 (not scored).

Qualification: this is a precommitted out-of-sample test. The evaluator could see the predictions, so it was not evaluator-blind.

**Post-commit extension (Claude, own engine, not blind):** Prop 3 of HCG-THM-EDGEFLUX, S(x,N_e y) = −h(F_e(τx), F_e(τy)), checked exactly on all 12 holdout trees (17 curves × 64 entries each), together with τ∘N_e = 0 and rank τ = 4. Evidence: `h4sel/holdout_post/identity_out.txt`.

| RID | Proposed state |
|---|---|
| HCG-ALG-H4-HOLDOUT-12 (new) | `[ALG cert]` CHECKED. Precommitted holdout, Claude predictor, ChatGPT monodromy; scope: the 12 cases. |
| HCG-THM-EDGEFLUX | PROPOSED (unchanged). The finite evidence is now W5/W6/W7 plus 12 holdout trees for Prop 3 (Claude engine); the written proof still needs an independent check. The definitions ChatGPT reported missing (A1–A3, τ) are in `H3_H4SEL_EDGEFORM_THEOREM_CLAUDE_v0_1.md` §0–§1 and §4. That note was not part of ChatGPT's holdout package. |

## Δ6 — Edge-flux theorem: independent proof review — 23 Oct 2026

**Evidence:**
- ChatGPT, `HCG_EDGEFLUX_CHATGPT_PROOF_REVIEW_v0_1.md` with its ledger delta and the package `HCG_EDGEFLUX_PROOF_CHECK_v0_1.zip`.
- Claude's replay of that package in this workspace:
  - manifest 12/12 OK;
  - the embedded earlier archives are byte-identical (702a4d65… and 1cce011d…, the latter equal to the H4_HOLDOUT_POSTCHECK zip sent by Claude);
  - `replay.py --full-prior` gives PACKAGE / PRIOR / DELIVERY MANIFEST PASS, FRESH REPLAY PASS (the prior holdout) and FRESH POSTCHECK REPLAY PASS (τ identity: 4 tuples, tau rank 4, A3 true, 3264 identities each);
  - the A3-failure toy example was replayed.
- Theorem note v0.2: `h4sel/theorem/H3_H4SEL_EDGEFLUX_THEOREM_v0_2.md` (1e99898a…). v0.1 (4e2aaa0f…) is preserved; diff `theorem_v0_1_to_v0_2.diff`.

| RID | Proposed state |
|---|---|
| HCG-THM-EDGEFLUX | **CHECKED**: `[THM]` [assuming: A1, A2; A3 only for per-pair nonvanishing; displayed S; paired interval-twist convention]. Claude derivation; ChatGPT line-by-line proof review, no gap found. |
| └ Corollary 5 (A3 not needed for the aggregate conclusions) | CHECKED. Derived by ChatGPT; Claude verified the argument (ker M = ker τ via positive definite G and the surjectivity of τ; then dimension count). |
| HCG-ALG-H4-HOLDOUT-12 | CHECKED (unchanged). |
| τ-identity post-commit evidence | CHECKED (post-commit, not blind): 12 trees; 13,056 occurrences / 6,400 distinct entries (ChatGPT engine); also Claude engine. |
| HCG-OPEN-H4SEL | PARTIAL. The algebraic proof is closed in the paired scope. Open: literature/novelty comparison; unpaired and higher-order generalisation; geometric interpretation (via HCG-ALG-CUPVAL and the G34-D realization, per component). |
| HCG-EXT-PO6, HCG-EXT-SEVERN-62 | unchanged. |

**Editorial clarifications adopted in note v0.2 (from ChatGPT):** H/I instead of V/I; s_{p(k)} for point indices; cocycle domain Π stated explicitly; generality phrase restricted to the stated field and representation hypotheses.
