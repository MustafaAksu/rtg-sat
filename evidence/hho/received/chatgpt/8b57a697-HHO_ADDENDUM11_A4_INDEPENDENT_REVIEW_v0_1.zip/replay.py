#!/usr/bin/env python3
"""Frozen-source deterministic replay, stdlib driver + SymPy exact checker."""
from pathlib import Path
from zipfile import ZipFile
import hashlib, shutil, subprocess, sys, tempfile
BASE=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()

for line in (BASE/'SHA256SUMS.txt').read_text().splitlines():
    h,path=line.split(None,1); path=path.strip().removeprefix('*')
    assert sha((BASE/path).read_bytes())==h,path
print('REVIEW PACKAGE MANIFEST PASS')

def bfrom(z,n):
    with ZipFile(BASE/'original'/z) as f:
        return f.read(n)

z_a='HHO_A4_DIRECT_v0_1.zip'
z_old='HHO_ADDENDUM10_F20_NORMALIZATION_CORRECTION_v0_1.zip'
z_in='HHO_F20_TESTS_v0_1.zip'
expected={}
for line in bfrom(z_a,'SHA256SUMS.txt').decode().splitlines():
    h,n=line.split(None,1);expected[n.strip()]=h
assert len(expected)==4
assert expected['a4_direct.py']==sha(bfrom(z_a,'a4_direct.py'))
assert expected['a4_direct_out.txt']==sha(bfrom(z_a,'a4_direct_out.txt'))
assert expected['generic_engine.py']==sha(bfrom(z_old,'generic_engine.py'))
assert expected['cyclic_disc_claude.py']==sha(bfrom(z_old,'cyclic_disc_claude.py'))
print('A4 ORIGINAL 4/4 DEPENDENCY SHA-256 PASS (2 files recovered from previous archive)')

with tempfile.TemporaryDirectory(prefix='hho_a11_replay_') as tmp:
    root=Path(tmp);work=root/'replay';work.mkdir()
    for fn in ('a4_direct.py','a4_direct_out.txt'):
        (work/fn).write_bytes(bfrom(z_a,fn))
    for fn in ('generic_engine.py','cyclic_disc_claude.py'):
        (work/fn).write_bytes(bfrom(z_old,fn))
    (work/'f20_faithful_out.txt').write_bytes(bfrom(z_in,'f20_faithful_out.txt'))
    proc=subprocess.run([sys.executable,'-I','a4_direct.py','f20_faithful_out.txt'],cwd=work,capture_output=True,check=True)
    assert proc.stdout==bfrom(z_a,'a4_direct_out.txt')
    print('DIRECT A4 GRAM: 40 ROWS, OUTPUT BYTE-IDENTICAL')
    shutil.copy2(BASE/'checks/independent_f20_locality.py',root/'independent_f20_locality.py')
    local=subprocess.run([sys.executable,'independent_f20_locality.py'],cwd=root,capture_output=True,check=True)
    assert local.stdout==(BASE/'outputs/independent_stdout.txt').read_bytes()
    assert (root/'independent_locality_results.json').read_bytes()==(BASE/'outputs/independent_locality_results.json').read_bytes()
    print(local.stdout.decode(),end='')
print('COMPLETE HHO A11 REPLAY PASS; mathematical locality theorem is an inherited dependency')
