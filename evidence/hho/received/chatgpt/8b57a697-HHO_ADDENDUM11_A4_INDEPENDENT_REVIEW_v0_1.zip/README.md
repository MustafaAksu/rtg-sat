# HHO Addendum 11 — independent check and reproducibility package

**Status:** SESSION research record; no PI adoption or HCG/RTG edits.

This package contains the uploaded Addendum 11 and original A4 direct-Gram archive unchanged, plus two earlier exact hash-matching source archives that supply the 2 Python dependencies and the frozen 40 tuples missing from the A4 archive. The review and independent arithmetic check are in English.

Run from the extracted folder:

```bash
python replay.py
```

Runtime: Python >=3.10 and **SymPy** (independent rational matrix checker). The original direct Gram test uses only standard-library Python. No network or GAP required. The replay verifies the SHA-256 manifest, reconstructs the original Python dependencies from their matching prior archives in a temporary directory, re-runs the original A4 form calculation, then separately reconstructs the 40 determinant norm classes and all 60 group elements from a distinct rational/cyclotomic implementation. The direct engine output and independent checker JSON are byte-compared with frozen expected output.

The independent checker does **not** independently establish the mathematical parabolic-locality theorem; it checks the group and local-arithmetic consequences of that theorem. The original direct calculation reuses the generic cocycle-space routine. These evidence distinctions are stated in the report.

`docs/HHO_ADDENDUM11_CHATGPT_INDEPENDENT_REVIEW_v0_1.md` is the change-focused scientific review. No human referee certification, GitHub release, or source ownership is asserted.
