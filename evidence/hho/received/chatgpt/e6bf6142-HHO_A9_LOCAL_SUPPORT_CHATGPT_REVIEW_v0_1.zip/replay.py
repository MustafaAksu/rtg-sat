#!/usr/bin/env python3
"""Hash-verified, sandboxed-by-temp-directory replay; Python stdlib only."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib, subprocess, sys, json
ROOT=Path(__file__).resolve().parent
checks=[]
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h,name=line.split(maxsplit=1)
    p=(ROOT/name).resolve()
    assert p.parent==ROOT, name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h, name
    checks.append(name)
print(f'REVIEW PACKAGE MANIFEST {len(checks)}/{len(checks)} PASS')
with TemporaryDirectory(prefix='hho_a9_replay_') as temp:
    t=Path(temp)
    for name in ('generic_engine.py','cyclic_disc_claude.py','SOURCE_f20_check.py','independent_a9_exact_check.py'):
        src=ROOT/name
        (t/('f20_check.py' if name=='SOURCE_f20_check.py' else name)).write_bytes(src.read_bytes())
    a=subprocess.run([sys.executable,'-I','f20_check.py'],cwd=t,check=True,capture_output=True,text=True,timeout=40)
    assert a.stdout.encode()==(ROOT/'f20_replay_stdout.txt').read_bytes()
    b=subprocess.run([sys.executable,'-I','independent_a9_exact_check.py'],cwd=t,check=True,capture_output=True,text=True,timeout=15)
    assert (t/'independent_a9_exact_results.json').read_bytes()==(ROOT/'independent_a9_exact_results.json').read_bytes()
    print('F20 PARABOLIC GRAM MOTOR: PASS (UNCHANGED ENGINE, NOT A SECOND ALGORITHM)')
    print('INDEPENDENT EISENSTEIN LOCALITY CHECK: PASS (55 formal, 53 connected C6, 5+5 F20)')
print('ALL AVAILABLE REPLAYS PASS')
