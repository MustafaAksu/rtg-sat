#!/usr/bin/env python3
"""Independent exact HHO Addendum 9 controls (no HCG engine)."""
from itertools import combinations_with_replacement
from collections import Counter
from math import gcd
from pathlib import Path
import json

# Eisenstein integers a + b*w, w^2+w+1=0.
def mul(x,y):
    a,b=x;c,d=y
    return (a*c-b*d,a*d+b*c-b*d)
def pow_e(x,n):
    r=(1,0)
    for _ in range(n):r=mul(r,x)
    return r
zeta=(1,1)
P_rows=[]
for ex in combinations_with_replacement(range(1,6),10):
    # Character chi=zeta yields balanced Hodge numbers iff sum(ex)=30.
    if sum(ex)!=30:continue
    P=(1,0)
    for e in ex:
        lam=pow_e(zeta,e)
        P=mul(P,(1-lam[0],-lam[1]))
    assert P[1]==0 and P[0]>0,(ex,P)
    N=P[0]
    v2=0
    while N%2==0:
        N//=2;v2+=1
    m_neigh=8-ex.count(3)
    disc='[2]' if v2%2 else '[1]'
    assert (v2%2)==(m_neigh%2)
    conn = (gcd(6,*ex)==1)
    P_rows.append(dict(ex=list(ex),local_den=P[0],v2=v2,m4=m_neigh,
                       disc=disc,C6_cover_connected=conn))
assert len(P_rows)==55
assert sum(int(r['C6_cover_connected']) for r in P_rows)==53
assert {tuple(r['ex']) for r in P_rows if not r['C6_cover_connected']}=={
    (2,2,2,2,2,4,4,4,4,4), (3,3,3,3,3,3,3,3,3,3)}
# C3 x F20 rank-1 character: 5 local omega and 5 local omega^2.
omega=pow_e(zeta,2);omega2=pow_e(zeta,4)
P=(1,0)
for v in [omega]*5+[omega2]*5:
    P=mul(P,(1-v[0],-v[1]))
assert P==(3**5,0),P
# rank-one E is full K, so the coefficient Gram factor q^10 is a norm.
# A nontrivial involution can have simultaneously p-divisible numerator and denominator.
# For h0=I2, g=swap, E = span(1,-1), h0 root norm 2, det(1-g)|E=2.
assert 2/2==1
res={
 'balanced_multisets':55,
 'connected_C6_covers':53,
 'disconnected_C6_covers':[[2]*5+[4]*5,[3]*10],
 'parity_matches_all_formal_rows':True,
 'C3xF20_rank_one_local_denominator':243,
 'C3xF20_rank_one_class':'[1]',
 'p2_involution_local_factor_numerator':2,
 'p2_involution_local_factor_denominator':2,
 'p2_involution_local_factor':'1',
 'scope':'Results derived exactly from Eisenstein integers; HCG cup/locality theorem is an external premise.'
}
Path(__file__).with_name('independent_a9_exact_results.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
