# HHO Addendum 9 — independent scientific audit

This package is **SESSION / NONCANONICAL**. It does not modify RTG, HCG v0.2, Severn or PO-6 records. It does not supply the original full `HCG_PARABOLIC_DISCRIMINANT_LOCALITY_PROOF_v0_1.md`; it supplies a contemporaneous line-by-line second-AI review of that unavailable proof and the theorem statement under those hypotheses.

Contents:
- `HHO_A9_LOCAL_SUPPORT_CHATGPT_INDEPENDENT_REVIEW_v0_1.md`: English mathematical report, proof of the rank-one law, exact inert-parity criterion, proposed tame-local lemma, and correction of the C6 connected-cover census.
- `SOURCE_HHO_SUPPORT_LEMMA_REVIEW_CLAUDE_ADDENDUM9.md`: unchanged uploaded source report.
- `SOURCE_f20_check.py`: unchanged uploaded independent-implementation replay script.
- `SOURCE_H3_DISC_LOCALITY_PROOF_REVIEW_CLAUDE_v0_1.md`: unchanged 2026-10-29 second-AI proof review of the original locality formula (not the original proof itself).
- `generic_engine.py`, `cyclic_disc_claude.py`: byte-exact frozen HCG motor files recovered from the previous A8 evidence archive; not new implementations.
- `independent_a9_exact_check.py`: separate small exact Eisenstein-number-theory checker; **does not use the HCG engine**.
- `independent_a9_exact_results.json`, `f20_replay_stdout.txt`: frozen successful outputs.
- `SHA256SUMS.txt`, `replay.py`: verify and rerun the package with Python standard library.

Execution in the extracted directory:

```sh
python3 replay.py
```

The report distinguishes `[SESSION — THM]` conditional deductions from original-source identity and adopted science. The C6 sweep count correction (53 connected C6 covers, not 54) is independent of the validity of the cyclic parity theorem.
