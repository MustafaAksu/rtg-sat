"""Finite exact checks accompanying HHO degree-7 reflection-normalizer proposal.
Does not prove the external reflection-group classification or normalizer statements.
"""
from functools import lru_cache
from pathlib import Path
import json

@lru_cache(None)
def partitions(n, top=None):
    if top is None:
        top=n
    if n==0: return ((),)
    out=[]
    for a in range(min(n,top),1-1,-1):
        for rest in partitions(n-a,a): out.append((a,)+rest)
    return tuple(out)

rows=[]
for N in (19,20,21,22):
    E=22-N
    def extra_patterns(total, least=1):
        if total==0:
            yield ()
            return
        for n in range(least,total+1):
            for p in extra_patterns(total-n,n): yield (n,)+p
    profiles=sorted({tuple(sorted((x+1 for x in extra), reverse=True)) for extra in extra_patterns(E)})
    assert all(sum(c-1 for c in profile)==E for profile in profiles)
    assert all(sum(c>=3 for c in profile)<=1 for profile in profiles)
    # Relative to the normal reflection subgroup: all local rank-one and
    # (conditionally on the group normalizer bound) rank-two elements are in R.
    # At most one remaining local generator can lie outside R. Product one
    # then forces the last local generator into R as well.
    rows.append({'N_effective':N,'excess':E,'nonreflection_rank_profiles':profiles,
                 'possible_local_generators_rank_at_least_3':1 if E>=2 else 0})
assert [r['nonreflection_rank_profiles'] for r in rows]==[
 [(2,2,2),(3,2),(4,)],[(2,2),(3,)],[(2,)], [()]]

p8=partitions(8)
evenmax=max(sum(x%2==0 for x in p) for p in p8)
assert evenmax==4
max_eight_cycle=next(p for p in p8 if sum(x%2==0 for x in p)==4)
output={'degree':7,'ranks':rows,'s8_cycle_partitions':len(p8),
        's8_max_eigenvalue_negative_one_multiplicity_standard':evenmax,
        's8_max_negative_eigen_cycle_witness':max_eight_cycle,
        's8_moving_rank_for_minus_w_at_least':7-evenmax,
        'nonreal_eigenspace_multiplicity_real_orthogonal_at_most':7//2,
        'nonreal_scalar_twist_moving_rank_at_least':7-7//2,
        'scope':'Exact integer/cycle checks; classification and normalizer input external.'}
Path(__file__).with_name('d7_budget_certificate.json').write_text(json.dumps(output,indent=2)+'\n')
print('D7 exact budget and S8 -1 eigenspace bounds: PASS')
